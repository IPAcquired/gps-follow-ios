import Foundation
import SwiftUI
import UniformTypeIdentifiers

struct ControllerMapping: Codable, Equatable, Identifiable {
    var id = UUID()
    var input: String
    var channel: String
    var action: String
    var verified: Bool
    enum CodingKeys: String, CodingKey { case input, channel, action, verified }
}

struct ControllerProfile: Codable, Equatable, Identifiable {
    var id = UUID()
    var schemaVersion: Int
    var name: String
    var verifiedPreset: Bool
    var notes: String
    var mappings: [ControllerMapping]
    enum CodingKeys: String, CodingKey {
        case schemaVersion = "schema_version", name, verifiedPreset = "verified_preset", notes, mappings
    }
    static let tx15Max = ControllerProfile(schemaVersion: 1, name: "RadioMaster TX15 Max", verifiedPreset: true,
        notes: "Display-only map from the current verified recovery record. It does not read or write the radio or aircraft.", mappings: [
            ControllerMapping(input: "Button 1", channel: "CH12", action: "Stabilize", verified: true),
            ControllerMapping(input: "Button 2", channel: "CH12", action: "AltHold", verified: true),
            ControllerMapping(input: "Button 3", channel: "CH12", action: "Loiter", verified: true),
            ControllerMapping(input: "Button 4", channel: "CH12", action: "Brake", verified: true),
            ControllerMapping(input: "Button 5", channel: "CH12", action: "RTL", verified: true),
            ControllerMapping(input: "Button 6", channel: "CH12", action: "Land", verified: true),
            ControllerMapping(input: "SA UP", channel: "CH10", action: "Disarm", verified: true),
            ControllerMapping(input: "SA MIDDLE", channel: "CH10", action: "Arm", verified: true),
            ControllerMapping(input: "SA DOWN", channel: "Separate RTL mix", action: "RTL", verified: true),
            ControllerMapping(input: "SE press", channel: "CH9", action: "Avoidance toggle", verified: true),
            ControllerMapping(input: "SF DOWN", channel: "CH11", action: "Brake", verified: true),
            ControllerMapping(input: "SF UP", channel: "CH11", action: "Restore previous mode if still in Brake", verified: true),
            ControllerMapping(input: "SD UP", channel: "CH12 mode mix", action: "Use Buttons 1–6", verified: true),
            ControllerMapping(input: "SD MIDDLE", channel: "CH12 mode mix", action: "AltHold override", verified: true),
            ControllerMapping(input: "SD DOWN", channel: "CH12 mode mix", action: "Stabilize override", verified: true),
        ])
}

enum ControllerProfileRules {
    static let critical = Set(["Arm", "Disarm", "RTL", "Land", "Emergency AltHold", "Stabilize", "AltHold", "Loiter", "Brake"])
    static let officialELRS = Set(["https://www.expresslrs.org/", "https://expresslrs.github.io/web-flasher/"])
    static let automaticELRSFlashingSupported = false
    static func validate(_ profile: ControllerProfile, allowVerified: Bool = false) throws -> ControllerProfile {
        guard profile.schemaVersion == 1 else { throw ProfileValidationError("Unsupported controller profile version.") }
        let name = profile.name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty, name.count <= 80, !name.contains("\n"), !name.contains("\0") else { throw ProfileValidationError("Profile name must be 1–80 characters on one line.") }
        guard profile.notes.count <= 1_000, (1...64).contains(profile.mappings.count) else { throw ProfileValidationError("Use 1–64 mappings and keep notes under 1,000 characters.") }
        var used: [String: String] = [:]
        var clean = profile; clean.name = name; clean.verifiedPreset = allowVerified && profile.verifiedPreset
        clean.mappings = try profile.mappings.map { row in
            let input = row.input.trimmingCharacters(in: .whitespacesAndNewlines)
            let channel = row.channel.trimmingCharacters(in: .whitespacesAndNewlines)
            let action = row.action.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !input.isEmpty, input.count <= 80, !channel.isEmpty, channel.count <= 80, !action.isEmpty, action.count <= 120,
                  ![input, channel, action].contains(where: { $0.contains("\n") || $0.contains("\0") }) else { throw ProfileValidationError("Every mapping needs a short, single-line input, channel and action.") }
            let key = input.lowercased()
            if critical.contains(action), let prior = used[key], prior != action { throw ProfileValidationError("\(input) has conflicting flight-critical actions: \(prior) and \(action).") }
            if critical.contains(action) { used[key] = action }
            return ControllerMapping(input: input, channel: channel, action: action, verified: allowVerified && row.verified)
        }
        return clean
    }
    static func imported(_ data: Data) throws -> ControllerProfile {
        guard data.count <= 262_144 else { throw ProfileValidationError("Controller profile is too large.") }
        return try validate(JSONDecoder().decode(ControllerProfile.self, from: data))
    }
    static func officialELRSURL(_ value: String) -> URL? { officialELRS.contains(value) ? URL(string: value) : nil }
}

struct ProfileValidationError: LocalizedError {
    let message: String
    init(_ message: String) { self.message = message }
    var errorDescription: String? { message }
}

@MainActor final class ControllerProfileStore: ObservableObject {
    @Published var profiles: [ControllerProfile] = [.tx15Max]
    @Published var selectedID = ControllerProfile.tx15Max.id
    @Published var message = "Verified preset · display only · no hardware writes"
    private let defaultsKey = "controller_profiles_v1"
    init(defaults: UserDefaults = .standard) {
        if let data = defaults.data(forKey: defaultsKey), let saved = try? JSONDecoder().decode([ControllerProfile].self, from: data) { profiles += saved.compactMap { try? ControllerProfileRules.validate($0) } }
    }
    var selectedIndex: Int { profiles.firstIndex(where: { $0.id == selectedID }) ?? 0 }
    var selected: ControllerProfile { profiles[selectedIndex] }
    var selectedBinding: Binding<ControllerProfile> { Binding(get: { self.profiles[self.selectedIndex] }, set: { self.profiles[self.selectedIndex] = $0 }) }
    func duplicate() {
        var copy = selected; copy.id = UUID(); copy.verifiedPreset = false
        copy.mappings = copy.mappings.map { ControllerMapping(input: $0.input, channel: $0.channel, action: $0.action, verified: false) }
        var n = 1; repeat { copy.name = "My controller \(n)"; n += 1 } while profiles.contains(where: { $0.name == copy.name })
        profiles.append(copy); selectedID = copy.id; save(); message = "Custom profile · Unverified · edit and save locally"
    }
    func addMapping() {
        guard !selected.verifiedPreset, profiles[selectedIndex].mappings.count < 64 else { return }
        profiles[selectedIndex].mappings.append(ControllerMapping(input: "New control", channel: "Unassigned", action: "Unassigned", verified: false))
    }
    func save() {
        do {
            guard !selected.verifiedPreset else { message = "Verified preset is read-only."; return }
            profiles[selectedIndex] = try ControllerProfileRules.validate(selected)
            UserDefaults.standard.set(try JSONEncoder().encode(Array(profiles.dropFirst())), forKey: defaultsKey)
            message = "Saved locally · Unverified · no hardware writes"
        } catch { message = error.localizedDescription }
    }
    func importData(_ data: Data) {
        do {
            let profile = try ControllerProfileRules.imported(data)
            guard !profiles.contains(where: { $0.name == profile.name }) else { throw ProfileValidationError("Use a unique profile name.") }
            profiles.append(profile); selectedID = profile.id; save(); message = "Imported locally as Unverified."
        } catch { message = "Import failed: \(error.localizedDescription)" }
    }
}

struct ControllerProfileDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.json] }
    var data: Data
    init(profile: ControllerProfile) { let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]; data = (try? encoder.encode(profile)) ?? Data() }
    init(configuration: ReadConfiguration) throws { data = configuration.file.regularFileContents ?? Data() }
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper { FileWrapper(regularFileWithContents: data) }
}

struct ControllerProfilesView: View {
    @StateObject private var store = ControllerProfileStore()
    @StateObject private var hardware = HardwareCatalogStore()
    @AppStorage("battery_cells") private var batteryCells = 6
    @AppStorage("board_catalog_id") private var boardID = "micoair-h743-v2"
    @State private var importing = false
    @State private var exporting = false
    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Picker("Controller", selection: $store.selectedID) { ForEach(store.profiles) { Text($0.name).tag($0.id) } }
                    Text(store.selected.verifiedPreset ? "Verified preset" : "Custom · Unverified").font(.subheadline.weight(.semibold))
                    Text("Layouts are labels stored in this app. They do not read, map or write the transmitter or flight controller.").font(.footnote).foregroundStyle(.secondary)
                } header: { Text("Controller layout") }
                Section("Mappings") {
                    ForEach(store.selectedBinding.mappings) { $row in
                        VStack(alignment: .leading, spacing: 6) {
                            if store.selected.verifiedPreset { Text(row.input).font(.headline); Text("\(row.channel) · \(row.action)") }
                            else { TextField("Physical input", text: $row.input); TextField("Channel or route", text: $row.channel); TextField("Action", text: $row.action) }
                            Text(row.verified ? "Verified" : "Unverified").font(.caption).foregroundStyle(row.verified ? .green : .orange)
                        }.padding(.vertical, 3)
                    }.onDelete { offsets in
                        guard !store.selected.verifiedPreset, store.selected.mappings.count - offsets.count >= 1 else { return }
                        store.profiles[store.selectedIndex].mappings.remove(atOffsets: offsets)
                    }
                    if !store.selected.verifiedPreset { Button("Add mapping") { store.addMapping() } }
                }
                Section {
                    Button("New profile from this layout") { store.duplicate() }
                    if !store.selected.verifiedPreset { Button("Save custom profile") { store.save() } }
                    Button("Import local JSON") { importing = true }
                    Button("Export selected JSON") { exporting = true }
                    Text(store.message).font(.footnote).foregroundStyle(.secondary)
                } footer: { Text("Imported and custom mappings are always Unverified. Saving rejects two different flight-critical actions assigned to the same physical input.") }
                Section("ExpressLRS firmware · manual only") {
                    Text("Wrong target selection or power loss can brick a transmitter module or receiver. Use a computer, back up current settings, remove props and disconnect the aircraft battery. Confirm the exact TX15 Max, Nomad module and receiver targets yourself.").foregroundStyle(.orange)
                    Text("This app never guesses a target, flashes automatically, or stores a binding phrase.").font(.footnote).foregroundStyle(.secondary)
                    if let guide = ControllerProfileRules.officialELRSURL("https://www.expresslrs.org/") { Link("Official ExpressLRS guide", destination: guide) }
                    if let flasher = ControllerProfileRules.officialELRSURL("https://expresslrs.github.io/web-flasher/") { Link("Open official Web Flasher", destination: flasher) }
                }
                Section("Battery profile") {
                    Picker("Cell count", selection: $batteryCells) { ForEach(1...12, id: \.self) { Text("\($0)S").tag($0) } }
                    if let view = try? HardwareCatalogRules.batteryDisplay(measuredPackVoltage: nil, cells: batteryCells, catalog: hardware.catalog) {
                        LabeledContent("Measured pack voltage", value: "Unavailable · no aircraft telemetry")
                        LabeledContent("Estimated percentage", value: "Unavailable")
                        Text("Reference only: full \(view.full, specifier: "%.1f") V · low \(view.low, specifier: "%.1f") V · critical \(view.critical, specifier: "%.1f") V")
                    }
                } footer: {
                    Text("The selected cell count only changes per-cell threshold math and does not certify the battery, board, sensor, power module or ESC rating. Pack voltage must remain a measured telemetry value. Any percentage shown after telemetry support is added will be labelled Estimated; voltage alone cannot prove remaining energy or flight time.")
                }
                Section("Flight-controller compatibility") {
                    Picker("Board", selection: $boardID) { ForEach(hardware.catalog.payload.boards) { Text($0.label).tag($0.id) } }
                    if let board = hardware.catalog.payload.boards.first(where: { $0.id == boardID }) {
                        LabeledContent("Required firmware target", value: board.firmwareTarget)
                    }
                    Text("Each revision requires its exact board-specific firmware. There is no universal binary, automatic target guess or automatic flash.")
                        .font(.footnote).foregroundStyle(.secondary)
                    Button(hardware.refreshing ? "Refreshing…" : "Refresh catalog from GitHub") { hardware.refresh() }.disabled(hardware.refreshing)
                    Text(hardware.status).font(.footnote).foregroundStyle(.secondary)
                }
            }
            .modifier(DroneMatrixSurface()).navigationTitle("Controllers")
            .fileImporter(isPresented: $importing, allowedContentTypes: [.json]) { result in
                guard case .success(let url) = result, url.startAccessingSecurityScopedResource() else { store.message = "Import cancelled or file access was denied."; return }
                defer { url.stopAccessingSecurityScopedResource() }
                do { store.importData(try Data(contentsOf: url, options: .mappedIfSafe)) } catch { store.message = "Import failed: \(error.localizedDescription)" }
            }
            .fileExporter(isPresented: $exporting, document: ControllerProfileDocument(profile: store.selected), contentType: .json,
                          defaultFilename: store.selected.name.replacingOccurrences(of: " ", with: "-")) { result in
                store.message = (try? result.get()) != nil ? "Profile exported locally." : "Export was cancelled or failed."
            }
        }
    }
}
