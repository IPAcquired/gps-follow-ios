"""Offline CI verification: YAML, shell/Python syntax and synthetic cases; no Xcode.

Requires the already installed PyYAML on the WSL review environment. Does not
upload, dispatch, open hardware, start sockets or run the workflow's build steps.
"""
import contextlib
import datetime
import io
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile
import unittest
from unittest.mock import patch

import yaml

ROOT = Path(__file__).resolve().parent.parent
WORKFLOW = ROOT / ".github" / "workflows" / "ios-build.yml"
CHECKOUT = "actions/checkout@3d3c42e5aac5ba805825da76410c181273ba90b1"
UPLOAD = "actions/upload-artifact@043fb46d1a93c77aae656e7c1c64a875d1fc6a0a"


def python_body(step):
    match = re.search(r"python3 - <<'PY'\n(.*?)\nPY(?:\n|$)", step["run"], re.S)
    if not match:
        raise ValueError("Embedded Python block not found")
    return match.group(1)


class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.workflow = yaml.safe_load(WORKFLOW.read_text())
        self.jobs = self.workflow["jobs"]

    def step(self, job, name):
        return next(item for item in self.jobs[job]["steps"] if item["name"] == name)

    def test_manual_only_read_only_and_trusted_pins(self):
        self.assertEqual(self.workflow["on"], {"workflow_dispatch": None})
        self.assertEqual(self.workflow["permissions"], {"contents": "read"})
        self.assertEqual(set(self.jobs), {"build_unsigned", "simulator_tests"})
        for job in self.jobs.values():
            self.assertEqual(job["runs-on"], "macos-15-intel")
            self.assertLessEqual(job["timeout-minutes"], 30)
            self.assertNotIn("needs", job)
            for step in job["steps"]:
                if "uses" not in step:
                    continue
                self.assertIn(step["uses"], {CHECKOUT, UPLOAD})
                self.assertRegex(step["uses"], r"@[0-9a-f]{40}$")
                if step["uses"] == CHECKOUT:
                    self.assertIs(step["with"]["persist-credentials"], False)
                else:
                    self.assertEqual(step["with"]["retention-days"], 7)
        text = WORKFLOW.read_text()
        self.assertNotIn("secrets.", text)
        self.assertNotIn("-allowProvisioningUpdates", text)

    def test_project_scheme_and_native_inventory_match(self):
        project = ROOT / self.workflow["env"]["APPCI_PROJECT"]
        self.assertTrue((project / "project.pbxproj").is_file())
        self.assertTrue((project / "xcshareddata" / "xcschemes" / "GPSFollow.xcscheme").is_file())
        self.assertEqual(self.workflow["env"]["APPCI_SCHEME"], "GPSFollow")
        source = "\n".join(p.read_text() for p in (ROOT / "iOS" / "GPSFollowTests").glob("*.swift"))
        self.assertGreaterEqual(len(re.findall(r"\bfunc\s+(test\w+)\s*\(", source)), 37)
        verify = python_body(self.step("simulator_tests", "Confirm the native tests actually executed"))
        self.assertIn("if expected < 37:", verify)

    def test_embedded_python_and_bash_syntax(self):
        for job in self.jobs.values():
            for step in job["steps"]:
                if "run" not in step:
                    continue
                with self.subTest(step=step["name"]):
                    checked = subprocess.run(["bash", "-n"], input=step["run"], text=True,
                                             capture_output=True, check=False)
                    self.assertEqual(checked.returncode, 0, checked.stderr)
                    if "python3 - <<'PY'" in step["run"]:
                        compile(python_body(step), step["name"], "exec")
                    if "| tee" in step["run"]:
                        self.assertIn("set -euo pipefail", step["run"])

    def test_unsigned_device_build_and_native_test_scope(self):
        build = self.step("build_unsigned", "Compile Release for physical iPhone without signing")["run"]
        self.assertIn("generic/platform=iOS", build)
        self.assertIn("CODE_SIGNING_ALLOWED=NO", build)
        self.assertIn("CODE_SIGNING_REQUIRED=NO", build)
        native = self.step("simulator_tests", "Compile and run native tests")["run"]
        self.assertIn("xcodebuild test", native)
        self.assertIn("-only-testing:GPSFollowTests ", native)
        self.assertIn("-resultBundlePath", native)
        self.assertIn("CODE_SIGN_IDENTITY=-", native)
        upload = self.step("build_unsigned", "Save unsigned application artifact")
        self.assertEqual(upload["with"]["name"], "build_unsigned")
        for name, job in (("Save compilation diagnostics", "build_unsigned"),
                          ("Save simulator results and failure diagnostics", "simulator_tests")):
            self.assertEqual(self.step(job, name)["if"], "always()")

    def select_simulator(self, devices, sdk="26.2"):
        body = python_body(self.step("simulator_tests", "Select available iPhone 16 Plus simulator"))
        with tempfile.TemporaryDirectory(prefix="gpsfollow-ci-review-") as temporary:
            folder = Path(temporary) / "gpsfollow-simulator-ci"
            folder.mkdir()
            (folder / "devices.json").write_text(json.dumps({"devices": devices}))
            (folder / "sdk-version.txt").write_text(sdk)
            output = Path(temporary) / "github-output.txt"
            with patch.dict(os.environ, RUNNER_TEMP=temporary, GITHUB_OUTPUT=str(output)), \
                 contextlib.redirect_stdout(io.StringIO()):
                exec(compile(body, "simulator selection", "exec"), {})
            return json.loads((folder / "SelectedSimulator.json").read_text()), output.read_text()

    def test_selects_newest_exact_model_with_compatible_runtime(self):
        device = lambda identity, name="iPhone 16 Plus": {
            "name": name, "isAvailable": True, "udid": identity}
        devices = {
            "com.apple.CoreSimulator.SimRuntime.iOS-18-5": [device("00000000-0000-0000-0000-000000000001")],
            "com.apple.CoreSimulator.SimRuntime.iOS-26-2": [device("00000000-0000-0000-0000-000000000002")],
            "com.apple.CoreSimulator.SimRuntime.iOS-26-3": [device("00000000-0000-0000-0000-000000000003")],
            "com.apple.CoreSimulator.SimRuntime.tvOS-26-2": [device("00000000-0000-0000-0000-000000000004")],
        }
        selected, output = self.select_simulator(devices)
        self.assertEqual(selected["runtime"], "com.apple.CoreSimulator.SimRuntime.iOS-26-2")
        self.assertEqual(output, "id=00000000-0000-0000-0000-000000000002\n")

    def test_preserves_exact_uppercase_core_simulator_identifier(self):
        identity = "08F7C3A1-760F-4BEF-AD83-D3BB2F7A65F0"
        selected, output = self.select_simulator({"com.apple.CoreSimulator.SimRuntime.iOS-26-2": [{
            "name": "iPhone 16 Plus", "isAvailable": True, "udid": identity}]})
        self.assertEqual(selected["id"], identity)
        self.assertEqual(output, "id=" + identity + "\n")

    def test_missing_or_wrong_model_cannot_pass_selection(self):
        for devices in ({}, {"com.apple.CoreSimulator.SimRuntime.iOS-26-2": [{
                "name": "iPhone 17", "isAvailable": True,
                "udid": "00000000-0000-0000-0000-000000000001"}]}):
            with self.assertRaisesRegex(SystemExit, "No available iPhone 16 Plus"):
                self.select_simulator(devices)

    def verify_summary(self, report):
        body = python_body(self.step("simulator_tests", "Confirm the native tests actually executed"))
        with tempfile.TemporaryDirectory(prefix="gpsfollow-ci-review-") as temporary:
            folder = Path(temporary) / "gpsfollow-simulator-ci"
            folder.mkdir()
            (folder / "TestSummary.json").write_text(json.dumps(report))
            before = Path.cwd()
            try:
                os.chdir(ROOT)
                with patch.dict(os.environ, RUNNER_TEMP=temporary), \
                     contextlib.redirect_stdout(io.StringIO()):
                    exec(compile(body, "native summary verification", "exec"), {})
            finally:
                os.chdir(before)

    def native_count(self):
        return sum(len(re.findall(r"\bfunc\s+(test\w+)\s*\(", p.read_text())) for p in (ROOT / "iOS/GPSFollowTests").glob("*.swift"))

    def test_all_successful_native_tests_pass_confirmation(self):
        count = self.native_count()
        self.verify_summary({"result": "Passed", "passedTests": count, "failedTests": 0,
                             "skippedTests": 0, "totalTestCount": count})

    def test_empty_incomplete_failed_or_skipped_results_rejected(self):
        count = self.native_count()
        valid = {"result": "Passed", "passedTests": count, "failedTests": 0,
                 "skippedTests": 0, "totalTestCount": count}
        for change in ({"passedTests": 0}, {"totalTestCount": 0}, {"passedTests": count - 1},
                       {"failedTests": 1}, {"skippedTests": 1}, {"result": "Failed"}):
            with self.subTest(change=change):
                report = dict(valid); report.update(change)
                with self.assertRaisesRegex(SystemExit, "did not prove"):
                    self.verify_summary(report)


def main():
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(WorkflowTests)
    output = io.StringIO()
    result = unittest.TextTestRunner(stream=output, verbosity=2).run(suite)
    report = {"checked_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "tests_run": result.testsRun, "successful": result.wasSuccessful(),
        "failures": len(result.failures), "errors": len(result.errors),
        "scope": "offline workflow YAML/syntax/security/path checks and synthetic simulator/test-summary cases",
        "xcode_executed": False, "native_tests_executed": False,
        "uploaded_or_dispatched": False, "hardware_opened": False,
        "source_sha256": {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in (
            ".github/workflows/ios-build.yml", "ci/verify_workflow.py",
            "iOS/GPSFollow.xcodeproj/project.pbxproj",
            "iOS/GPSFollow.xcodeproj/xcshareddata/xcschemes/GPSFollow.xcscheme",
            "iOS/GPSFollowTests/MAVLinkTests.swift")},
        "test_output": output.getvalue()}
    (ROOT / "ci-validation.json").write_text(json.dumps(report, indent=2) + "\n")
    (ROOT / "ci-validation.txt").write_text(output.getvalue())
    print(output.getvalue())
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__": raise SystemExit(main())
