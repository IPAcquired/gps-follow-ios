"""Offline CI verification: YAML, shell/Python syntax and synthetic cases; no Xcode.

Requires the already installed PyYAML on the WSL review environment. Does not
upload, dispatch, open hardware, start sockets or run the workflow's build steps.
"""
import contextlib
import datetime
import io
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile
import unittest
from unittest.mock import patch

import yaml

ROOT = Path(__file__).resolve().parent.parent
WORKFLOW = ROOT / ".github" / "workflows" / "ios-build.yml"
CHECKOUT = "actions/checkout@3d3c42e5aac5ba805825da76410c181273ba90b1"
UPLOAD = "actions/upload-artifact@043fb46d1a93c77aae656e7c1c64a875d1fc6a0a"


def python_body(step):
    match = re.search(r"python3 - <<'PY'\n(.*?)\nPY(?:\n|$)", step["run"], re.S)
    if not match:
        raise ValueError("Embedded Python block not found")
    return match.group(1)


def native_test_source_membership(project_text, test_names):
    """Resolve the test target's actual Sources; a group/file declaration is insufficient.

    This project's PBX objects are one object per line. Reject ambiguity instead
    of guessing when the project format or target wiring changes.
    """
    objects = {}
    for identity, body in re.findall(r'^\s*([A-F0-9]{24}) = \{(.*)\};\s*$', project_text, re.M):
        if identity in objects:
            raise ValueError('Duplicate PBX object')
        objects[identity] = body

    def scalar(identity, field):
        if identity not in objects:
            raise ValueError('Missing PBX object')
        values = re.findall(r'\b' + re.escape(field) + r'\s*=\s*([^;]+);', objects[identity])
        if len(values) != 1:
            raise ValueError('Missing or ambiguous PBX field')
        return values[0].strip().strip('"')

    def isa(identity):
        return scalar(identity, 'isa')

    def ids(identity, field):
        value = scalar(identity, field)
        if not re.fullmatch(r'\(\s*(?:[A-F0-9]{24}(?:\s*,\s*[A-F0-9]{24})*)?\s*\)', value):
            raise ValueError('Invalid PBX reference list')
        found = re.findall(r'[A-F0-9]{24}', value)
        if len(found) != len(set(found)):
            raise ValueError('Duplicate PBX reference')
        return found

    targets = [identity for identity in objects if isa(identity) == 'PBXNativeTarget'
               and scalar(identity, 'name') == 'GPSFollowTests']
    if len(targets) != 1 or scalar(targets[0], 'productType') != 'com.apple.product-type.bundle.unit-test':
        raise ValueError('Unique native test target required')
    phases = [identity for identity in ids(targets[0], 'buildPhases')
              if isa(identity) == 'PBXSourcesBuildPhase']
    if len(phases) != 1:
        raise ValueError('Unique test Sources phase required')
    groups = [identity for identity in objects if isa(identity) == 'PBXGroup'
              and re.search(r'\bpath\s*=\s*GPSFollowTests\s*;', objects[identity])]
    if len(groups) != 1:
        raise ValueError('Unique test source group required')
    expected = set(test_names)
    refs = {}
    for identity in ids(groups[0], 'children'):
        if isa(identity) != 'PBXFileReference':
            raise ValueError('Invalid test group child')
        name = scalar(identity, 'path')
        if name.endswith('.swift'):
            if name in refs or scalar(identity, 'lastKnownFileType') != 'sourcecode.swift':
                raise ValueError('Duplicate or invalid Swift test reference')
            refs[name] = identity
    if set(refs) != expected:
        raise ValueError('Swift test files do not match test group references')
    compiled = []
    for identity in ids(phases[0], 'files'):
        if isa(identity) != 'PBXBuildFile':
            raise ValueError('Invalid test Sources build file')
        ref = scalar(identity, 'fileRef')
        if isa(ref) != 'PBXFileReference' or ref not in refs.values():
            raise ValueError('Test Sources references a foreign file')
        compiled.append(ref)
    if len(compiled) != len(expected) or set(compiled) != set(refs.values()):
        raise ValueError('A native test file is missing or duplicated in actual test Sources')
    return {'target': targets[0], 'sources_phase': phases[0], 'test_files': sorted(refs)}


class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.workflow = yaml.safe_load(WORKFLOW.read_text())
        self.jobs = self.workflow["jobs"]

    def step(self, job, name):
        return next(item for item in self.jobs[job]["steps"] if item["name"] == name)

    def test_manual_only_read_only_and_trusted_pins(self):
        self.assertEqual(self.workflow["on"], {"workflow_dispatch": None})
        self.assertEqual(self.workflow["permissions"], {"contents": "read"})
        self.assertEqual(set(self.jobs), {"build_unsigned", "simulator_tests"})
        for job in self.jobs.values():
            self.assertEqual(job["runs-on"], "macos-15-intel")
            self.assertLessEqual(job["timeout-minutes"], 30)
            self.assertNotIn("needs", job)
            for step in job["steps"]:
                if "uses" not in step:
                    continue
                self.assertIn(step["uses"], {CHECKOUT, UPLOAD})
                self.assertRegex(step["uses"], r"@[0-9a-f]{40}$")
                if step["uses"] == CHECKOUT:
                    self.assertIs(step["with"]["persist-credentials"], False)
                else:
                    self.assertEqual(step["with"]["retention-days"], 7)
        text = WORKFLOW.read_text()
        self.assertNotIn("secrets.", text)
        self.assertNotIn("-allowProvisioningUpdates", text)

    def test_project_scheme_and_native_inventory_match(self):
        project = ROOT / self.workflow["env"]["APPCI_PROJECT"]
        self.assertTrue((project / "project.pbxproj").is_file())
        self.assertTrue((project / "xcshareddata" / "xcschemes" / "GPSFollow.xcscheme").is_file())
        self.assertEqual(self.workflow["env"]["APPCI_SCHEME"], "GPSFollow")
        source = "\n".join(p.read_text() for p in (ROOT / "iOS" / "GPSFollowTests").glob("*.swift"))
        self.assertGreaterEqual(len(re.findall(r"\bfunc\s+(test\w+)\s*\(", source)), 37)
        verify = python_body(self.step("simulator_tests", "Confirm the native tests actually executed"))
        self.assertIn("if expected < 37:", verify)

    def test_every_native_test_file_reaches_actual_test_target_sources(self):
        project = ROOT / self.workflow['env']['APPCI_PROJECT'] / 'project.pbxproj'
        names = [p.name for p in (ROOT / 'iOS/GPSFollowTests').glob('*.swift')]
        result = native_test_source_membership(project.read_text(encoding='utf-8'), names)
        self.assertEqual(result['test_files'], sorted(names))
        self.assertIn('CADTransferIntegrationTests.swift', result['test_files'])

    def test_declared_group_linked_but_uncompiled_test_is_rejected(self):
        project = ROOT / self.workflow['env']['APPCI_PROJECT'] / 'project.pbxproj'
        text = project.read_text(encoding='utf-8')
        names = [p.name for p in (ROOT / 'iOS/GPSFollowTests').glob('*.swift')]
        old_phase = re.search(r'^\s*A40000000000000000000004 = .*$', text, re.M).group(0)
        for member in ('D10000000000000000000004', 'A10000000000000000000005'):
            members = re.search(r'files = \((.*?)\);', old_phase).group(1).split(', ')
            self.assertIn(member, members)
            damaged = old_phase.replace(', '.join(members), ', '.join(value for value in members if value != member))
            self.assertNotEqual(damaged, old_phase)
            with self.subTest(member=member), self.assertRaisesRegex(ValueError, 'missing or duplicated'):
                native_test_source_membership(text.replace(old_phase, damaged), names)

    def test_test_build_file_must_resolve_to_its_actual_group_reference(self):
        project = ROOT / self.workflow['env']['APPCI_PROJECT'] / 'project.pbxproj'
        text = project.read_text(encoding='utf-8')
        names = [p.name for p in (ROOT / 'iOS/GPSFollowTests').glob('*.swift')]
        damaged = text.replace('D10000000000000000000004 = {isa = PBXBuildFile; fileRef = D20000000000000000000004;',
                               'D10000000000000000000004 = {isa = PBXBuildFile; fileRef = D20000000000000000000003;')
        self.assertNotEqual(damaged, text)
        with self.assertRaisesRegex(ValueError, 'foreign file'):
            native_test_source_membership(damaged, names)

    def test_embedded_python_and_bash_syntax(self):
        for job in self.jobs.values():
            for step in job["steps"]:
                if "run" not in step:
                    continue
                with self.subTest(step=step["name"]):
                    checked = subprocess.run(["bash", "-n"], input=step["run"], text=True,
                                             capture_output=True, check=False)
                    self.assertEqual(checked.returncode, 0, checked.stderr)
                    if "python3 - <<'PY'" in step["run"]:
                        compile(python_body(step), step["name"], "exec")
                    if "| tee" in step["run"]:
                        self.assertIn("set -euo pipefail", step["run"])

    def test_unsigned_device_build_and_native_test_scope(self):
        build = self.step("build_unsigned", "Compile Release for physical iPhone without signing")["run"]
        self.assertIn("generic/platform=iOS", build)
        self.assertIn("CODE_SIGNING_ALLOWED=NO", build)
        self.assertIn("CODE_SIGNING_REQUIRED=NO", build)
        native = self.step("simulator_tests", "Compile and run native tests")["run"]
        self.assertIn("xcodebuild test", native)
        self.assertIn("-only-testing:GPSFollowTests ", native)
        self.assertIn("-resultBundlePath", native)
        self.assertIn("CODE_SIGN_IDENTITY=-", native)
        upload = self.step("build_unsigned", "Save unsigned application artifact")
        self.assertEqual(upload["with"]["name"], "build_unsigned")
        for name, job in (("Save compilation diagnostics", "build_unsigned"),
                          ("Save simulator results and failure diagnostics", "simulator_tests")):
            self.assertEqual(self.step(job, name)["if"], "always()")

    def select_simulator(self, devices, sdk="26.2"):
        body = python_body(self.step("simulator_tests", "Select available iPhone 16 Plus simulator"))
        with tempfile.TemporaryDirectory(prefix="gpsfollow-ci-review-") as temporary:
            folder = Path(temporary) / "gpsfollow-simulator-ci"
            folder.mkdir()
            (folder / "devices.json").write_text(json.dumps({"devices": devices}))
            (folder / "sdk-version.txt").write_text(sdk)
            output = Path(temporary) / "github-output.txt"
            with patch.dict(os.environ, RUNNER_TEMP=temporary, GITHUB_OUTPUT=str(output)), \
                 contextlib.redirect_stdout(io.StringIO()):
                exec(compile(body, "simulator selection", "exec"), {})
            return json.loads((folder / "SelectedSimulator.json").read_text()), output.read_text()

    def test_selects_newest_exact_model_with_compatible_runtime(self):
        device = lambda identity, name="iPhone 16 Plus": {
            "name": name, "isAvailable": True, "udid": identity}
        devices = {
            "com.apple.CoreSimulator.SimRuntime.iOS-18-5": [device("00000000-0000-0000-0000-000000000001")],
            "com.apple.CoreSimulator.SimRuntime.iOS-26-2": [device("00000000-0000-0000-0000-000000000002")],
            "com.apple.CoreSimulator.SimRuntime.iOS-26-3": [device("00000000-0000-0000-0000-000000000003")],
            "com.apple.CoreSimulator.SimRuntime.tvOS-26-2": [device("00000000-0000-0000-0000-000000000004")],
        }
        selected, output = self.select_simulator(devices)
        self.assertEqual(selected["runtime"], "com.apple.CoreSimulator.SimRuntime.iOS-26-2")
        self.assertEqual(output, "id=00000000-0000-0000-0000-000000000002\n")

    def test_preserves_exact_uppercase_core_simulator_identifier(self):
        identity = "08F7C3A1-760F-4BEF-AD83-D3BB2F7A65F0"
        selected, output = self.select_simulator({"com.apple.CoreSimulator.SimRuntime.iOS-26-2": [{
            "name": "iPhone 16 Plus", "isAvailable": True, "udid": identity}]})
        self.assertEqual(selected["id"], identity)
        self.assertEqual(output, "id=" + identity + "\n")

    def test_missing_or_wrong_model_cannot_pass_selection(self):
        for devices in ({}, {"com.apple.CoreSimulator.SimRuntime.iOS-26-2": [{
                "name": "iPhone 17", "isAvailable": True,
                "udid": "00000000-0000-0000-0000-000000000001"}]}):
            with self.assertRaisesRegex(SystemExit, "No available iPhone 16 Plus"):
                self.select_simulator(devices)

    def verify_summary(self, report):
        body = python_body(self.step("simulator_tests", "Confirm the native tests actually executed"))
        with tempfile.TemporaryDirectory(prefix="gpsfollow-ci-review-") as temporary:
            folder = Path(temporary) / "gpsfollow-simulator-ci"
            folder.mkdir()
            (folder / "TestSummary.json").write_text(json.dumps(report))
            before = Path.cwd()
            try:
                os.chdir(ROOT)
                with patch.dict(os.environ, RUNNER_TEMP=temporary), \
                     contextlib.redirect_stdout(io.StringIO()):
                    exec(compile(body, "native summary verification", "exec"), {})
            finally:
                os.chdir(before)

    def native_count(self):
        return sum(len(re.findall(r"\bfunc\s+(test\w+)\s*\(", p.read_text())) for p in (ROOT / "iOS/GPSFollowTests").glob("*.swift"))

    def preview_calls(self, state, available=True, present=True):
        identity = "08F7C3A1-760F-4BEF-AD83-D3BB2F7A65F0"
        body = python_body(self.step("simulator_tests", "Capture app connection screen"))
        rows = [{"udid": identity, "state": state, "isAvailable": available}] if present else []
        calls = []
        with tempfile.TemporaryDirectory(prefix="gpsfollow-preview-review-") as temporary:
            app = Path(temporary) / "gpsfollow-simulator-derived/Build/Products/Debug-iphonesimulator/GPSFollow.app"
            app.mkdir(parents=True)
            with patch.dict(os.environ, RUNNER_TEMP=temporary, APPCI_SIMULATOR_ID=identity), \
                 patch.object(subprocess, "check_output", return_value=json.dumps({"devices": {"test": rows}}).encode()), \
                 patch.object(subprocess, "run", side_effect=lambda command, **options: calls.append((command, options))):
                exec(compile(body, "preview simulator preparation", "exec"), {})
        return identity, calls

    def test_preview_reboots_shutdown_and_installs_tested_app(self):
        identity, calls = self.preview_calls("Shutdown")
        self.assertEqual(calls[0][0], ["xcrun", "simctl", "boot", identity])
        self.assertEqual(calls[1][0], ["xcrun", "simctl", "bootstatus", identity, "-b"])
        self.assertEqual(calls[2][0][:4], ["xcrun", "simctl", "install", identity])
        self.assertEqual(Path(calls[2][0][4]).parts[-2:], ("Debug-iphonesimulator", "GPSFollow.app"))
        self.assertTrue(all(options["check"] and 0 < options["timeout"] <= 180 for _, options in calls))

    def test_preview_booted_device_is_not_booted_twice(self):
        identity, calls = self.preview_calls("Booted")
        self.assertEqual(len(calls), 2)
        self.assertEqual(calls[0][0], ["xcrun", "simctl", "bootstatus", identity, "-b"])

    def test_preview_rejects_missing_unavailable_or_transition_device(self):
        for state, available, present in [("Shutdown", True, False), ("Shutdown", False, True), ("Shutting Down", True, True)]:
            with self.subTest(state=state, available=available, present=present), self.assertRaises(SystemExit):
                self.preview_calls(state, available, present)

    def test_all_successful_native_tests_pass_confirmation(self):
        count = self.native_count()
        self.verify_summary({"result": "Passed", "passedTests": count, "failedTests": 0,
                             "skippedTests": 0, "totalTestCount": count})

    def test_empty_incomplete_failed_or_skipped_results_rejected(self):
        count = self.native_count()
        valid = {"result": "Passed", "passedTests": count, "failedTests": 0,
                 "skippedTests": 0, "totalTestCount": count}
        for change in ({"passedTests": 0}, {"totalTestCount": 0}, {"passedTests": count - 1},
                       {"failedTests": 1}, {"skippedTests": 1}, {"result": "Failed"}):
            with self.subTest(change=change):
                report = dict(valid); report.update(change)
                with self.assertRaisesRegex(SystemExit, "did not prove"):
                    self.verify_summary(report)


def main():
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(WorkflowTests)
    output = io.StringIO()
    result = unittest.TextTestRunner(stream=output, verbosity=2).run(suite)
    report = {"checked_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "tests_run": result.testsRun, "successful": result.wasSuccessful(),
        "failures": len(result.failures), "errors": len(result.errors),
        "scope": "offline workflow YAML/syntax/security/path checks and synthetic simulator/test-summary cases",
        "xcode_executed": False, "native_tests_executed": False,
        "uploaded_or_dispatched": False, "hardware_opened": False,
        "source_sha256": {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in (
            ".github/workflows/ios-build.yml", "ci/verify_workflow.py",
            "iOS/GPSFollow.xcodeproj/project.pbxproj",
            "iOS/GPSFollow.xcodeproj/xcshareddata/xcschemes/GPSFollow.xcscheme",
            "iOS/GPSFollowTests/MAVLinkTests.swift")},
        "test_output": output.getvalue()}
    (ROOT / "ci-validation.json").write_text(json.dumps(report, indent=2) + "\n")
    (ROOT / "ci-validation.txt").write_text(output.getvalue())
    print(output.getvalue())
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__": raise SystemExit(main())
