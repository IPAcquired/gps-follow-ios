"""CI-only real UDP relay: synthetic public key, production protocol.Session, no controller access.

The socket binds loopback only. The test adapter maps its loopback peer IP to a fixed
synthetic RFC1918 address because production Session correctly refuses loopback.
Actual source ports, session/sequence/time/crypto paths are preserved.
"""
import argparse
import json
from pathlib import Path
import signal
import socket
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "relay"))
from protocol import Limits, Rejected, Session

parser = argparse.ArgumentParser()
parser.add_argument("--report", type=Path, required=True)
args = parser.parse_args()
session = Session(bytes(range(32)), "192.168.25.2", Limits(origin_lat=41.1234567, origin_lon=-87.7654321))
metrics = dict(accepted=0, rejected=0, expired=0, controller_commands=0, fixture="public synthetic loopback only")
running = True
def stop(*_):
    global running
    running = False
signal.signal(signal.SIGTERM, stop)
signal.signal(signal.SIGINT, stop)
with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as udp:
    udp.bind(("127.0.0.1", 35678))
    udp.settimeout(0.2)
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.with_suffix(".ready").write_text("ready\n")
    started = time.monotonic()
    while running and time.monotonic() - started < 1200:
        try:
            data, peer = udp.recvfrom(4097)
            if peer[0] != "127.0.0.1":
                continue
            response = session.accept(data, ("192.168.25.2", peer[1]), int(time.time() * 1000), time.monotonic(), serial_ready=False)
            udp.sendto(response, peer)
            metrics["accepted"] += 1
        except Rejected:
            metrics["rejected"] += 1
        except socket.timeout:
            if session.latest is not None and session.publishable(int(time.time() * 1000), time.monotonic()) is None and session.latest is None:
                metrics["expired"] += 1
        except OSError:
            break
args.report.write_text(json.dumps(metrics, indent=2) + "\n")
