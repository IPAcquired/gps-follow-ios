# Secure phone connection

The matching secure iPhone app and Windows companion encrypt every phone-PC GPS message and reply. Update both together. Older, unencrypted relay messages are rejected rather than silently accepted.

Connect the devices to the same secured local Wi-Fi. Copy the companion's current PC address and private pairing details into the phone. Keep the phone open and unlocked while sharing. A private release download and the existing Sideloadly signing process provide manual updates; the app does not install itself or change controller settings.

## Exact wire contract

Phone-PC protocol version is `2`. The only outer fields are `v`, `nonce`, `ciphertext`, and `tag`. Binary fields use canonical standard base64. AES-256-GCM uses a 32-byte private pairing key, a fresh cryptographically random 12-byte nonce per packet, and a 16-byte tag. The exact additional authenticated data is ASCII `GPSFollow/phone-pc/v2/aes-256-gcm`. The decrypted JSON also requires integer `v: 2`. There is no legacy HMAC/plaintext fallback. A 4,096-byte datagram bound and 16-level JSON nesting bound apply before parsing; malformed packets are rejected.

Encryption does not replace replay or safety checks. The existing explicitly selected private IPv4 peer, endpoint binding, client/relay handshake nonces, increasing sequence, two-second clock bound, one-second source expiry, five-Hz publication ceiling, and GPS accuracy/speed/radius/jump limits remain. Invalid authenticated coordinates clear the cached target. A fixed or old encrypted packet cannot reset an established sequence. Authentication is symmetric: anyone with the pairing key is an authorized peer. Keep that key private and replace it if disclosed. No actual keys are provisioned or rotated by this source build.

Guest Target never reuses or exposes the owner pairing key. Each guest invitation has its own random 256-bit key, unique target identity, selected private phone address and absolute expiration. The relay binds a session to that role and identity, rejects legacy owner packets on a guest listener, and clears the cached target when the invitation expires. Only one explicitly selected configuration is active per relay process. Guest setup cards are sensitive until expiration and must stay out of public source, screenshots and release bundles.

Swift uses Apple's CryptoKit; Python uses pinned `cryptography` AESGCM. The public test fixtures are not user secrets. Fixed nonces exist only in tests. Python verifies a published all-zero AES-256-GCM known answer and the exact protocol-domain fixture; native XCTest verifies both with CryptoKit. Native test success and physical phone-PC pairing need separate evidence from an actual build and test.

## Separate controller links

This encryption covers phone-PC traffic only. The current desktop companion has no flight-controller output. The optional CLI serial code does not configure MAVLink signing and must not be treated as an authenticated wireless controller connection. It requires a separately reviewed extension and provisioning/recovery plan before wireless flight use.

The advanced direct telemetry implementation requires authenticated signed MAVLink replies. MAVLink signing is not payload encryption. The board's current signing key/provisioning and wireless enforcement are unverified; source support alone does not prove signing is active. The installed firmware intentionally allows unsigned USB recovery/channel 0 and radio-status exceptions. Neither controller keys nor USB recovery policy are changed here.

Keys remain in iOS device-only, when-unlocked Keychain and the desktop's existing Windows-user protected private configuration. Configured operating-center coordinates remain locally remembered; this is not a claim of fully encrypted local metadata. No credentials, user keys or private relay configuration are shipped in this source.

This app does not arm the drone, change flight modes/home/parameters, classify landing surfaces or provide obstacle avoidance. Follow is currently disabled. No software or radio can be promised hackproof or crashproof.

References: [Apple CryptoKit AES.GCM](https://developer.apple.com/documentation/cryptokit/aes/gcm), [NIST GCM](https://csrc.nist.gov/pubs/sp/800/38/d/final), [MAVLink signing](https://mavlink.io/en/guide/message_signing.html).
