# Nate’s Drone 1.2 build 4 — reviewed candidate scope

The previous build 3 ZIP is preserved as an intermediate CAD/handoff edition.

This revision adds direct **read-only Centauri Carbon 2 LAN** connection from the iPhone, using the official Elegoo Link contract at Apache-2.0 source commit `46c7b814e055cf9675d58482d79f43d0bd2280da`. Manual printer IP / unicast UDP discovery avoids restricted broadcast entitlements that are unavailable with ordinary free personal signing. The phone checks the selected serial, access code through HTTP `X-Token`, MQTT registration, attributes and full status before showing a result. It does not send printer mutations, upload G-code, start a print, or consume partial status deltas as a full baseline. Each operation owns its sockets, is bounded, and disconnects after a status check; leaving the tab or backgrounding cancels it.

The vendor’s LAN protocol is **plain HTTP/MQTT**. The UI states this; access-code, serial and IP checking do not supply encrypted or cryptographic printer identity. No credential is placed in a URL, log or error. Native Network framework handles the vendor protocol directly; no broad ATS Internet exception is added. Real printer header-only X-Token compatibility and actual hardware status remain to be tested.

Editable local profiles are limited to Elegoo families. The Carbon 2 adapter is enabled. Original Carbon / Neptune / Giga profiles can be saved, but unsupported models cannot send Carbon 2 commands. Access codes are stored separately by profile ID in Keychain. Changing model/address or disconnecting clears displayed status and selection. The official Matrix App Store link handles remote/cellular account sign-in; this app does not fake an Elegoo login or obtain vendor tokens. Matrix account connection requires printer Internet access and vendor support.

## PC pairing

The first Connect screen automatically looks for `_gpsfollow._udp` Bonjour advertisements on local Wi-Fi. Compatible advertisements contain only protocol `aes-gcm-v2`, companion version and `bench_only=1`, with a selected PC address/UDP port. No key or GPS is advertised. The user selects the PC; the private key is never overwritten by discovery, and the encrypted handshake remains required. Multiple PC services remain separate choices.

An explicit **Copy iPhone setup → Paste** card transfers the current PC endpoint, key and operating area once. Exact bounded format: header `GPSFollow-local-setup-v1`, then ordered `pc_ip`, `udp_port`, `pairing_key`, `center_lat`, `center_lon`, `radius_m`, `height_m`, `protocol`, `companion_version` lines, at most 2048 UTF-8 bytes. There is no automatic clipboard reading. The phone’s actual Wi-Fi IP remains separate; the PC’s selected phone peer must match it. No flight authority, Follow enablement or automatic GPS sharing is added.

## Native simulator verification

The workflow now executes **all** GPSFollowTests classes and computes its expected inventory from every Swift test file, fixing the inherited single-class filter. It runs native real loopback UDP/HTTP/MQTT fake-printer connection tests, rejection cases and full-status decoding. Fake listeners bind loopback only. A separate loopback Python fixture runs the production protocol.Session with a public synthetic key: native CryptoKit messages test handshake, target acknowledgement, Stop, wrong-key timeout, stale fixes, replay rejection and recovery. A test-only loopback-to-synthetic-private-peer adapter is needed because production Session correctly refuses loopback addresses; no real Windows PC, live key or drone is involved. These are native connection tests, not physical printer/drone clearance.

Rounded system typography, red/black/white interface, keyboard Done/scroll dismissal, tab/background cleanup and clear connection errors are included. CAD import/share and the full controller/help/footer remain. Updates stay verified HTTPS release downloads followed by local Sideloadly signing; no FTP, silent over-air install or vendor-password screen is added.
