# Nate’s Drone app 1.2 candidate

This candidate adds four native tabs while preserving the encrypted GPS protocol:

- **Connect / GPS** opens first, defaults to the Windows relay, and shows the PC address, UDP port, masked key, this iPhone’s current Wi-Fi address, installed iOS version and required relay protocol together. The phone address is read from the actual en0 Wi-Fi interface every five seconds. The PC address is explicitly the user-entered address copied from the companion; the app does not falsely label it automatically verified. Separate direct/relay address settings prevent using an old direct-telemetry address as the PC endpoint.
- **Drone CAD** imports local STL / 3MF copies through Apple’s Files picker. Filenames are sanitized; regular files only; at most 64 MB each, 256 MB total, 100 files. Basic STL/ZIP headers are checked. No ZIP extraction, mesh execution, printer commands or format transformation occurs. Each import gets an independent UUID filename; the library lists, shares, exports through Files and deletes only its own copies. Files are protected until first device unlock and excluded from automatic backup; users should explicitly save another copy. Library geometry, strength and printing suitability are not validated by these header checks.
- **Printer** identifies the user-confirmed Centauri Carbon 2 with 0.6 mm nozzle, notes the older original-Carbon profile, and provides a standard file-share / PC slicing workflow. Printer upload and direct 3D GO integration are unavailable until an independently reviewed supported bridge is connected. No proprietary 3D GO source or undocumented deep link is used.
- **Q&A** retains the full AERO control map, connection help and manual app-update links. iOS and Windows version numbers are separate; both must support AES-GCM protocol v2. The original branding footer remains `Made by Nate Wrench 2026`.

## Deliberate limits

No automatic secret broadcasting, QR discovery, camera permission, Bluetooth hardware claims or background location were added. The pairing key remains in Keychain and masked until the user reveals it. A first-time iPhone setup still needs the private PC details transferred locally; no untrusted LAN sender can silently set the key. GPS sharing does not arm or enable Follow, and the current PC companion remains bench-only. Saved CAD files can be passed to compatible installed apps through the normal iOS Share sheet; an app appearing there does not prove printer support.

## Verification

The inherited Python protocol/relay tests and project-structure tests run offline on Windows. Eight new native CAD tests cover byte preservation, duplicate imports, safe filenames, malformed STL headers, no archive extraction, symlink/folder/unsupported-file rejection, deletion confinement, oversized-file refusal and item-count limits. These native tests must be executed in Xcode CI with the existing 13 tests; Windows source checks are not native compilation.

Source-only candidate: root owns the Mac CI build, device signing, private keys, real connections and actual printer profile changes. The frozen 1.1 release remains untouched.
