# Automated Mac compilation and native tests

The prepared workflow is `.github/workflows/ios-build.yml`. It has **not been uploaded or dispatched by the app-building agent**. A workflow file on this Windows computer does not establish successful native compilation. Read actual run status, logs and artifacts before changing the delivery status.

The app directory’s **contents** must be at the GitHub repository root: `.github/workflows/ios-build.yml`, `iOS/GPSFollow.xcodeproj`, `iOS/GPSFollow/` and `iOS/GPSFollowTests/`. Upload only the app source package, not unrelated workspace records or real relay/signing configuration. The parent task owns repository selection/upload and dispatch. Once uploaded to the repository’s default branch, select **Actions → GPS Follow iOS build and tests → Run workflow** on the reviewed source revision. The workflow is manual-only and does not create schedules or run on every push.

The workflow runs two independent Mac jobs:

| Job / artifact | What it proves |
|---|---|
| `build_unsigned` | Compiles a Release application for the physical iPhone platform with device signing disabled. Saves `GPSFollow-unsigned-ios.app.zip` plus commit/Xcode/SDK/hash provenance. The result is **not installable on a physical iPhone** until separately signed and provisioned. |
| `device_build_diagnostics` | Saves compilation logs, project inventory, selected Xcode version and available build result bundle, including on failures. |
| `simulator_tests` / `simulator_test_results` | Compiles and executes the included XCTest suite on an available iPhone 16 Plus simulator; saves `.xcresult`, logs, device/SDK selection and test summary. A count check rejects zero-test or unexpectedly incomplete success. |

It uses the standard `macos-15-intel` runner and explicitly selects the verified preinstalled Xcode 26.3 path. It fails clearly if that Xcode version or a compatible iPhone 16 Plus simulator is no longer present. It selects the newest available iPhone 16 Plus runtime supported by that SDK, rather than guessing a simulator UUID. Nothing is installed from third-party package managers.

No Apple account, development certificate, provisioning profile, application signing secret or publishing secret is required. Simulator tests use Xcode’s local ad-hoc `-` identity to run their hosted test application; this is not physical-device signing. There is no upload to Apple, TestFlight, an App Store or a release. GitHub stores the explicitly named build/test artifacts for seven days. The workflow grants only repository contents read access and does not persist checkout credentials. Its two official GitHub actions are pinned to full verified commit revisions:

- `actions/checkout` v7.0.1: `3d3c42e5aac5ba805825da76410c181273ba90b1`.
- `actions/upload-artifact` v7.0.1: `043fb46d1a93c77aae656e7c1c64a875d1fc6a0a`.

GitHub repository access and an enabled Actions runner are still needed to execute it. Private-repository runner availability and minutes depend on the account. No workflow execution, repository creation or upload is represented as completed by this document.

A green device-build job establishes native compilation. A green simulator test job with its verified summary establishes actual Swift XCTest execution. Neither proves precise physical GPS, local-network permissions on the user’s iPhone, telemetry module compatibility, a successful phone install or safe flight behavior. Those remaining checks require the signed app and actual hardware. The existing `FOLL_ENABLE=0` and Follow firmware integration prerequisites remain unchanged.

Primary references used to prepare the workflow:

- [GitHub runner labels](https://docs.github.com/en/actions/reference/runners/github-hosted-runners).
- [Official macOS 15 image/Xcode inventory](https://github.com/actions/runner-images/blob/main/images/macos/macos-15-Readme.md).
- [Official checkout v7.0.1](https://github.com/actions/checkout/releases/tag/v7.0.1) and [upload-artifact v7.0.1](https://github.com/actions/upload-artifact/releases/tag/v7.0.1); tag-to-full-commit identity was resolved against GitHub’s public API.
- [GitHub workflow security guidance](https://docs.github.com/en/actions/reference/security/secure-use).
- [Apple command-line Xcode build/test guidance](https://developer.apple.com/library/archive/technotes/tn2339/_index.html).
- [Apple running tests and result bundles](https://developer.apple.com/documentation/xcode/running-tests-and-interpreting-results).
- [Apple xcresulttool commands introduced in Xcode 16](https://developer.apple.com/documentation/xcode-release-notes/xcode-16_3-release-notes).
