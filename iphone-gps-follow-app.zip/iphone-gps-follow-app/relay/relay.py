"""Optional Wi-Fi iPhone -> Windows -> MAVLink serial relay. Explicit start only."""
from __future__ import annotations

import argparse
import dataclasses
import json
import os
from pathlib import Path
import secrets
import socket
import sys
import time

from protocol import (EXPECTED_BOARD_UID, TARGET_COMPONENT_ID, TARGET_SYSTEM_ID,
                      Limits, Rejected, Session, local_ipv4, pairing_key,
                      parameters_ready, required_follow_parameters, target_fields)

APP_ROOT = Path(__file__).resolve().parent.parent
WORKSPACE_ROOT = APP_ROOT.parent.parent
DEPENDENCIES = WORKSPACE_ROOT / "work" / "serial-deps"
PARAMETER_NAMES = tuple(required_follow_parameters(5)) + ("FOLL_DIST_MAX", "FOLL_TIMEOUT", "FOLL_YAW_BEHAVE")


def load_config(path: Path) -> dict:
    config = json.loads(path.read_text(encoding="utf-8"))
    config["bind_ip"] = local_ipv4(config["bind_ip"])
    config["phone_ip"] = local_ipv4(config["phone_ip"])
    port = config["port"]
    if isinstance(port, bool) or not isinstance(port, int) or not 1024 <= port <= 65535:
        raise Rejected("UDP port must be between 1024 and 65535")
    config["key_bytes"] = pairing_key(config["pairing_key_hex"])
    config["limits_object"] = Limits(**config["limits"])
    role = config.get("target_role", "owner")
    identity = config.get("target_id", "owner")
    expires = config.get("expires_ms")
    # Session performs the complete validation. Constructing here also makes
    # malformed/expired guest files fail before a socket or COM port is opened.
    Session(config["key_bytes"], config["phone_ip"], config["limits_object"], role, identity, expires)
    if expires is not None and int(time.time() * 1000) >= expires:
        raise Rejected("Guest invitation expired; create a new one")
    config["target_role"], config["target_id"], config["expires_ms"] = role, identity, expires
    return config


class SerialTarget:
    def __init__(self, port: str, baud: int, limits: Limits):
        if port.upper() not in {"COM8", "COM9"}:
            raise Rejected("Only explicitly selected COM8 or COM9 is allowed in this board-specific package")
        if not 9600 <= baud <= 921600:
            raise Rejected("Invalid baud rate")
        if DEPENDENCIES.is_dir():
            sys.path.insert(0, str(DEPENDENCIES))
        os.environ["MAVLINK20"] = "1"
        try:
            from pymavlink import mavutil
        except ImportError as exc:
            raise Rejected("pymavlink is unavailable; use the existing work/serial-deps environment") from exc
        self.mavutil = mavutil
        # Only this explicit run --serial action opens hardware.
        self.link = mavutil.mavlink_connection(port.upper(), baud=baud,
                    source_system=TARGET_SYSTEM_ID, source_component=TARGET_COMPONENT_ID,
                    autoreconnect=False, dialect="ardupilotmega")
        self.limits = limits
        self.uid_verified = False
        self.parameters: dict[str, float] = {}
        self.parameter_times: dict[str, float] = {}
        self.last_heartbeat = 0.0
        self.fc_system: int | None = None
        self.fc_component: int | None = None
        self.last_refresh = 0.0
        self.last_own_heartbeat = 0.0
        self.own_frames: list[bytes] = []
        self.link.mav.set_send_callback(self.remember_frame)
        self.start_mono = time.monotonic()
        self.last_reason = "Waiting for the selected controller"

    def probe(self) -> None:
        deadline = time.monotonic() + 15
        # run() owns cleanup for every failure, including probe and socket setup.
        while time.monotonic() < deadline:
            self.poll()
            if self.fc_system is not None:
                self.refresh()
            if self.ready():
                print("Controller UID and Follow settings verified; no parameters changed.")
                return
            time.sleep(0.02)
        raise Rejected(self.last_reason)

    def refresh(self) -> None:
        now = time.monotonic()
        if now - self.last_refresh < 4 or self.fc_system is None:
            return
        self.last_refresh = now
        # MAV_CMD_REQUEST_MESSAGE is a diagnostic read; never a mode/arming command.
        self.link.mav.command_long_send(self.fc_system, self.fc_component,
            self.mavutil.mavlink.MAV_CMD_REQUEST_MESSAGE, 0,
            self.mavutil.mavlink.MAVLINK_MSG_ID_AUTOPILOT_VERSION, 0, 0, 0, 0, 0, 0)
        for name in PARAMETER_NAMES:
            self.link.mav.param_request_read_send(self.fc_system, self.fc_component,
                                                name.encode("ascii"), -1)

    def poll(self) -> None:
        # Bounded input draining prevents a telemetry flood starving source freshness checks.
        for _ in range(100):
            msg = self.link.recv_match(blocking=False)
            if msg is None:
                break
            kind = msg.get_type()
            now = time.monotonic()
            if msg.get_srcSystem() == TARGET_SYSTEM_ID:
                if bytes(msg.get_msgbuf()) in self.own_frames:
                    continue
                raise Rejected("Target system ID 42 already exists on this telemetry link")
            if (kind == "HEARTBEAT" and msg.get_srcComponent() == 1
                    and msg.autopilot == self.mavutil.mavlink.MAV_AUTOPILOT_ARDUPILOTMEGA):
                if self.fc_system is not None and msg.get_srcSystem() != self.fc_system:
                    raise Rejected("More than one ArduPilot controller is present")
                self.fc_system, self.fc_component = msg.get_srcSystem(), msg.get_srcComponent()
                self.last_heartbeat = now
            if msg.get_srcSystem() != self.fc_system or msg.get_srcComponent() != self.fc_component:
                continue
            if kind == "AUTOPILOT_VERSION":
                uid = bytes(getattr(msg, "uid2", [])).hex()
                if EXPECTED_BOARD_UID is None:
                    raise Rejected("No private controller identity is configured for serial output")
                if uid != EXPECTED_BOARD_UID:
                    raise Rejected("Selected port is not the expected H743 controller (UID mismatch)")
                self.uid_verified = True
            elif kind == "PARAM_VALUE":
                name = msg.param_id
                if isinstance(name, bytes):
                    name = name.decode("ascii", errors="replace")
                name = name.rstrip("\x00")
                if name in PARAMETER_NAMES:
                    self.parameters[name] = float(msg.param_value)
                    self.parameter_times[name] = now
        self.refresh()
        if time.monotonic() - self.last_own_heartbeat >= 1:
            self.last_own_heartbeat = time.monotonic()
            self.link.mav.heartbeat_send(self.mavutil.mavlink.MAV_TYPE_GROUND_ROVER,
                self.mavutil.mavlink.MAV_AUTOPILOT_INVALID, 0, 0,
                self.mavutil.mavlink.MAV_STATE_ACTIVE)

    def remember_frame(self, message) -> None:
        self.own_frames.append(bytes(message.get_msgbuf()))
        self.own_frames = self.own_frames[-128:]

    def ready(self) -> bool:
        now = time.monotonic()
        if not self.uid_verified:
            self.last_reason = "Expected board UID has not been verified"
            return False
        if now - self.last_heartbeat > 3:
            self.last_reason = "Controller heartbeat lost"
            return False
        valid, self.last_reason = parameters_ready(self.parameters, self.limits)
        if not valid:
            return False
        if any(now - self.parameter_times.get(name, 0) > 10 for name in PARAMETER_NAMES):
            self.last_reason = "Follow parameter readback is stale"
            return False
        return True

    def publish(self, sample) -> None:
        self.link.mav.global_position_int_send(*target_fields(sample, time.monotonic() - self.start_mono))

    def close(self) -> None:
        self.link.close()


def create_config(args) -> None:
    path = Path(args.config).resolve()
    if path.exists():
        raise Rejected("Configuration exists; choose a new path to rotate pairing explicitly")
    if not 1024 <= args.port <= 65535:
        raise Rejected("UDP port must be between 1024 and 65535")
    limits = Limits(args.origin_lat, args.origin_lon, radius_m=args.radius_m,
                    hover_height_m=args.height_m)
    config = {"bind_ip": local_ipv4(args.bind_ip), "phone_ip": local_ipv4(args.phone_ip),
              "target_role": "owner", "target_id": "owner", "expires_ms": None,
              "port": args.port, "pairing_key_hex": secrets.token_hex(32),
              "limits": dataclasses.asdict(limits)}
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(config, indent=2) + "\n", encoding="utf-8")
    print(f"Pairing configuration created at {path}")


def create_guest_config(args) -> None:
    owner = load_config(Path(args.owner_config))
    if owner["target_role"] != "owner":
        raise Rejected("Guest invitations must be created from an owner configuration")
    minutes = args.minutes
    if not 5 <= minutes <= 240:
        raise Rejected("Guest invitation lifetime must be between 5 and 240 minutes")
    identity = "guest-" + secrets.token_hex(8)
    expires = int(time.time() * 1000) + minutes * 60_000
    guest = {
        "bind_ip": owner["bind_ip"], "phone_ip": local_ipv4(args.phone_ip),
        "port": owner["port"], "pairing_key_hex": secrets.token_hex(32),
        "limits": dataclasses.asdict(owner["limits_object"]),
        "target_role": "guest", "target_id": identity, "expires_ms": expires,
    }
    path = Path(args.config).resolve()
    if path.exists():
        raise Rejected("Refusing to overwrite an existing guest configuration")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(guest, indent=2) + "\n", encoding="utf-8")
    card = path.with_suffix(path.suffix + ".iphone-setup.txt")
    limits = guest["limits"]
    card.write_text("\n".join((
        "GPSFollow-local-setup-v2",
        f"pc_ip={guest['bind_ip']}", f"udp_port={guest['port']}",
        f"pairing_key={guest['pairing_key_hex']}",
        f"center_lat={limits['origin_lat']}", f"center_lon={limits['origin_lon']}",
        f"radius_m={limits['radius_m']}", f"height_m={limits['hover_height_m']}",
        "protocol=aes-gcm-v2", "companion_version=1.2",
        "target_role=guest", f"target_id={identity}", f"expires_ms={expires}", ""
    )), encoding="utf-8")
    print(f"Temporary guest configuration created at {path}")
    print(f"Share only the expiring setup card: {card}")
    print("Open it locally to transfer the pairing key into the app. Treat this file as a secret.")
    print("No network listener or serial port was opened.")


def run(args) -> None:
    config = load_config(Path(args.config))
    limits = config["limits_object"]
    confirmation = getattr(args, "confirm_target_id", None)
    configured_role = config.get("target_role", "owner")
    configured_identity = config.get("target_id", "owner")
    if configured_role == "guest":
        if confirmation != configured_identity:
            raise Rejected("Guest Target requires explicit confirmation of its target ID")
    elif confirmation is not None:
        raise Rejected("Owner mode does not accept a guest target confirmation")
    if not args.dry_run and not args.serial:
        raise Rejected("Choose --dry-run or explicitly specify --serial COM8/COM9")
    if args.dry_run and args.serial:
        raise Rejected("Choose one of --dry-run and --serial")
    serial_target = None
    listener = None
    last_state = None
    try:
        serial_target = SerialTarget(args.serial, args.baud, limits) if args.serial else None
        if serial_target:
            serial_target.probe()
        session = Session(config["key_bytes"], config["phone_ip"], limits,
                          configured_role, configured_identity,
                          config.get("expires_ms"))
        listener = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        listener.settimeout(0.04)
        listener.bind((config["bind_ip"], config["port"]))
        print(f"Listening on selected private interface {config['bind_ip']}:{config['port']}")
        print("Only the selected phone and authenticated session are accepted.")
        if args.dry_run:
            print("DRY RUN: accepted coordinates are validated; no MAVLink or hardware output.")
        while True:
            now_ms, now_mono = int(time.time()*1000), time.monotonic()
            if serial_target:
                serial_target.poll()
            ready = serial_target.ready() if serial_target else False
            try:
                data, peer = listener.recvfrom(4097)
                reply = session.accept(data, peer, int(time.time()*1000), time.monotonic(), ready)
                listener.sendto(reply, peer)
            except socket.timeout:
                pass
            except Rejected:
                # No replies/log flooding for unauthenticated or out-of-session datagrams.
                pass
            sample = session.publishable(int(time.time()*1000), time.monotonic())
            if serial_target and ready and sample:
                serial_target.publish(sample)
            state = ("publishing target" if ready and session.latest else
                     "dry-run target accepted" if args.dry_run and session.latest else
                     serial_target.last_reason if serial_target and not ready else "target unavailable")
            if state != last_state:
                print(state)
                last_state = state
    finally:
        # Keep the primary failure and release serial even if socket cleanup itself fails.
        if listener is not None:
            try:
                listener.close()
            except OSError:
                pass
        if serial_target:
            try:
                serial_target.close()
            except OSError:
                pass


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="action", required=True)
    new = sub.add_parser("new-config", help="Create pairing file only; opens no hardware/network")
    new.add_argument("--config", required=True)
    new.add_argument("--bind-ip", required=True, help="Laptop's private Wi-Fi IPv4 address")
    new.add_argument("--phone-ip", required=True, help="One selected phone's private Wi-Fi IPv4 address")
    new.add_argument("--origin-lat", type=float, required=True)
    new.add_argument("--origin-lon", type=float, required=True)
    new.add_argument("--radius-m", type=float, default=50)
    new.add_argument("--height-m", type=float, default=5)
    new.add_argument("--port", type=int, default=45678)
    guest = sub.add_parser("new-guest-config", help="Create one expiring guest target invitation")
    guest.add_argument("--owner-config", required=True)
    guest.add_argument("--config", required=True)
    guest.add_argument("--phone-ip", required=True, help="Guest phone's private Wi-Fi IPv4 address")
    guest.add_argument("--minutes", type=int, default=30)
    start = sub.add_parser("run", help="Explicitly start selected interface and optional serial")
    start.add_argument("--config", required=True)
    choice = start.add_mutually_exclusive_group(required=True)
    choice.add_argument("--dry-run", action="store_true")
    choice.add_argument("--serial", choices=("COM8", "COM9"))
    start.add_argument("--baud", type=int, default=115200)
    start.add_argument("--confirm-target-id", help="Required exact target ID when intentionally running Guest Target")
    args = parser.parse_args()
    try:
        if args.action == "new-config":
            create_config(args)
        elif args.action == "new-guest-config":
            create_guest_config(args)
        else:
            run(args)
        return 0
    except KeyboardInterrupt:
        print("Stopped. Target publication ended; no mode or arming command was sent.")
        return 0
    except (Rejected, OSError, KeyError, TypeError, json.JSONDecodeError) as exc:
        print(f"Not started/stopped: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
