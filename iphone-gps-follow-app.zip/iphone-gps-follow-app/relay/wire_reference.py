"""Independent offline MAVLink fixture builder for tests. Opens no sockets/hardware."""
import hashlib
import struct

EXTRA = {0: 50, 20: 214, 22: 220, 33: 104, 76: 152, 77: 143, 148: 178}


def crc_x25(data, extra):
    crc = 0xffff
    for value in data + bytes([extra]):
        tmp = value ^ (crc & 0xff)
        tmp = (tmp ^ (tmp << 4)) & 0xff
        crc = ((crc >> 8) ^ (tmp << 8) ^ (tmp << 3) ^ (tmp >> 4)) & 0xffff
    return crc


def packet(message_id, payload, sequence=7, key=None, timestamp=1_000_000, link_id=43):
    header = bytes([0xfd, len(payload), int(key is not None), 0, sequence, 42, 191])
    header += message_id.to_bytes(3, "little")
    frame = header + payload + struct.pack("<H", crc_x25(header[1:] + payload, EXTRA[message_id]))
    if key is not None:
        trailer = bytes([link_id]) + timestamp.to_bytes(6, "little")
        frame += trailer + hashlib.sha256(key + frame + trailer).digest()[:6]
    return frame


def position_payload(lat=41.1234567, lon=-87.7654321, uptime_ms=123456):
    return struct.pack("<Iiiii hhh H", uptime_ms, round(lat * 1e7), round(lon * 1e7),
                       0, 0, 0, 0, 0, 65535)


def fixtures():
    heartbeat = struct.pack("<IBBBBB", 0, 10, 8, 0, 4, 3)
    payload = position_payload()
    key = bytes(range(32))
    return {"key_hex": key.hex(), "timestamp": 1_000_000, "sequence": 7,
            "global_position_int_hex": packet(33, payload).hex(),
            "signed_global_position_int_hex": packet(33, payload, key=key).hex(),
            "heartbeat_hex": packet(0, heartbeat).hex(),
            "signed_heartbeat_hex": packet(0, heartbeat, key=key).hex()}
