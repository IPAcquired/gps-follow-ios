import base64
import hashlib
import json
import math
from pathlib import Path
import struct
import sys
import unittest
from unittest.mock import Mock, patch
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parent))
workspace = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(workspace / "work" / "serial-deps"))

from protocol import (VERSION, AAD, Limits, Rejected, Session, decode, encode, local_ipv4,
                      parameters_ready, required_follow_parameters, target_fields)
from wire_reference import packet, position_payload, fixtures

KEY = bytes(range(32))
PEER = ("192.168.4.2", 12345)
CLIENT = "01" * 16
NOW = 1_800_000_000_000


class GPSValidationTests(unittest.TestCase):
    def setUp(self):
        self.limits = Limits(41, -87)
        self.session = Session(KEY, PEER[0], self.limits)
        response = self.send({"v": VERSION, "kind": "hello", "client_nonce": CLIENT, "sent_ms": NOW})
        self.relay_nonce = response["relay_nonce"]

    def send(self, payload, now_ms=NOW, mono=100, peer=PEER):
        return decode(self.session.accept(encode(payload, KEY), peer, now_ms, mono), KEY)

    def position(self, **changes):
        payload = {"v": VERSION, "kind": "position", "client_nonce": CLIENT,
            "relay_nonce": self.relay_nonce, "sequence": 1, "sent_ms": NOW,
            "fix_ms": NOW, "lat": 41, "lon": -87, "accuracy_m": 3, "speed_mps": 0}
        payload.update(changes)
        return payload

    def test_accept_and_fixed_safe_altitude(self):
        self.assertEqual(self.send(self.position())["status"], "accepted")
        sample = self.session.publishable(NOW, 100)
        fields = target_fields(sample, 12.345)
        self.assertEqual(fields, (12345, 410000000, -870000000, 0, 0, 0, 0, 0, 65535))

    def test_wrong_peer(self):
        with self.assertRaises(Rejected): self.send(self.position(), peer=("192.168.4.3", 12345))

    def test_wrong_endpoint(self):
        with self.assertRaises(Rejected): self.send(self.position(), peer=(PEER[0], 33333))

    def test_wrong_key_and_tamper(self):
        with self.assertRaises(Rejected): decode(encode(self.position(), b"x" * 32), KEY)
        body = bytearray(encode(self.position(), KEY)); body[20] ^= 1
        with self.assertRaises(Rejected): decode(bytes(body), KEY)

    def test_sequence_replay_and_reorder(self):
        self.send(self.position(sequence=2))
        with self.assertRaises(Rejected): self.send(self.position(sequence=1))
        with self.assertRaises(Rejected): self.send(self.position(sequence=2))

    def test_stale_and_future_fix(self):
        self.assertEqual(self.send(self.position(fix_ms=NOW - 1001))["status"], "rejected")
        self.assertEqual(self.send(self.position(sequence=2, fix_ms=NOW + 101))["status"], "rejected")

    def test_old_packet_and_clock_skew(self):
        with self.assertRaises(Rejected): self.send(self.position(sent_ms=NOW - 2001))

    def test_bad_accuracy_suppresses_cached_target(self):
        self.send(self.position())
        response = self.send(self.position(sequence=2, accuracy_m=10))
        self.assertEqual(response["status"], "rejected")
        self.assertIsNone(self.session.publishable(NOW, 100.3))

    def test_speed_and_outside_radius(self):
        self.assertEqual(self.send(self.position(speed_mps=4))["status"], "rejected")
        self.assertEqual(self.send(self.position(sequence=2, lat=41.001))["status"], "rejected")

    def test_jump_filter(self):
        self.send(self.position())
        response = self.send(self.position(sequence=2, lat=41.0002, fix_ms=NOW + 200, sent_ms=NOW + 200),
                             now_ms=NOW + 200, mono=100.2)
        self.assertEqual(response["status"], "rejected")
        self.assertIn("jumped", response["reason"])

    def test_same_timestamp_coordinate_change(self):
        self.send(self.position())
        response = self.send(self.position(sequence=2, lat=41.00001))
        self.assertEqual(response["status"], "rejected")

    def test_backward_fix_timestamp(self):
        self.send(self.position())
        response = self.send(self.position(sequence=2, fix_ms=NOW - 1))
        self.assertEqual(response["status"], "rejected")

    def test_rate_cap_and_loss_timeout(self):
        self.send(self.position())
        self.assertIsNotNone(self.session.publishable(NOW, 100))
        self.assertIsNone(self.session.publishable(NOW + 100, 100.1))
        self.assertIsNotNone(self.session.publishable(NOW + 201, 100.201))
        self.assertIsNone(self.session.publishable(NOW + 1001, 101.001))

    def test_monotonic_loss_if_wall_clock_moves(self):
        self.send(self.position())
        self.assertIsNone(self.session.publishable(NOW, 101.001))

    def test_stop_clears_target(self):
        self.send(self.position())
        stop = self.position(sequence=2, kind="stop")
        self.assertEqual(self.send(stop)["status"], "stopped")
        self.assertIsNone(self.session.publishable(NOW, 100.3))

    def test_restart_and_old_session_nonce(self):
        self.send(self.position())
        new = {"v": VERSION, "kind": "hello", "client_nonce": "02" * 16, "sent_ms": NOW}
        self.send(new)
        with self.assertRaises(Rejected): self.send(self.position(sequence=2))
        with self.assertRaises(Rejected): self.send({"v": VERSION, "kind": "hello", "client_nonce": CLIENT, "sent_ms": NOW})

    def test_hello_replay_does_not_reset_sequence(self):
        self.send(self.position())
        self.send({"v": VERSION, "kind": "hello", "client_nonce": CLIENT, "sent_ms": NOW})
        with self.assertRaises(Rejected): self.send(self.position())

    def test_invalid_nan_boolean_and_huge_packet(self):
        for field in ("lat", "lon", "accuracy_m", "speed_mps", "fix_ms", "sequence"):
            bad = self.position(sequence=self.session.last_sequence + 1)
            bad[field] = True
            try:
                response = self.send(bad)
                self.assertEqual(response["status"], "rejected")
            except Rejected:
                self.assertIn(field, ("sequence",))
        with self.assertRaises(Rejected): decode(b"x" * 4097, KEY)
        with self.assertRaises(ValueError): encode({"lat": math.nan}, KEY)
        with self.assertRaises(Rejected): decode(encode({"v": True}, KEY), KEY)

    def test_duplicate_field_json(self):
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        body = b'{"v":2,"v":2}'
        iv = bytes(range(12))
        sealed = AESGCM(KEY).encrypt(iv, body, AAD)
        envelope = json.dumps({"v": VERSION, "nonce": base64.b64encode(iv).decode(),
            "ciphertext": base64.b64encode(sealed[:-16]).decode(),
            "tag": base64.b64encode(sealed[-16:]).decode()}).encode()
        with self.assertRaises(Rejected): decode(envelope, KEY)

    def test_operating_limits_and_private_unicast(self):
        for ip in ("0.0.0.0", "255.255.255.255", "127.0.0.1", "224.0.0.1", "8.8.8.8", "192.168.1.255"):
            with self.assertRaises(Rejected): local_ipv4(ip)
        for change in ({"radius_m": 0}, {"send_hz": 6}, {"hover_height_m": 100}, {"origin_lat": math.nan}):
            args = dict(origin_lat=41, origin_lon=-87); args.update(change)
            with self.assertRaises(Rejected): Limits(**args)

    def test_follow_configuration_gates(self):
        params = required_follow_parameters(5)
        params.update(FOLL_DIST_MAX=50, FOLL_TIMEOUT=1, FOLL_YAW_BEHAVE=1)
        self.assertTrue(parameters_ready(params, self.limits)[0])
        for name, wrong in (("FOLL_ENABLE", 0), ("FOLL_SYSID", 1), ("FOLL_ALT_TYPE", 0),
                            ("FOLL_OFS_TYPE", 1), ("FOLL_OFS_X", 2), ("FOLL_OFS_Y", 2),
                            ("FOLL_OFS_Z", 5), ("FOLL_DIST_MAX", 0), ("FOLL_TIMEOUT", 10),
                            ("FOLL_YAW_BEHAVE", 2)):
            broken = dict(params); broken[name] = wrong
            self.assertFalse(parameters_ready(broken, self.limits)[0], name)


class MAVLinkCompatibilityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Importing the generated codec does not open COM ports.
        from pymavlink.dialects.v20 import ardupilotmega
        cls.mav = ardupilotmega

    def test_global_position_packet_matches_pymavlink(self):
        codec = self.mav.MAVLink(None, srcSystem=42, srcComponent=191)
        codec.seq = 7
        msg = self.mav.MAVLink_global_position_int_message(123456, 411234567, -877654321,
                                                          0, 0, 0, 0, 0, 65535)
        actual = packet(33, position_payload())
        self.assertEqual(actual, msg.pack(codec))
        parsed = self.mav.MAVLink(None).parse_buffer(actual)[0]
        self.assertEqual(parsed.get_srcSystem(), 42)
        self.assertEqual(parsed.relative_alt, 0)

    def test_signed_packets_match_pymavlink(self):
        for message, payload, message_id in (
            (self.mav.MAVLink_global_position_int_message(123456, 411234567, -877654321,
                0, 0, 0, 0, 0, 65535), position_payload(), 33),
            (self.mav.MAVLink_heartbeat_message(10, 8, 0, 0, 4, 3),
                struct.pack("<IBBBBB", 0, 10, 8, 0, 4, 3), 0)):
            codec = self.mav.MAVLink(None, srcSystem=42, srcComponent=191)
            codec.seq = 7
            codec.signing.secret_key = KEY
            codec.signing.link_id = 43
            codec.signing.timestamp = 1_000_000
            codec.signing.sign_outgoing = True
            self.assertEqual(packet(message_id, payload, key=KEY), message.pack(codec))

    def test_read_only_requests_decode(self):
        decoder = self.mav.MAVLink(None)
        payload = struct.pack("<7fHBBB", 148, 0, 0, 0, 0, 0, 0, 512, 1, 1, 0)
        request = decoder.parse_buffer(packet(76, payload))[0]
        self.assertEqual(request.command, self.mav.MAV_CMD_REQUEST_MESSAGE)
        self.assertEqual(request.param1, 148)
        param = struct.pack("<hBB16s", -1, 1, 1, b"FOLL_ENABLE")
        request = decoder.parse_buffer(packet(20, param))[0]
        self.assertEqual(request.param_id, "FOLL_ENABLE")

    def test_signed_receiver_rejects_tampering(self):
        codec = self.mav.MAVLink(None)
        codec.signing.secret_key = KEY
        codec.signing.timestamp = 1_000_000
        original = packet(33, position_payload(), key=KEY)
        self.assertEqual(codec.parse_buffer(original)[0].get_type(), "GLOBAL_POSITION_INT")
        fresh = bytearray(packet(33, position_payload(), key=KEY, timestamp=1_000_001))
        fresh[-1] ^= 1
        with self.assertRaises(self.mav.MAVError): codec.parse_buffer(bytes(fresh))

    def test_uid_extension_zero_padding(self):
        uid = bytes.fromhex("1c0032000d51343436353634000000000000")
        payload = bytes(60) + uid
        frame = packet(148, payload.rstrip(b"\x00"))
        parsed = self.mav.MAVLink(None).parse_buffer(frame)[0]
        self.assertEqual(bytes(parsed.uid2), uid)

    def test_fixture_file_is_current(self):
        fixture = Path(__file__).resolve().parent.parent / "iOS" / "GPSFollowTests" / "fixtures.json"
        self.assertEqual(json.loads(fixture.read_text()), fixtures())


class RelayOwnershipTests(unittest.TestCase):
    def test_serial_released_on_socket_creation_setup_and_bind_failures(self):
        import relay
        config = {"bind_ip": "192.168.4.1", "phone_ip": PEER[0], "port": 45678,
                  "key_bytes": KEY, "limits_object": Limits(41, -87)}
        args = SimpleNamespace(config="unused.json", dry_run=False, serial="COM8", baud=115200)
        for phase in ("create", "setup", "bind"):
            with self.subTest(phase=phase):
                serial = Mock()
                listener = Mock()
                failure = OSError("injected " + phase)
                socket_factory = Mock(return_value=listener)
                if phase == "create": socket_factory.side_effect = failure
                if phase == "setup": listener.settimeout.side_effect = failure
                if phase == "bind": listener.bind.side_effect = failure
                with patch.object(relay, "load_config", return_value=config), \
                     patch.object(relay, "SerialTarget", return_value=serial), \
                     patch.object(relay.socket, "socket", socket_factory):
                    with self.assertRaisesRegex(OSError, "injected " + phase): relay.run(args)
                serial.probe.assert_called_once()
                serial.close.assert_called_once()
                if phase != "create": listener.close.assert_called_once()

    def test_cleanup_failure_preserves_primary_error_and_releases_serial(self):
        import relay
        config = {"bind_ip": "192.168.4.1", "phone_ip": PEER[0], "port": 45678,
                  "key_bytes": KEY, "limits_object": Limits(41, -87)}
        args = SimpleNamespace(config="unused", dry_run=False, serial="COM9", baud=115200)
        serial, listener = Mock(), Mock()
        listener.bind.side_effect = OSError("primary bind failure")
        listener.close.side_effect = OSError("secondary close failure")
        with patch.object(relay, "load_config", return_value=config), \
             patch.object(relay, "SerialTarget", return_value=serial), \
             patch.object(relay.socket, "socket", return_value=listener):
            with self.assertRaisesRegex(OSError, "primary bind failure"): relay.run(args)
        serial.close.assert_called_once()

    def test_probe_failure_survives_close_failure(self):
        import relay
        config = {"bind_ip": "192.168.4.1", "phone_ip": PEER[0], "port": 45678,
                  "key_bytes": KEY, "limits_object": Limits(41, -87)}
        args = SimpleNamespace(config="unused", dry_run=False, serial="COM9", baud=115200)
        serial = Mock()
        serial.probe.side_effect = Rejected("primary controller probe failure")
        serial.close.side_effect = OSError("secondary serial close failure")
        with patch.object(relay, "load_config", return_value=config), \
             patch.object(relay, "SerialTarget", return_value=serial), \
             patch.object(relay.socket, "socket") as socket_factory:
            with self.assertRaisesRegex(Rejected, "primary controller probe failure"): relay.run(args)
        serial.close.assert_called_once()
        socket_factory.assert_not_called()

    def test_exact_echo_allowed_other_target_identity_rejected(self):
        import relay
        from pymavlink.dialects.v20 import ardupilotmega
        target = relay.SerialTarget.__new__(relay.SerialTarget)
        target.own_frames = [packet(33, position_payload())]
        target.refresh = Mock()
        target.last_own_heartbeat = __import__("time").monotonic()
        echo = ardupilotmega.MAVLink(None).parse_buffer(target.own_frames[0])[0]
        target.link = Mock()
        target.link.recv_match.side_effect = [echo, None]
        target.poll()  # byte-for-byte self echo is ignored
        other = ardupilotmega.MAVLink(None).parse_buffer(packet(33, position_payload(uptime_ms=99)))[0]
        target.link.recv_match.side_effect = [other]
        with self.assertRaisesRegex(Rejected, "42 already exists"): target.poll()


if __name__ == "__main__":
    unittest.main(verbosity=2)
