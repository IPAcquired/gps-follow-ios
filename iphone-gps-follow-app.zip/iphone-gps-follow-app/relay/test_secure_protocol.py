"""Encryption/availability regressions with public synthetic keys; no I/O links."""
import base64
import json
from pathlib import Path
import unittest
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from protocol import AAD, VERSION, Limits, Rejected, Session, decode, encode

KEY = bytes(range(32))
IV = bytes(range(12))
NOW = 1_800_000_000_000
PEER = ('192.168.4.2', 12345)


def raw_envelope(body, *, aad=AAD, key=KEY, iv=IV, version=VERSION):
    sealed = AESGCM(key).encrypt(iv, body, aad)
    return json.dumps({'v': version, 'nonce': base64.b64encode(iv).decode(),
        'ciphertext': base64.b64encode(sealed[:-16]).decode(),
        'tag': base64.b64encode(sealed[-16:]).decode()}, separators=(',', ':')).encode()


class SecureProtocolTests(unittest.TestCase):
    def test_published_aes256_zero_known_vector(self):
        vector = json.loads((Path(__file__).with_name('secure-fixtures.json')).read_text())['nist_aes256_zero_vector']
        sealed = AESGCM(bytes.fromhex(vector['key_hex'])).encrypt(bytes.fromhex(vector['nonce_hex']),
            bytes.fromhex(vector['plaintext_hex']), bytes.fromhex(vector['aad_hex']))
        self.assertEqual(sealed.hex(), vector['ciphertext_hex'] + vector['tag_hex'])

    def test_fixed_cross_platform_fixture(self):
        fixture = json.loads(Path(__file__).with_name('secure-fixtures.json').read_text())
        self.assertEqual(fixture['aad_utf8'].encode(), AAD)
        sealed = AESGCM(KEY).encrypt(IV, fixture['plaintext_utf8'].encode(), AAD)
        self.assertEqual(sealed.hex(), fixture['ciphertext_hex'] + fixture['tag_hex'])
        self.assertEqual(decode(json.dumps(fixture['envelope']).encode(), KEY), {'kind': 'hello', 'v': VERSION})

    def test_swift_native_fixtures_exactly_match_public_fixture(self):
        fixture = json.loads(Path(__file__).with_name('secure-fixtures.json').read_text())
        swift = (Path(__file__).parents[1]/'iOS/GPSFollowTests/MAVLinkTests.swift').read_text()
        for name in ('ciphertext_hex', 'tag_hex'):
            self.assertIn(fixture[name], swift)
        self.assertIn('cea7403d4d606b6e074ec5d3baf39d18', swift)
        self.assertIn('d0d1c8a799996bf0265b98b5d48ab919', swift)

    def test_every_packet_uses_fresh_random_nonce_and_hides_plaintext(self):
        payload = {'v': VERSION, 'lat': 41.1234567, 'lon': -87.7654321, 'kind': 'position'}
        packets = [encode(payload, KEY) for _ in range(1024)]
        nonces = {json.loads(wire)['nonce'] for wire in packets}
        self.assertEqual(len(nonces), len(packets))
        for wire in packets:
            self.assertNotIn(b'41.1234567', wire)
            self.assertNotIn(b'position', wire)
            self.assertEqual(len(base64.b64decode(json.loads(wire)['nonce'])), 12)
            self.assertEqual(decode(wire, KEY), payload)

    def test_ciphertext_tag_and_nonce_tampering_all_reject(self):
        envelope = json.loads(encode({'v': VERSION, 'kind': 'hello'}, KEY))
        for name in ('nonce', 'ciphertext', 'tag'):
            altered = dict(envelope)
            value = bytearray(base64.b64decode(altered[name])); value[0] ^= 1
            altered[name] = base64.b64encode(value).decode()
            with self.subTest(field=name), self.assertRaises(Rejected):
                decode(json.dumps(altered).encode(), KEY)

    def test_wrong_key_and_wrong_domain_reject(self):
        wire = encode({'v': VERSION, 'kind': 'hello'}, KEY)
        with self.assertRaises(Rejected): decode(wire, b'x'*32)
        with self.assertRaises(Rejected): decode(raw_envelope(b'{"v":2}', aad=b'wrong domain'), KEY)

    def test_legacy_plaintext_hmac_and_version_downgrade_reject(self):
        legacy = b'{"payload":"eyJ2IjoxfQ==","mac":"' + b'0'*64 + b'"}'
        for wire in (legacy, b'{"v":2,"kind":"hello"}', raw_envelope(b'{"v":1}'),
                     raw_envelope(b'{"v":2}', version=1), raw_envelope(b'{"v":true}'),
                     raw_envelope(b'{"v":2.0}'), raw_envelope(b'{"v":2}', version=True)):
            with self.subTest(packet=wire[:25]), self.assertRaises(Rejected): decode(wire, KEY)

    def test_invalid_key_nonce_tag_and_envelope_fields_reject(self):
        envelope = json.loads(encode({'v': VERSION}, KEY))
        for name, value in (('nonce', base64.b64encode(bytes(8)).decode()),
                            ('tag', base64.b64encode(bytes(8)).decode()), ('tag', True),
                            ('ciphertext', ''), ('extra', 'field'), ('nonce', 'not base64')):
            altered = dict(envelope); altered[name] = value
            with self.subTest(field=name), self.assertRaises(Rejected): decode(json.dumps(altered).encode(), KEY)
        for key in (b'', b'x'*16, 'x'*32, None):
            with self.subTest(key_type=type(key).__name__), self.assertRaises(Rejected):
                decode(json.dumps(envelope).encode(), key)
            with self.assertRaises(Rejected): encode({'v': VERSION}, key)

    def test_duplicate_outer_and_inner_keys_reject(self):
        wire = encode({'v': VERSION}, KEY)
        outer_duplicate = wire[:-1] + b',"v":2}'
        for bad in (outer_duplicate, raw_envelope(b'{"v":2,"v":2}')):
            with self.assertRaises(Rejected): decode(bad, KEY)

    def test_deep_invalid_packet_then_valid_packet_survives(self):
        session = Session(KEY, PEER[0], Limits(41, -87))
        for bad in (b'['*2047+b'0'+b']'*2047, b'\xff', b'x'*4097,
                    raw_envelope(b'{"v":2,"x":'+b'['*20+b'0'+b']'*20+b'}')):
            with self.assertRaises(Rejected): session.accept(bad, PEER, NOW, 100)
        hello = {'v': VERSION, 'kind': 'hello', 'client_nonce': '01'*16, 'sent_ms': NOW}
        self.assertEqual(decode(session.accept(encode(hello, KEY), PEER, NOW, 100), KEY)['kind'], 'challenge')

    def test_brackets_inside_strings_are_not_nesting(self):
        payload = {'v': VERSION, 'text': '['*30 + '\\"' + ']'*30}
        self.assertEqual(decode(encode(payload, KEY), KEY), payload)

    def test_oversized_plaintext_or_encrypted_packet_reject(self):
        for value in ('x'*4000, 'x'*5000):
            with self.assertRaises(Rejected): encode({'v': VERSION, 'x': value}, KEY)

    def test_huge_authenticated_numeric_value_rejects_without_listener_exit(self):
        session = Session(KEY, PEER[0], Limits(41, -87))
        hello = {'v': VERSION, 'kind': 'hello', 'client_nonce': '01'*16, 'sent_ms': NOW}
        challenge = decode(session.accept(encode(hello, KEY), PEER, NOW, 100), KEY)
        position = {'v': VERSION, 'kind': 'position', 'client_nonce': '01'*16,
            'relay_nonce': challenge['relay_nonce'], 'sequence': 1, 'sent_ms': NOW,
            'fix_ms': NOW, 'lat': 10**1000, 'lon': -87, 'accuracy_m': 3, 'speed_mps': 0}
        reply = decode(session.accept(encode(position, KEY), PEER, NOW, 100), KEY)
        self.assertEqual(reply['status'], 'rejected')
        position.update(sequence=2, lat=41)
        reply = decode(session.accept(encode(position, KEY), PEER, NOW, 100), KEY)
        self.assertEqual(reply['status'], 'accepted')


if __name__ == '__main__': unittest.main(verbosity=2)
