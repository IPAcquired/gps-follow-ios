"""Save a reproducible test report. Executes only offline tests; never starts relay."""
import contextlib
import datetime
import hashlib
import io
import json
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "relay"))
sys.path.insert(0, str(ROOT.parent.parent / "work" / "serial-deps"))


def main():
    suite = unittest.defaultTestLoader.discover(str(ROOT / "relay"), pattern="test_*.py")
    stream = io.StringIO()
    with contextlib.redirect_stdout(stream), contextlib.redirect_stderr(stream):
        result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    ci_path = ROOT / "ci-validation.json"
    ci_report = json.loads(ci_path.read_text(encoding="utf-8")) if ci_path.is_file() else None
    if ci_report:
        for name, expected in ci_report.get("source_sha256", {}).items():
            if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != expected:
                raise RuntimeError("CI verification is stale; rerun ci/verify_workflow.py before aggregating its report")
        if not ci_report.get("source_sha256"):
            raise RuntimeError("CI verification needs source hashes; rerun ci/verify_workflow.py")
    ci_count = ci_report.get("tests_run", 0) if ci_report else 0
    successful = result.wasSuccessful() and (ci_report is None or ci_report.get("successful") is True)
    report = {"checked_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "tests_run": result.testsRun + ci_count, "protocol_project_tests_run": result.testsRun,
        "workflow_tests_run": ci_count, "ci_checked_utc": ci_report.get("checked_utc") if ci_report else None,
        "successful": successful,
        "failures": len(result.failures) + (ci_report.get("failures", 0) if ci_report else 0),
        "errors": len(result.errors) + (ci_report.get("errors", 0) if ci_report else 0),
        "skipped": len(result.skipped),
        "scope": "offline protocol/codec/lifecycle/Xcode-structure tests plus hash-matched workflow verification report; no native build",
        "ios_compiled": False, "swift_tests_executed": False, "iphone_installed": False,
        "hardware_opened": False, "network_listener_started": False,
        "python_version": sys.version,
        "source_sha256": {str(p.relative_to(ROOT)).replace("\\", "/"): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(ROOT.rglob("*")) if p.is_file() and "__pycache__" not in p.parts
            and p.name not in {"validation.json", "validation.txt"}},
        "test_output": stream.getvalue(), "ci_test_output": ci_report.get("test_output") if ci_report else None}
    (ROOT / "validation.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    (ROOT / "validation.txt").write_text(stream.getvalue(), encoding="utf-8")
    print(f"{result.testsRun + ci_count} offline checks ({result.testsRun} protocol/project + {ci_count} workflow): {'PASS' if successful else 'FAIL'}")
    print("Native iOS compilation, Swift execution and phone installation remain unverified.")
    return 0 if successful else 1


if __name__ == "__main__": raise SystemExit(main())
