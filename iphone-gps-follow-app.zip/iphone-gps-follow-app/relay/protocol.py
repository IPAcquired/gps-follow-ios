"""Encrypted authenticated GPS-only transport. No hardware or sockets are opened by import."""
from __future__ import annotations

import base64
import ipaddress
import json
import math
import secrets
from dataclasses import asdict, dataclass
from typing import Any
from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

VERSION = 2
AAD = b"GPSFollow/phone-pc/v2/aes-256-gcm"
MAX_JSON_DEPTH = 16
MAX_DATAGRAM_BYTES = 4096
EXPECTED_BOARD_UID = "1c0032000d51343436353634000000000000"
TARGET_SYSTEM_ID = 42
TARGET_COMPONENT_ID = 191  # MAV_COMP_ID_ONBOARD_COMPUTER
RFC1918 = tuple(ipaddress.ip_network(s) for s in ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16"))


class Rejected(ValueError):
    """A packet/configuration was not safe to accept."""


def local_ipv4(value: str) -> str:
    try:
        address = ipaddress.IPv4Address(value)
    except (ValueError, TypeError) as exc:
        raise Rejected("Use a numeric private IPv4 address") from exc
    if not any(address in net for net in RFC1918):
        raise Rejected("Use a unicast address on your private Wi-Fi network")
    if int(address) & 255 in (0, 255):
        raise Rejected("Do not use a network or broadcast address")
    return str(address)


def finite_number(value: Any, label: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise Rejected(f"Invalid {label}")
    try:
        number = float(value)
    except (OverflowError, ValueError) as exc:
        raise Rejected(f"Invalid {label}") from exc
    if not math.isfinite(number):
        raise Rejected(f"Invalid {label}")
    return number


def integer(value: Any, label: str, minimum: int = 0, maximum: int = 2**53 - 1) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or not minimum <= value <= maximum:
        raise Rejected(f"Invalid {label}")
    return value


def nonce(value: Any) -> str:
    if not isinstance(value, str) or len(value) != 32:
        raise Rejected("Invalid session nonce")
    try:
        bytes.fromhex(value)
    except ValueError as exc:
        raise Rejected("Invalid session nonce") from exc
    if value != value.lower():
        raise Rejected("Invalid session nonce")
    return value


def coordinates(lat: Any, lon: Any) -> tuple[float, float]:
    lat = finite_number(lat, "latitude")
    lon = finite_number(lon, "longitude")
    if not -85 <= lat <= 85 or not -180 <= lon <= 180 or (lat == 0 and lon == 0):
        raise Rejected("Position outside supported coordinate range")
    return lat, lon


def distance_m(a_lat: float, a_lon: float, b_lat: float, b_lon: float) -> float:
    p1, p2 = math.radians(a_lat), math.radians(b_lat)
    dlat, dlon = p2 - p1, math.radians(b_lon - a_lon)
    hav = math.sin(dlat / 2)**2 + math.cos(p1)*math.cos(p2)*math.sin(dlon / 2)**2
    return 6371000.0 * 2 * math.asin(math.sqrt(max(0.0, min(1.0, hav))))


def pairing_key(hex_key: str) -> bytes:
    if not isinstance(hex_key, str) or len(hex_key) != 64:
        raise Rejected("Pairing key must contain 64 hexadecimal characters")
    try:
        result = bytes.fromhex(hex_key)
    except ValueError as exc:
        raise Rejected("Pairing key must contain 64 hexadecimal characters") from exc
    if len(result) != 32:
        raise Rejected("Pairing key must contain 64 hexadecimal characters")
    return result


def _bounded_json(data: bytes) -> dict[str, Any]:
    # Bound nesting before either runtime's JSON parser. Ignore brackets inside strings.
    depth = 0
    quoted = escaped = False
    for byte in data:
        if quoted:
            if escaped:
                escaped = False
            elif byte == 92:
                escaped = True
            elif byte == 34:
                quoted = False
        elif byte == 34:
            quoted = True
        elif byte in (91, 123):
            depth += 1
            if depth > MAX_JSON_DEPTH:
                raise Rejected("JSON nesting exceeds packet limit")
        elif byte in (93, 125):
            depth -= 1
            if depth < 0:
                raise Rejected("Malformed encrypted packet")
    value = json.loads(data, object_pairs_hook=_unique_object)
    if not isinstance(value, dict):
        raise Rejected("Packet must contain a JSON object")
    return value


def _key(key: bytes) -> bytes:
    if not isinstance(key, bytes) or len(key) != 32:
        raise Rejected("Encryption requires a 32-byte pairing key")
    return key


def _is_version(value: Any) -> bool:
    return not isinstance(value, bool) and isinstance(value, int) and value == VERSION


def encode(payload: dict[str, Any], key: bytes) -> bytes:
    if not isinstance(payload, dict) or not _is_version(payload.get("v")):
        raise Rejected("Unsupported encrypted protocol version")
    body = json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
    if len(body) > MAX_DATAGRAM_BYTES:
        raise Rejected("Invalid plaintext size")
    _bounded_json(body)
    # Random nonces are generated for every packet in both directions; never supplied by callers.
    iv = secrets.token_bytes(12)
    sealed = AESGCM(_key(key)).encrypt(iv, body, AAD)
    wire = json.dumps({"v": VERSION, "nonce": base64.b64encode(iv).decode("ascii"),
                       "ciphertext": base64.b64encode(sealed[:-16]).decode("ascii"),
                       "tag": base64.b64encode(sealed[-16:]).decode("ascii")},
                      sort_keys=True, separators=(",", ":")).encode("utf-8")
    if len(wire) > MAX_DATAGRAM_BYTES:
        raise Rejected("Invalid encrypted datagram size")
    return wire


def _unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for name, value in pairs:
        if name in result:
            raise Rejected("Duplicate JSON field")
        result[name] = value
    return result


def _base64(value: Any) -> bytes:
    if not isinstance(value, str):
        raise Rejected("Invalid encrypted envelope")
    decoded = base64.b64decode(value, validate=True)
    if base64.b64encode(decoded).decode("ascii") != value:
        raise Rejected("Non-canonical encrypted envelope")
    return decoded


def decode(data: bytes, key: bytes) -> dict[str, Any]:
    if not isinstance(data, bytes) or not data or len(data) > MAX_DATAGRAM_BYTES:
        raise Rejected("Invalid datagram size")
    try:
        envelope = _bounded_json(data)
        if set(envelope) != {"v", "nonce", "ciphertext", "tag"} or not _is_version(envelope["v"]):
            raise Rejected("Unsupported encrypted envelope")
        iv, ciphertext, tag = (_base64(envelope[name]) for name in ("nonce", "ciphertext", "tag"))
        if len(iv) != 12 or len(tag) != 16 or not ciphertext:
            raise Rejected("Invalid encrypted nonce, body or tag size")
        body = AESGCM(_key(key)).decrypt(iv, ciphertext + tag, AAD)
        payload = _bounded_json(body)
        if not _is_version(payload.get("v")):
            raise Rejected("Unsupported encrypted protocol version")
        return payload
    except (InvalidTag, UnicodeDecodeError, ValueError, TypeError, KeyError, RecursionError, OverflowError) as exc:
        if isinstance(exc, Rejected):
            raise
        raise Rejected("Malformed or unauthenticated encrypted packet") from exc


@dataclass(frozen=True)
class Limits:
    origin_lat: float
    origin_lon: float
    radius_m: float = 50.0
    max_accuracy_m: float = 8.0
    max_speed_mps: float = 3.0
    max_fix_age_s: float = 1.0
    max_clock_skew_s: float = 2.0
    loss_timeout_s: float = 1.0
    send_hz: float = 5.0
    hover_height_m: float = 5.0

    def __post_init__(self) -> None:
        coordinates(self.origin_lat, self.origin_lon)
        ranges = {
            "radius_m": (5, 200), "max_accuracy_m": (1, 10),
            "max_speed_mps": (0.5, 5), "max_fix_age_s": (0.2, 1),
            "max_clock_skew_s": (0.2, 2), "loss_timeout_s": (0.2, 1),
            "send_hz": (1, 5), "hover_height_m": (2, 20),
        }
        for field, (minimum, maximum) in ranges.items():
            value = finite_number(getattr(self, field), field)
            if not minimum <= value <= maximum:
                raise Rejected(f"{field} must be between {minimum} and {maximum}")


@dataclass(frozen=True)
class Sample:
    sequence: int
    lat: float
    lon: float
    accuracy_m: float
    fix_ms: int
    received_mono: float


class Session:
    """One explicitly selected phone. Epoch checks are additional to monotonic loss checks."""

    def __init__(self, key: bytes, phone_ip: str, limits: Limits):
        self.key = key
        self.phone_ip = local_ipv4(phone_ip)
        self.limits = limits
        self.client_nonce: str | None = None
        self.relay_nonce: str | None = None
        self.peer: tuple[str, int] | None = None
        self.last_sequence = 0
        self.latest: Sample | None = None
        self.previous: Sample | None = None
        self.used_client_nonces: set[str] = set()
        self.last_publish_mono = -math.inf

    def _base(self, kind: str, now_ms: int) -> dict[str, Any]:
        return {"v": VERSION, "kind": kind, "client_nonce": self.client_nonce,
                "relay_nonce": self.relay_nonce, "sent_ms": now_ms}

    def accept(self, data: bytes, peer: tuple[str, int], now_ms: int,
               now_mono: float, serial_ready: bool = True) -> bytes:
        if peer[0] != self.phone_ip:
            raise Rejected("Phone address does not match selected peer")
        message = decode(data, self.key)
        sent_ms = integer(message.get("sent_ms"), "sender timestamp")
        if abs(now_ms - sent_ms) > self.limits.max_clock_skew_s * 1000:
            raise Rejected("Phone/relay clocks differ or packet is old")
        client_nonce = nonce(message.get("client_nonce"))
        kind = message.get("kind")
        if kind == "hello":
            if self.client_nonce == client_nonce and self.peer == peer:
                return encode({**self._base("challenge", now_ms), "limits": asdict(self.limits)}, self.key)
            if client_nonce in self.used_client_nonces:
                raise Rejected("Replayed session request")
            if len(self.used_client_nonces) >= 1024:
                raise Rejected("Restart relay to establish more sessions")
            self.used_client_nonces.add(client_nonce)
            self.client_nonce, self.relay_nonce = client_nonce, secrets.token_hex(16)
            self.peer = peer
            self.last_sequence = 0
            self.latest = None
            return encode({**self._base("challenge", now_ms), "limits": asdict(self.limits)}, self.key)
        if (peer != self.peer or client_nonce != self.client_nonce
                or nonce(message.get("relay_nonce")) != self.relay_nonce):
            raise Rejected("Pair this phone session first")
        sequence = integer(message.get("sequence"), "sequence", minimum=1)
        if sequence <= self.last_sequence:
            raise Rejected("Old or reordered sequence")
        # Consume even rejected authenticated sequences; they cannot be retried out of order.
        self.last_sequence = sequence
        response = self._base("ack", now_ms)
        response.update(sequence=sequence, serial_ready=serial_ready)
        if kind == "stop":
            self.latest = None
            response.update(status="stopped", reason="GPS sharing stopped")
            return encode(response, self.key)
        if kind != "position":
            raise Rejected("Unsupported packet kind")
        try:
            sample = self._validate_position(message, now_ms, now_mono)
            self.latest = self.previous = sample
            response.update(status="accepted", reason="Fresh target accepted")
        except Rejected as exc:
            # Invalid incoming source data immediately suppresses the cached target.
            self.latest = None
            response.update(status="rejected", reason=str(exc))
        return encode(response, self.key)

    def _validate_position(self, message: dict[str, Any], now_ms: int, now_mono: float) -> Sample:
        lat, lon = coordinates(message.get("lat"), message.get("lon"))
        accuracy = finite_number(message.get("accuracy_m"), "horizontal accuracy")
        if not 0 < accuracy <= self.limits.max_accuracy_m:
            raise Rejected("GPS accuracy is too low")
        fix_ms = integer(message.get("fix_ms"), "GPS timestamp")
        # Future fixes are rejected, allowing only 100 ms of scheduling/clock roundoff.
        if not -100 <= now_ms - fix_ms <= self.limits.max_fix_age_s * 1000:
            raise Rejected("GPS fix is old or in the future")
        if message["sent_ms"] < fix_ms - 100:
            raise Rejected("GPS fix is newer than its packet")
        speed = finite_number(message.get("speed_mps"), "GPS speed")
        if not -1 <= speed <= self.limits.max_speed_mps:
            raise Rejected("Speed exceeds walking limit")
        if distance_m(self.limits.origin_lat, self.limits.origin_lon, lat, lon) > self.limits.radius_m:
            raise Rejected("Outside the configured operating radius")
        if self.previous:
            if fix_ms < self.previous.fix_ms:
                raise Rejected("GPS timestamp moved backward")
            distance = distance_m(self.previous.lat, self.previous.lon, lat, lon)
            dt = (fix_ms - self.previous.fix_ms) / 1000.0
            if dt == 0 and distance > 0.05:
                raise Rejected("Same GPS timestamp changed position")
            # Bounded uncertainty allowance avoids unbounded jumps from poor fixes.
            allowance = 3.0 + min(6.0, accuracy + self.previous.accuracy_m)
            if distance > allowance + self.limits.max_speed_mps * dt:
                raise Rejected("GPS position jumped too far")
        return Sample(message["sequence"], lat, lon, accuracy, fix_ms, now_mono)

    def publishable(self, now_ms: int, now_mono: float) -> Sample | None:
        if not self.latest:
            return None
        if (now_mono - self.latest.received_mono > self.limits.loss_timeout_s
                or not -100 <= now_ms - self.latest.fix_ms <= self.limits.max_fix_age_s * 1000):
            self.latest = None
            return None
        if now_mono - self.last_publish_mono < 1.0 / self.limits.send_hz:
            return None
        self.last_publish_mono = now_mono
        return self.latest


def target_fields(sample: Sample, relay_uptime_s: float) -> tuple[int, ...]:
    """GLOBAL_POSITION_INT: home-relative zero, no phone altitude, no extrapolation."""
    return (int(relay_uptime_s * 1000) & 0xffffffff,
            round(sample.lat * 1e7), round(sample.lon * 1e7),
            0, 0, 0, 0, 0, 65535)


def required_follow_parameters(height_m: float) -> dict[str, float]:
    return {"FOLL_ENABLE": 1.0, "FOLL_SYSID": 42.0, "FOLL_ALT_TYPE": 1.0,
            "FOLL_OFS_TYPE": 0.0, "FOLL_OFS_X": 0.0, "FOLL_OFS_Y": 0.0, "FOLL_OFS_Z": -height_m}


def parameters_ready(values: dict[str, float], limits: Limits) -> tuple[bool, str]:
    for name, expected in required_follow_parameters(limits.hover_height_m).items():
        if name not in values:
            return False, f"Readback missing: {name}"
        if not math.isfinite(values[name]) or abs(values[name] - expected) > 0.01:
            return False, f"Readback mismatch: {name}; expected {expected:g}"
    maximum = values.get("FOLL_DIST_MAX", 0)
    if not math.isfinite(maximum) or not 5 <= maximum <= limits.radius_m:
        return False, "FOLL_DIST_MAX must be positive and within the configured operating radius"
    timeout = values.get("FOLL_TIMEOUT", 0)
    if not math.isfinite(timeout) or not 0.5 <= timeout <= 3:
        return False, "FOLL_TIMEOUT readback must be between 0.5 and 3 seconds"
    if values.get("FOLL_YAW_BEHAVE") not in (0.0, 1.0):
        return False, "FOLL_YAW_BEHAVE must be 0 (none) or 1 (face target)"
    return True, "Follow readback matches explicit setup"
