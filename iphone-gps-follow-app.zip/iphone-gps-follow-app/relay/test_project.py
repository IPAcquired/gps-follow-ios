"""Offline structure checks; these are deliberately NOT an iOS compilation."""
import json
from pathlib import Path
import plistlib
import re
import unittest
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent.parent
IOS = ROOT / "iOS"


class OpenStep:
    def __init__(self, text):
        text = re.sub(r"/\*.*?\*/|//[^\n]*", "", text, flags=re.S)
        self.tokens = re.findall(r'"(?:\\.|[^"\\])*"|[{}()=;,]|[^\s{}()=;,]+', text)
        self.index = 0

    def take(self):
        value = self.tokens[self.index]
        self.index += 1
        return value

    def expect(self, token):
        actual = self.take()
        if actual != token: raise ValueError(f"Expected {token}, received {actual}")

    def value(self):
        token = self.take()
        if token == "{":
            result = {}
            while self.tokens[self.index] != "}":
                key = self.take(); self.expect("=")
                if key.startswith('"'): key = json.loads(key)
                if key in result: raise ValueError("Duplicate project object key")
                result[key] = self.value(); self.expect(";")
            self.expect("}")
            return result
        if token == "(":
            result = []
            while self.tokens[self.index] != ")":
                result.append(self.value())
                if self.tokens[self.index] == ",": self.take()
                elif self.tokens[self.index] != ")": raise ValueError("Invalid list")
            self.expect(")")
            return result
        return json.loads(token) if token.startswith('"') else token


class ProjectStructureTests(unittest.TestCase):
    def setUp(self):
        parser = OpenStep((IOS / "GPSFollow.xcodeproj" / "project.pbxproj").read_text())
        self.project = parser.value()
        self.assertEqual(parser.index, len(parser.tokens))
        self.objects = self.project["objects"]

    def test_all_project_object_references_exist(self):
        def walk(value):
            if isinstance(value, dict):
                for item in value.values(): walk(item)
            elif isinstance(value, list):
                for item in value: walk(item)
            elif isinstance(value, str) and re.fullmatch(r"[A-F0-9]{24}", value):
                self.assertIn(value, self.objects)
        walk(self.project)

    def test_source_and_resource_paths_exist(self):
        for item in self.objects.values():
            if item.get("isa") != "PBXGroup" or "path" not in item: continue
            for child in item["children"]:
                reference = self.objects[child]
                if reference.get("isa") == "PBXFileReference":
                    path = IOS / item["path"] / reference["path"]
                    if reference.get("lastKnownFileType") == "folder.assetcatalog":
                        self.assertTrue(path.is_dir(), reference["path"])
                        self.assertTrue((path / "Contents.json").is_file())
                    else:
                        self.assertTrue(path.is_file(), reference["path"])

    def test_nw_app_icon_is_opaque1024_and_in_resources(self):
        icon = IOS / 'GPSFollow/Assets.xcassets/AppIcon.appiconset'
        definition = json.loads((icon / 'Contents.json').read_bytes())
        self.assertEqual(definition['images'], [{'filename': 'NW-AppIcon.png', 'idiom': 'universal', 'platform': 'ios', 'size': '1024x1024'}])
        png = (icon / 'NW-AppIcon.png').read_bytes()
        self.assertEqual(png[:8], b'\x89PNG\r\n\x1a\n')
        self.assertEqual(png[12:16], b'IHDR')
        self.assertEqual(int.from_bytes(png[16:20], 'big'), 1024)
        self.assertEqual(int.from_bytes(png[20:24], 'big'), 1024)
        self.assertEqual(png[25], 2)  # RGB without an alpha channel.
        resources = self.objects['A40000000000000000000003']['files']
        refs = [self.objects[self.objects[item]['fileRef']]['path'] for item in resources]
        self.assertIn('Assets.xcassets', refs)
        for identity in ['A90000000000000000000003', 'A90000000000000000000004']:
            self.assertEqual(self.objects[identity]['buildSettings']['ASSETCATALOG_COMPILER_APPICON_NAME'], 'AppIcon')

    def test_scheme_builds_app_and_runs_tests(self):
        scheme = ET.parse(IOS / "GPSFollow.xcodeproj" / "xcshareddata" / "xcschemes" / "GPSFollow.xcscheme")
        references = scheme.findall(".//BuildableReference")
        self.assertTrue(any(x.attrib["BuildableName"] == "GPSFollow.app" for x in references))
        self.assertTrue(any(x.attrib["BuildableName"] == "GPSFollowTests.xctest" for x in references))
        for reference in references: self.assertIn(reference.attrib["BlueprintIdentifier"], self.objects)

    def test_foreground_privacy_configuration(self):
        with (IOS / "GPSFollow" / "Info.plist").open("rb") as file:
            plist = plistlib.load(file)
        self.assertIn("NSLocationWhenInUseUsageDescription", plist)
        self.assertIn("NSLocalNetworkUsageDescription", plist)
        self.assertNotIn("UIBackgroundModes", plist)
        self.assertNotIn("NSLocationAlwaysAndWhenInUseUsageDescription", plist)

    def test_public_source_does_not_embed_private_controller_identity(self):
        personal_uid = "1c0032000d513434" + "36353634000000000000"
        personal_bluetooth_name = "MicoAir743v2" + "-09858"
        for path in ROOT.rglob("*"):
            if not path.is_file() or path.suffix.lower() not in {".swift", ".py", ".md", ".json", ".plist"}:
                continue
            text = path.read_text(encoding="utf-8", errors="ignore")
            self.assertNotIn(personal_uid, text, str(path.relative_to(ROOT)))
            self.assertNotIn(personal_bluetooth_name, text, str(path.relative_to(ROOT)))

    def test_app_transmission_has_no_flight_control_or_estimator_commands(self):
        swift = "\n".join(p.read_text() for p in (IOS / "GPSFollow").glob("*.swift"))
        outgoing = set(map(int, re.findall(r"signer\.packet\(id:\s*(\d+)", swift)))
        self.assertEqual(outgoing, {0, 20, 33, 76})
        # The only COMMAND_LONG is an AUTOPILOT_VERSION diagnostic request.
        self.assertIn("little(512, count: 2)", swift)
        self.assertIn("Float(148).bitPattern", swift)
        for forbidden in ("GPS_INPUT", "HIL_GPS", "GPS_RAW_INT", "SETUP_SIGNING", "param_set_send", "MAV_CMD_COMPONENT_ARM_DISARM"):
            self.assertNotIn(forbidden, swift)
        self.assertIn("manager.allowsBackgroundLocationUpdates = false", swift)
        self.assertIn("if phase == .background", swift)

    def test_help_explains_degraded_lidar_without_disabling_core_failsafes(self):
        help_source = (IOS / "GPSFollow" / "GPSFollowApp.swift").read_text()
        for fact in (
            "marked unavailable and excluded from that direction",
            "never changed into a fake near obstacle or fake clear path",
            "Stabilize and AltHold remain pilot-controlled",
            "does not bypass GPS, compass, receiver, EKF or battery failsafes",
        ):
            self.assertIn(fact, help_source)

    def test_new_native_files_are_in_correct_build_phases(self):
        sources = self.objects["A40000000000000000000001"]["files"]
        tests = self.objects["A40000000000000000000004"]["files"]
        self.assertTrue(set(["B10000000000000000000001", "B10000000000000000000002", "B10000000000000000000003"]).issubset(sources))
        self.assertIn("B10000000000000000000004", tests)
        self.assertNotIn("B10000000000000000000004", sources)

    def test_local_cad_storage_and_no_new_background_camera_bluetooth_permissions(self):
        plist = plistlib.loads((IOS / "GPSFollow" / "Info.plist").read_bytes())
        self.assertTrue(plist["UIFileSharingEnabled"])
        self.assertTrue(plist["LSSupportsOpeningDocumentsInPlace"])
        self.assertFalse(set(plist).intersection({"NSCameraUsageDescription", "NSBluetoothAlwaysUsageDescription", "UIBackgroundModes"}))
        views = (IOS / "GPSFollow" / "CADViews.swift").read_text()
        self.assertIn("ShareLink(item: item.url)", views)
        self.assertIn("G-code upload and print-start controls are not enabled here", views)
        self.assertNotIn("URLSession", views)


if __name__ == "__main__": unittest.main(verbosity=2)
