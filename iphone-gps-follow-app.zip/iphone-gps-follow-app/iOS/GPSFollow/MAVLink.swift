import Foundation
import CryptoKit

struct MAVMessage {
    let system: UInt8
    let component: UInt8
    let id: UInt32
    let payload: [UInt8]
}

enum MAVLink {
    static let system: UInt8 = 42
    static let component: UInt8 = 191
    static let expectedUID = "1c0032000d51343436353634000000000000"
    static let crcExtras: [UInt32: UInt8] = [0: 50, 20: 214, 22: 220, 33: 104, 76: 152, 77: 143, 148: 178]

    static func crc(_ bytes: [UInt8], extra: UInt8) -> UInt16 {
        var result: UInt16 = 0xffff
        for byte in bytes + [extra] {
            var tmp = UInt16(byte) ^ (result & 0xff)
            tmp ^= (tmp << 4) & 0xff
            result = (result >> 8) ^ (tmp << 8) ^ (tmp << 3) ^ (tmp >> 4)
        }
        return result
    }

    static func unsignedPacket(id: UInt32, payload: [UInt8], sequence: UInt8,
                               signed: Bool = false) -> [UInt8] {
        precondition(payload.count <= 255 && crcExtras[id] != nil)
        let header: [UInt8] = [0xfd, UInt8(payload.count), signed ? 1 : 0, 0,
                             sequence, system, component,
                             UInt8(id & 0xff), UInt8((id >> 8) & 0xff), UInt8((id >> 16) & 0xff)]
        let check = crc(Array(header.dropFirst()) + payload, extra: crcExtras[id]!)
        return header + payload + little(UInt64(check), count: 2)
    }

    static func signedPacket(id: UInt32, payload: [UInt8], sequence: UInt8,
                             key: Data, linkID: UInt8, timestamp: UInt64) -> Data {
        precondition(key.count == 32 && timestamp < (1 << 48))
        let packet = unsignedPacket(id: id, payload: payload, sequence: sequence, signed: true)
        let suffix = [linkID] + little(timestamp, count: 6)
        let digest = SHA256.hash(data: key + Data(packet + suffix))
        return Data(packet + suffix + Array(digest.prefix(6)))
    }

    static func little(_ value: UInt64, count: Int) -> [UInt8] {
        (0..<count).map { UInt8((value >> (8 * $0)) & 0xff) }
    }

    static func u16(_ bytes: [UInt8], _ offset: Int) -> UInt16 {
        UInt16(bytes[offset]) | (UInt16(bytes[offset + 1]) << 8)
    }
    static func u32(_ bytes: [UInt8], _ offset: Int) -> UInt32 {
        UInt32(bytes[offset]) | (UInt32(bytes[offset + 1]) << 8) |
        (UInt32(bytes[offset + 2]) << 16) | (UInt32(bytes[offset + 3]) << 24)
    }
    static func u48(_ bytes: [UInt8], _ offset: Int) -> UInt64 {
        (0..<6).reduce(0) { $0 | (UInt64(bytes[offset + $1]) << (8 * $1)) }
    }

    static func heartbeat() -> [UInt8] {
        // A separate lead target, not the aircraft or a flight controller.
        little(0, count: 4) + [10, 8, 0, 4, 3] // Ground rover, invalid autopilot, active.
    }

    static func position(lat: Double, lon: Double, uptimeMS: UInt32) -> [UInt8] {
        let latInt = Int32((lat * 1e7).rounded())
        let lonInt = Int32((lon * 1e7).rounded())
        return little(UInt64(uptimeMS), count: 4) +
            little(UInt64(UInt32(bitPattern: latInt)), count: 4) +
            little(UInt64(UInt32(bitPattern: lonInt)), count: 4) +
            Array(repeating: 0, count: 14) + [0xff, 0xff]
        // alt=0, relative_alt=0, vx=vy=vz=0, heading unknown; no phone height.
    }

    static func requestVersion(system: UInt8, component: UInt8) -> [UInt8] {
        let first = little(UInt64(Float(148).bitPattern), count: 4)
        return first + Array(repeating: 0, count: 24) +
            little(512, count: 2) + [system, component, 0]
    }

    static func requestParameter(_ name: String, system: UInt8, component: UInt8) -> [UInt8] {
        var field = Array(name.utf8.prefix(16))
        field += Array(repeating: 0, count: 16 - field.count)
        return [0xff, 0xff, system, component] + field
    }

    static func hex(_ data: Data) -> String { data.map { String(format: "%02x", $0) }.joined() }
    static func key(_ hex: String) -> Data? {
        let text = hex.trimmingCharacters(in: .whitespacesAndNewlines)
        guard text.count == 64 else { return nil }
        var result = Data()
        var index = text.startIndex
        while index < text.endIndex {
            let next = text.index(index, offsetBy: 2)
            guard let byte = UInt8(text[index..<next], radix: 16) else { return nil }
            result.append(byte)
            index = next
        }
        return result
    }
    static func constantTimeEqual(_ a: [UInt8], _ b: [UInt8]) -> Bool {
        guard a.count == b.count else { return false }
        return zip(a, b).reduce(UInt8(0)) { $0 | ($1.0 ^ $1.1) } == 0
    }
}

final class MAVSigner {
    let key: Data
    let linkID: UInt8 = 43
    private var sequence: UInt8 = 0
    private var lastSent: UInt64
    private var streams: [String: UInt64] = [:]
    private var sentPackets: [Data] = []
    private let storagePrefix: String
    static let epoch2015: TimeInterval = 1_420_070_400

    init(key: Data) {
        self.key = key
        storagePrefix = "gpsfollow.signing." + MAVLink.hex(Data(SHA256.hash(data: key).prefix(8)))
        lastSent = (UserDefaults.standard.object(forKey: storagePrefix + ".sent") as? NSNumber)?.uint64Value ?? 0
    }

    static func timestamp(now: Date = Date()) -> UInt64 {
        UInt64(max(0, now.timeIntervalSince1970 - epoch2015) * 100_000)
    }

    func packet(id: UInt32, payload: [UInt8]) -> Data {
        lastSent = max(lastSent + 1, Self.timestamp())
        UserDefaults.standard.set(NSNumber(value: lastSent), forKey: storagePrefix + ".sent")
        let result = MAVLink.signedPacket(id: id, payload: payload, sequence: sequence,
                                        key: key, linkID: linkID, timestamp: lastSent)
        sequence &+= 1
        sentPackets.append(result)
        if sentPackets.count > 128 { sentPackets.removeFirst() }
        return result
    }

    func decode(_ data: Data) -> [MAVMessage] {
        let bytes = Array(data)
        var cursor = 0
        var messages: [MAVMessage] = []
        while cursor + 12 <= bytes.count {
            guard bytes[cursor] == 0xfd else { cursor += 1; continue }
            let length = Int(bytes[cursor + 1])
            let flags = bytes[cursor + 2]
            let fullLength = 12 + length + ((flags & 1) != 0 ? 13 : 0)
            guard cursor + fullLength <= bytes.count else { break }
            defer { cursor += fullLength }
            // This app requires MAVLink 2 signing for its direct network transport.
            guard flags == 1 else { continue }
            let wholePacket = Data(bytes[cursor..<(cursor + fullLength)])
            if sentPackets.contains(wholePacket) { continue } // Only exact self echoes are ignored.
            let packet = Array(bytes[cursor..<(cursor + 12 + length)])
            let id = UInt32(packet[7]) | (UInt32(packet[8]) << 8) | (UInt32(packet[9]) << 16)
            guard let extra = MAVLink.crcExtras[id] else { continue }
            let check = MAVLink.crc(Array(packet[1..<(10 + length)]), extra: extra)
            guard check == MAVLink.u16(packet, 10 + length) else { continue }
            let suffixStart = cursor + 12 + length
            let suffix = Array(bytes[suffixStart..<(suffixStart + 7)])
            let signature = Array(bytes[(suffixStart + 7)..<(suffixStart + 13)])
            let digest = Array(SHA256.hash(data: key + Data(packet + suffix)).prefix(6))
            guard MAVLink.constantTimeEqual(signature, digest) else { continue }
            let stamp = MAVLink.u48(suffix, 1)
            let stream = "\(packet[5]).\(packet[6]).\(suffix[0])"
            let persisted = (UserDefaults.standard.object(forKey: storagePrefix + ".rx." + stream) as? NSNumber)?.uint64Value ?? 0
            let previous = streams[stream] ?? persisted
            guard stamp > previous else { continue }
            let clock = Self.timestamp()
            // Also refuse old recordings/future signing clocks (60 seconds).
            let distance = clock > stamp ? clock - stamp : stamp - clock
            guard distance <= 6_000_000 else { continue }
            streams[stream] = stamp
            UserDefaults.standard.set(NSNumber(value: stamp), forKey: storagePrefix + ".rx." + stream)
            lastSent = max(lastSent, stamp)
            UserDefaults.standard.set(NSNumber(value: lastSent), forKey: storagePrefix + ".sent")
            var payload = Array(packet[10..<(10 + length)])
            // MAVLink 2 legitimately truncates zero-valued extension bytes.
            let expectedLengths: [UInt32: Int] = [0: 9, 22: 25, 148: 78]
            if let expected = expectedLengths[id], payload.count < expected {
                payload += Array(repeating: 0, count: expected - payload.count)
            }
            messages.append(MAVMessage(system: packet[5], component: packet[6], id: id, payload: payload))
        }
        return messages
    }
}
