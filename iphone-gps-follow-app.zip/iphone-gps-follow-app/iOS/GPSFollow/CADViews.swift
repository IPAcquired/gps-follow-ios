import SwiftUI
import UniformTypeIdentifiers

struct CADLibraryView: View {
    @ObservedObject var library: CADLibrary
    @State private var importing = false
    @State private var pendingRemoval: CADItem?

    var body: some View {
        NavigationStack {
            List {
                Section {
                    Button { importing = true } label: { Label("Add STL or 3MF", systemImage: "plus.circle.fill") }
                    Text("Save a copy from Files, AirDrop or your PC. Original files and dimensions stay unchanged. Saved locally on this iPhone and excluded from automatic backup; use Share / Save to Files to keep another copy.")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
                if library.items.isEmpty {
                    ContentUnavailableView("Your drone parts", systemImage: "cube.transparent", description: Text("Add a landing leg, battery tray or another drone design."))
                } else {
                    Section("Saved designs · \(library.items.count)") {
                        ForEach(library.items) { item in
                            VStack(alignment: .leading, spacing: 6) {
                                Text(item.name).font(.headline)
                                Text("\(item.url.pathExtension.uppercased()) · \(item.sizeText)").font(.caption).foregroundStyle(.secondary)
                                ShareLink(item: item.url) { Label("Send to PC / Save to Files / Share", systemImage: "square.and.arrow.up") }
                            }
                            .padding(.vertical, 4)
                            .swipeActions { Button("Remove", role: .destructive) { pendingRemoval = item } }
                        }
                    }
                }
                Section("Before printing") {
                    Text("Files are stored and shared unchanged. Import checks only file type, basic header and size; it does not verify mesh strength, watertightness, dimensions, supports or printer instructions.")
                    Text("Use the Printer tab for the slicing and printing steps. An STL is a model, not a ready-to-run printer job.")
                }.font(.footnote)
                if let error = library.error { Section { Text(error).foregroundStyle(.red) } }
            }
            .modifier(DroneMatrixSurface())
            .navigationTitle("Drone CAD")
            .onAppear { library.refresh() }
            .fileImporter(isPresented: $importing, allowedContentTypes: [.data], allowsMultipleSelection: false) { result in
                switch result {
                case .success(let urls):
                    guard let source = urls.first else { return }
                    do { _ = try library.importFile(source); library.error = nil }
                    catch { library.error = error.localizedDescription }
                case .failure(let error): library.error = error.localizedDescription
                }
            }
            .confirmationDialog("Remove this copy from your iPhone?", isPresented: Binding(get: { pendingRemoval != nil }, set: { if !$0 { pendingRemoval = nil } }), titleVisibility: .visible) {
                Button("Remove local copy", role: .destructive) {
                    if let item = pendingRemoval { library.remove(item) }
                    pendingRemoval = nil
                }
                Button("Cancel", role: .cancel) { pendingRemoval = nil }
            }
            .safeAreaInset(edge: .bottom) { AppBrandFooter() }
        }
    }
}

@MainActor struct PrinterView: View {
    @ObservedObject var library: CADLibrary
    @StateObject private var printer = PrinterModel()
    @State private var now = Date()
    @FocusState private var editing: Bool
    @Environment(\.scenePhase) private var scenePhase
    @State private var confirmProfileRemoval = false
    var body: some View {
        NavigationStack {
            Form {
                Section("Your Elegoo printer profiles") {
                    if !printer.profiles.isEmpty {
                        Picker("Saved printer", selection: Binding(get: { printer.profileID }, set: { printer.selectProfile($0) })) {
                            ForEach(printer.profiles) { profile in Text(profile.name).tag(profile.id) }
                        }
                    }
                    TextField("Printer name", text: $printer.profileName).focused($editing)
                    Picker("Elegoo model", selection: $printer.family) { ForEach(ElegooFamily.allCases) { Text($0.rawValue).tag($0) } }
                        .onChange(of: printer.family) { _, _ in printer.addressChanged() }
                    Button("Save profile") { editing = false; printer.saveProfile() }
                    Button("Add another Elegoo printer") { printer.addProfile() }
                    Button("Remove this profile", role: .destructive) { confirmProfileRemoval = true }
                    if !printer.family.supported { Text("Profile storage is available for this model. Its direct connection adapter is not enabled here; Carbon 2 commands will never be sent to it.").font(.footnote).foregroundStyle(.secondary) }
                }
                Section {
                    TextField("Printer Wi-Fi IP", text: $printer.ip).keyboardType(.decimalPad).focused($editing)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                        .onChange(of: printer.ip) { _, _ in printer.addressChanged() }
                    SecureField("Printer LAN access code", text: $printer.code).focused($editing)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                    Button("Find printer at this address") { editing = false; printer.discover() }.disabled(printer.busy || !printer.family.supported)
                    if let selected = printer.selected {
                        LabeledContent("Selected printer", value: selected.name)
                        LabeledContent("Model", value: selected.model)
                        LabeledContent("Serial number", value: selected.serial)
                        Button("Connect to this printer / Refresh status") { editing = false; printer.connect() }.disabled(printer.busy || !printer.family.supported)
                    }
                    if printer.busy { ProgressView("Checking direct LAN connection…") }
                    Button("Disconnect", role: .destructive) { printer.disconnect() }
                    if let error = printer.error { Text(error).foregroundStyle(.red) }
                } header: {
                    Text("Direct iPhone → Carbon 2 · same Wi-Fi")
                } footer: {
                    Text("Enter the address shown on the printer. Finding uses one selected address, not a network scan. Verify its serial before connecting. The vendor’s LAN connection uses an access code but plain HTTP/MQTT, so use a trusted private Wi-Fi; this printer link is not encrypted. No automatic print, heater or movement commands are sent.")
                }
                if let status = printer.snapshot {
                    Section("Direct printer status") {
                        LabeledContent("State at last check", value: status.state)
                        LabeledContent("Checked", value: "\(Int(max(0, now.timeIntervalSince(status.checked)))) seconds ago")
                        LabeledContent("Printer firmware", value: status.version)
                        if let progress = status.progress { LabeledContent("Progress", value: String(format: "%.0f%%", progress)) }
                        if let nozzle = status.nozzle { LabeledContent("Nozzle", value: String(format: "%.1f °C", nozzle)) }
                        if let bed = status.bed { LabeledContent("Bed", value: String(format: "%.1f °C", bed)) }
                        Text("A bounded status check finishes and closes its network session. Refresh to get a new full reading; old or partial events are not shown as live status.")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                }
                Section("Remote / Cellular · official account") {
                    Link("Open Elegoo Matrix / account setup", destination: URL(string: "https://apps.apple.com/app/id6745138636")!)
                    Text("Open Matrix, sign in there, bind this printer to your account and keep the printer connected to the Internet. Use Matrix’s remote controls when the iPhone is away from your printer’s Wi-Fi, including cellular where supported.")
                    Text("Your Elegoo account stays in Matrix. This app does not collect its password, copy vendor tokens or claim to be logged into that account.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                Section("Print your drone parts") {
                    Label("Elegoo printer workflow", systemImage: "printer.fill").font(.headline)
                    LabeledContent("Your confirmed printer", value: "Elegoo Centauri Carbon 2")
                    LabeledContent("Your installed nozzle", value: "0.6 mm")
                    Text("The old saved PC profile was for the original Centauri Carbon. Use the verified Carbon 2 profile on the PC after it has been prepared; this phone does not change slicer settings.")
                        .foregroundStyle(.orange)
                    Text("Use your verified, saved printer profile in Elegoo Slicer on the PC. Choose the exact printer generation and installed nozzle there before slicing.")
                    Text("The iPhone stores designs and shares files. It does not slice, send printer commands or start a print.")
                        .foregroundStyle(.secondary)
                }
                Section("Three simple steps") {
                    Text("1. Add your STL or 3MF in Drone CAD, then Share it to the PC or save it to Files.")
                    Text("2. Open it in Elegoo Slicer using the saved printer profile. Check dimensions, orientation, supports and sliced preview.")
                    Text("3. Send the checked job using Elegoo’s supported printer workflow. Elegoo Matrix supports printer controls; 3D GO is a separate design and slicing app, not a verified Carbon 2 controller.")
                    Link("Elegoo Matrix on the App Store", destination: URL(string: "https://apps.apple.com/app/id6745138636")!)
                }
                Section {
                    if library.items.isEmpty { Text("Add a design in Drone CAD first.").foregroundStyle(.secondary) }
                    ForEach(library.items) { item in
                        ShareLink(item: item.url) { Label(item.name, systemImage: "square.and.arrow.up") }
                    }
                } header: {
                    Text("Send a saved design")
                } footer: {
                    Text("The Share menu shows compatible installed apps. An app appearing there does not guarantee that it can slice or print this model.")
                }
                Section("Printer connection") {
                    LabeledContent("Direct LAN capability", value: "Discovery, access-code check and full status")
                    Text("G-code upload and print-start controls are not enabled here. Use the checked slicer / Matrix workflow to print. 3D GO does not provide a verified public Carbon 2 control interface.")
                    Text("Your printer’s network and your drone’s telemetry are separate. Never use a printer connection or printer job as a drone command.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
            .modifier(DroneMatrixSurface())
            .navigationTitle("Printer")
            .alert("Remove this saved printer profile?", isPresented: $confirmProfileRemoval) {
                Button("Remove", role: .destructive) { printer.removeProfile() }
                Button("Cancel", role: .cancel) { }
            } message: { Text("This removes its saved address and private access code from this app. It does not reset the printer or change your Elegoo account.") }
            .onAppear { library.refresh() }
            .onDisappear { printer.disconnect() }
            .onChange(of: scenePhase) { _, phase in if phase == .background { printer.disconnect() } }
            .onReceive(Timer.publish(every: 1, on: .main, in: .common).autoconnect()) { now = $0 }
            .scrollDismissesKeyboard(.interactively)
            .toolbar { ToolbarItemGroup(placement: .keyboard) { Spacer(); Button("Done") { editing = false } } }
            .safeAreaInset(edge: .bottom) { AppBrandFooter() }
        }
    }
}

struct AppBrandFooter: View {
    var body: some View {
        Text("Made by Nate Wrench 2026").font(.footnote).foregroundStyle(.secondary)
            .frame(maxWidth: .infinity).padding(.vertical, 8).background(.bar)
    }
}
