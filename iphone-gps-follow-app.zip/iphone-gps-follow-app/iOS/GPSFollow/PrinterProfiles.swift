import Foundation

enum ElegooFamily: String, CaseIterable, Codable, Identifiable {
    case carbon2 = "Centauri Carbon 2"
    case carbon = "Centauri Carbon"
    case neptune4 = "Neptune 4"
    case neptune4Pro = "Neptune 4 Pro"
    case neptune4Plus = "Neptune 4 Plus"
    case neptune4Max = "Neptune 4 Max"
    case giga = "OrangeStorm Giga"
    var id: String { rawValue }
    var supported: Bool { self == .carbon2 }
}
struct PrinterProfile: Codable, Identifiable {
    let id: UUID
    var name: String
    var family: ElegooFamily
    var ip: String
    var serial: String?
    static func read() -> [PrinterProfile] {
        guard let data = UserDefaults.standard.data(forKey: "printer.profiles.v1"), data.count <= 16_384,
              let profiles = try? JSONDecoder().decode([PrinterProfile].self, from: data), profiles.count <= 8,
              Set(profiles.map(\.id)).count == profiles.count,
              profiles.allSatisfy({ validName($0.name) && ($0.ip.isEmpty || OperatingArea.privateIPv4($0.ip)) && ($0.serial == nil || PrinterJSON.serial($0.serial) != nil) }) else { return [] }
        return profiles
    }
    static func validName(_ name: String) -> Bool {
        !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && name.utf8.count <= 64 && !name.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) })
    }
    static func save(_ profiles: [PrinterProfile]) -> Bool {
        guard profiles.count <= 8, let data = try? JSONEncoder().encode(profiles), data.count <= 16_384 else { return false }
        UserDefaults.standard.set(data, forKey: "printer.profiles.v1"); return UserDefaults.standard.data(forKey: "printer.profiles.v1") == data
    }
}
