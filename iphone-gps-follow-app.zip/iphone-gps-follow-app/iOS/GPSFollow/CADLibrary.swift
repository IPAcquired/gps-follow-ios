import Foundation
import Combine

enum CADLibraryError: LocalizedError {
    case unsupported, tooLarge, notRegular, quota, invalidHeader
    var errorDescription: String? {
        switch self {
        case .unsupported: return "Choose an STL or 3MF file."
        case .tooLarge: return "Each CAD file must be 64 MB or smaller."
        case .notRegular: return "Choose a local file, not a folder or shortcut."
        case .quota: return "The library is full. Remove a file before importing another."
        case .invalidHeader: return "This does not look like an STL or 3MF file. Export it again from your design software."
        }
    }
}

enum CADPolicy {
    static let maxFileBytes = 64 * 1024 * 1024
    static let maxLibraryBytes = 256 * 1024 * 1024
    static let maxFiles = 100

    static func safeName(_ original: String) throws -> String {
        let name = (original as NSString).lastPathComponent
        let ext = (name as NSString).pathExtension.lowercased()
        guard ext == "stl" || ext == "3mf" else { throw CADLibraryError.unsupported }
        let stem = (name as NSString).deletingPathExtension
        let safe = stem.unicodeScalars.map { scalar -> String in
            let n = scalar.value
            return (n >= 48 && n <= 57) || (n >= 65 && n <= 90) || (n >= 97 && n <= 122) || n == 45 || n == 95 ? String(scalar) : "_"
        }.joined()
        return String((safe.isEmpty ? "Drone_part" : safe).prefix(80)) + "." + ext
    }

    static func validateHeader(_ data: Data, extension ext: String) throws {
        guard !data.isEmpty, data.count <= maxFileBytes else { throw CADLibraryError.tooLarge }
        if ext == "3mf" {
            guard data.count >= 4, Array(data.prefix(4)) == [0x50, 0x4b, 0x03, 0x04] else { throw CADLibraryError.invalidHeader }
            return // Archive is stored unchanged, never decompressed or executed here.
        }
        guard ext == "stl" else { throw CADLibraryError.unsupported }
        if data.count >= 84 {
            let bytes = Array(data[80..<84])
            let triangles = UInt64(bytes[0]) | (UInt64(bytes[1]) << 8) | (UInt64(bytes[2]) << 16) | (UInt64(bytes[3]) << 24)
            if triangles > 0 && 84 + triangles * 50 == UInt64(data.count) { return }
        }
        let start = String(decoding: data.prefix(1024), as: UTF8.self).trimmingCharacters(in: .whitespacesAndNewlines)
        let end = String(decoding: data.suffix(1024), as: UTF8.self)
        guard start.hasPrefix("solid"), end.contains("endsolid") else { throw CADLibraryError.invalidHeader }
    }
}

struct CADItem: Identifiable {
    let url: URL
    let name: String
    let bytes: Int
    var id: String { url.lastPathComponent }
    var sizeText: String { ByteCountFormatter.string(fromByteCount: Int64(bytes), countStyle: .file) }
}

final class CADLibrary: ObservableObject {
    @Published private(set) var items: [CADItem] = []
    @Published var error: String?
    private let directory: URL
    private let files: FileManager

    init(directory: URL? = nil, files: FileManager = .default) {
        self.files = files
        self.directory = directory ?? files.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("Drone CAD", isDirectory: true)
        do {
            try files.createDirectory(at: self.directory, withIntermediateDirectories: true,
                                      attributes: [.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication])
            var resources = URLResourceValues()
            resources.isExcludedFromBackup = true
            var localDirectory = self.directory
            try localDirectory.setResourceValues(resources)
            refresh()
        } catch { self.error = "Could not open the local CAD library." }
    }

    func refresh() {
        do {
            items = try files.contentsOfDirectory(at: directory, includingPropertiesForKeys: [.isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey], options: .skipsHiddenFiles)
                .compactMap { url -> CADItem? in
                    let values = try url.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey])
                    guard values.isRegularFile == true, values.isSymbolicLink != true,
                          ["stl", "3mf"].contains(url.pathExtension.lowercased()),
                          let bytes = values.fileSize, bytes > 0, bytes <= CADPolicy.maxFileBytes else { return nil }
                    let raw = url.lastPathComponent
                    let displayed = raw.count > 37 && raw[raw.index(raw.startIndex, offsetBy: 36)] == "_" ? String(raw.dropFirst(37)) : raw
                    return CADItem(url: url, name: displayed, bytes: bytes)
                }.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
        } catch { self.error = "Could not read the local CAD library." }
    }

    @discardableResult func importFile(_ source: URL) throws -> CADItem {
        guard source.isFileURL else { throw CADLibraryError.notRegular }
        let scoped = source.startAccessingSecurityScopedResource()
        defer { if scoped { source.stopAccessingSecurityScopedResource() } }
        let safeName = try CADPolicy.safeName(source.lastPathComponent)
        let values = try source.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey])
        guard values.isRegularFile == true, values.isSymbolicLink != true else { throw CADLibraryError.notRegular }
        guard let declaredSize = values.fileSize, declaredSize > 0, declaredSize <= CADPolicy.maxFileBytes else { throw CADLibraryError.tooLarge }
        refresh()
        guard items.count < CADPolicy.maxFiles else { throw CADLibraryError.quota }
        let handle = try FileHandle(forReadingFrom: source)
        defer { try? handle.close() }
        var data = Data()
        while let chunk = try handle.read(upToCount: min(65_536, CADPolicy.maxFileBytes + 1 - data.count)), !chunk.isEmpty {
            data.append(chunk)
            if data.count > CADPolicy.maxFileBytes { throw CADLibraryError.tooLarge }
        }
        try CADPolicy.validateHeader(data, extension: source.pathExtension.lowercased())
        guard items.reduce(0, { $0 + $1.bytes }) + data.count <= CADPolicy.maxLibraryBytes else { throw CADLibraryError.quota }
        let target = directory.appendingPathComponent(UUID().uuidString + "_" + safeName)
        try data.write(to: target, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        refresh()
        return CADItem(url: target, name: safeName, bytes: data.count)
    }

    func remove(_ item: CADItem) {
        // Only a listed direct child may be deleted; never an arbitrary imported URL.
        guard items.contains(where: { $0.id == item.id }), item.url.deletingLastPathComponent().standardizedFileURL == directory.standardizedFileURL else { return }
        do { try files.removeItem(at: item.url); refresh() }
        catch { self.error = "Could not remove this local copy." }
    }
}
