import Foundation
import Combine

@MainActor final class PrinterModel: ObservableObject {
    @Published var ip = UserDefaults.standard.string(forKey: "printer.cc2.ip") ?? ""
    @Published var code = SecretStore.load("printer-cc2")
    @Published var family = ElegooFamily.carbon2
    @Published var profileName = "My Carbon 2"
    @Published private(set) var profiles = PrinterProfile.read()
    @Published private(set) var profileID = UUID()
    @Published private(set) var selected: PrinterIdentity?
    @Published private(set) var snapshot: PrinterSnapshot?
    @Published private(set) var busy = false
    @Published private(set) var automaticScanFinished = false
    @Published var error: String?
    private var client: PrinterClient?
    private var task: Task<Void, Never>?
    private var generation = 0
    init() {
        if let first = profiles.first {
            profileID = first.id; profileName = first.name; family = first.family; ip = first.ip
            code = SecretStore.load("printer-profile-" + first.id.uuidString)
            if let serial = first.serial { selected = PrinterIdentity(ip: first.ip, serial: serial, model: first.family.rawValue, name: first.name) }
            return
        }
        if let serial = UserDefaults.standard.string(forKey: "printer.cc2.serial"), PrinterJSON.serial(serial) != nil, OperatingArea.privateIPv4(ip) {
            selected = PrinterIdentity(ip: ip, serial: serial, model: "Elegoo Centauri Carbon 2", name: "Saved printer")
        }
    }
    func selectProfile(_ id: UUID) {
        guard let profile = profiles.first(where: { $0.id == id }) else { return }
        disconnect(); profileID = profile.id; profileName = profile.name; family = profile.family; ip = profile.ip
        code = SecretStore.load("printer-profile-" + profile.id.uuidString); error = nil
        selected = profile.serial.map { PrinterIdentity(ip: ip, serial: $0, model: family.rawValue, name: profileName) }
    }
    func addProfile() {
        guard profiles.count < 8 else { error = "Up to eight Elegoo printer profiles can be saved."; return }
        disconnect(); profileID = UUID(); profileName = "New Elegoo printer"; family = .carbon2; ip = ""; code = ""; selected = nil; error = nil
    }
    func saveProfile() {
        guard PrinterProfile.validName(profileName), ip.isEmpty || OperatingArea.privateIPv4(ip) else { error = "Use a short printer name and its private Wi-Fi IP."; return }
        guard code.isEmpty || ((1...64).contains(code.utf8.count) && code.utf8.allSatisfy({ (33...126).contains($0) })) else { error = "Use the printer’s LAN access code, not an Elegoo account password."; return }
        guard SecretStore.save(code, name: "printer-profile-" + profileID.uuidString) else { error = "Could not save this printer’s access code securely."; return }
        let identityMatches = family.supported && selected?.ip == ip && selected.map({ PrinterJSON.isCC2($0.model) }) == true
        let profile = PrinterProfile(id: profileID, name: profileName, family: family, ip: ip, serial: identityMatches ? selected?.serial : nil)
        var updated = profiles.filter { $0.id != profileID }; updated.append(profile)
        guard updated.count <= 8, PrinterProfile.save(updated) else { error = "Could not save this printer profile."; return }
        profiles = updated; error = nil
    }
    func removeProfile() {
        disconnect(); let updated = profiles.filter { $0.id != profileID }
        guard PrinterProfile.save(updated) else { error = "Could not remove the saved profile. It is still listed; retry."; return }
        let cleared = SecretStore.save("", name: "printer-profile-" + profileID.uuidString)
        profiles = updated
        if let first = profiles.first { selectProfile(first.id) } else { addProfile() }
        if !cleared { error = "The profile was removed, but its private access-code cleanup failed. Unlock the phone and retry setup." }
    }
    func addressChanged() { disconnect(); selected = nil }
    func disconnect() {
        generation += 1; task?.cancel(); task = nil; client?.close(); client = nil; busy = false; snapshot = nil
    }
    func discover() {
        guard family.supported else { error = "This Elegoo model can be saved, but its direct connection adapter is not enabled in this build. Use its supported Elegoo app / slicer workflow."; return }
        disconnect(); error = nil; busy = true; let stamp = generation, host = ip
        let operation = PrinterClient(); client = operation
        task = Task {
            do {
                let identity = try await operation.discover(ip: host)
                guard generation == stamp else { return }
                selected = identity; busy = false
            } catch {
                guard generation == stamp else { return }
                self.error = error.localizedDescription; busy = false
            }
        }
    }
    func discoverNearby() {
        guard !busy else { return }
        disconnect(); error = nil; busy = true; let stamp = generation
        let operation = PrinterClient(); client = operation
        task = Task {
            do {
                let printers = try await operation.discoverNearby()
                guard generation == stamp else { return }
                automaticScanFinished = true; busy = false
                guard let identity = printers.first else {
                    self.error = "No supported Elegoo printer replied on this Wi-Fi. Check that Local Network access is allowed and retry."
                    return
                }
                selected = identity; ip = identity.ip; profileName = identity.name; family = .carbon2
            } catch {
                guard generation == stamp else { return }
                automaticScanFinished = true; self.error = error.localizedDescription; busy = false
            }
        }
    }
    func connect() {
        guard family.supported else { error = "Direct connection is currently enabled only for Centauri Carbon 2."; return }
        guard let selected, selected.ip == ip else { error = "Find and select your printer first."; return }
        disconnect(); error = nil; busy = true; let stamp = generation, host = ip, access = code
        let operation = PrinterClient(); client = operation
        task = Task {
            do {
                let current = try await operation.status(ip: host, code: access, pinnedSerial: selected.serial)
                guard generation == stamp else { return }
                guard SecretStore.save(access, name: "printer-profile-" + profileID.uuidString) else { throw PrinterError.rejected }
                UserDefaults.standard.set(host, forKey: "printer.cc2.ip")
                UserDefaults.standard.set(current.identity.serial, forKey: "printer.cc2.serial")
                self.selected = current.identity; snapshot = current; busy = false
                saveProfile()
            } catch {
                guard generation == stamp else { return }
                self.error = error.localizedDescription; busy = false; snapshot = nil
            }
        }
    }
}
