import Foundation
import CoreLocation
import Combine
import UIKit

struct OperatingArea {
    let latitude: Double
    let longitude: Double
    let radius: Double
    let height: Double
    static func privateIPv4(_ text: String) -> Bool {
        let parts = text.split(separator: ".", omittingEmptySubsequences: false)
        guard parts.count == 4 else { return false }
        let bytes = parts.compactMap { UInt8($0) }
        guard bytes.count == 4, bytes[3] != 0, bytes[3] != 255 else { return false }
        return bytes[0] == 10 || (bytes[0] == 172 && (16...31).contains(bytes[1])) ||
            (bytes[0] == 192 && bytes[1] == 168)
    }
    static func validCoordinates(_ lat: Double, _ lon: Double) -> Bool {
        lat.isFinite && lon.isFinite && (-85...85).contains(lat) && (-180...180).contains(lon) && !(lat == 0 && lon == 0)
    }
}

struct GPSFilter {
    let area: OperatingArea
    var previous: CLLocation?

    mutating func reason(_ fix: CLLocation, now: Date = Date()) -> String? {
        let coordinate = fix.coordinate
        guard OperatingArea.validCoordinates(coordinate.latitude, coordinate.longitude) else { return "Invalid GPS coordinates" }
        if fix.sourceInformation?.isSimulatedBySoftware == true { return "Simulated GPS fixes are disabled" }
        guard fix.horizontalAccuracy > 0, fix.horizontalAccuracy <= 8 else { return "Waiting for GPS accuracy of 8 m or better" }
        let age = now.timeIntervalSince(fix.timestamp)
        guard age >= -0.1, age <= 1 else { return "Waiting for a fresh GPS fix" }
        guard fix.speed.isFinite, fix.speed >= -1, fix.speed <= 3 else { return "Walking speed exceeded" }
        let origin = CLLocation(latitude: area.latitude, longitude: area.longitude)
        guard fix.distance(from: origin) <= area.radius else { return "Outside the operating radius" }
        if let last = previous {
            let dt = fix.timestamp.timeIntervalSince(last.timestamp)
            guard dt >= 0 else { return "GPS timestamp moved backward" }
            let distance = fix.distance(from: last)
            if dt == 0 && distance > 0.05 { return "GPS changed position without a new fix" }
            let allowance = 3 + min(6, fix.horizontalAccuracy + last.horizontalAccuracy)
            guard distance <= allowance + 3 * dt else { return "GPS jump rejected" }
        }
        previous = fix
        return nil
    }
}

final class GPSModel: NSObject, ObservableObject, CLLocationManagerDelegate {
    @Published var mode: TransportMode = .direct
    @Published var ip: String = UserDefaults.standard.string(forKey: "gpsfollow.ip") ?? ""
    @Published var port: String = UserDefaults.standard.string(forKey: "gpsfollow.port") ?? "14550"
    @Published var secret = SecretStore.load("direct")
    @Published var originLat: String = UserDefaults.standard.string(forKey: "gpsfollow.lat") ?? ""
    @Published var originLon: String = UserDefaults.standard.string(forKey: "gpsfollow.lon") ?? ""
    @Published var radiusText = "50"
    @Published var heightText = "5"
    @Published private(set) var running = false
    @Published private(set) var status = "Stopped"
    @Published private(set) var linkStatus = "No connection"
    @Published private(set) var accuracy: Double?
    @Published private(set) var fixDate: Date?
    @Published private(set) var targetCount = 0
    @Published private(set) var error: String?
    @Published var now = Date()

    private let manager = CLLocationManager()
    private var ticker: Timer?
    private var direct: DirectTarget?
    private var relay: UDPLink?
    private var key: Data?
    private var clientNonce = ""
    private var relayNonce: String?
    private var sequence = 0
    private var lastAcknowledgedSequence = 0
    private var lastAckMono: TimeInterval = -100
    private var lastHelloMono: TimeInterval = -100
    private var lastFixMono: TimeInterval = -100
    private var lastPublicationMono: TimeInterval = -100
    private var latest: CLLocation?
    private var filter: GPSFilter?
    private var needsCenter = false

    override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.distanceFilter = kCLDistanceFilterNone
        manager.activityType = .fitness
        manager.pausesLocationUpdatesAutomatically = false
        manager.allowsBackgroundLocationUpdates = false
    }

    var fixAge: String {
        guard let fixDate else { return "—" }
        return String(format: "%.1f s", max(0, now.timeIntervalSince(fixDate)))
    }
    var accuracyText: String {
        guard let accuracy, accuracy >= 0 else { return "—" }
        return String(format: "±%.1f m", accuracy)
    }

    func modeChanged() {
        stop()
        secret = SecretStore.load(mode == .direct ? "direct" : "relay")
        port = mode == .direct ? "14550" : "45678"
    }

    func useCurrentLocationAsCenter() {
        guard !running else { return }
        error = nil
        needsCenter = true
        status = "Getting operating center"
        requestLocationPermission()
        if permissionGranted { manager.requestLocation() }
    }

    private var permissionGranted: Bool {
        manager.authorizationStatus == .authorizedWhenInUse || manager.authorizationStatus == .authorizedAlways
    }
    private func requestLocationPermission() {
        if manager.authorizationStatus == .notDetermined { manager.requestWhenInUseAuthorization() }
        if manager.authorizationStatus == .denied || manager.authorizationStatus == .restricted {
            error = "Allow Location access in Settings to use GPS Follow."
            stop()
        }
    }

    func start() {
        error = nil
        guard OperatingArea.privateIPv4(ip), let portValue = UInt16(port), portValue >= 1024 else {
            error = "Enter the private Wi-Fi address and UDP port of your telemetry device."; return
        }
        guard let configuredKey = MAVLink.key(secret) else {
            error = mode == .direct ? "Enter the 64-character MAVLink signing key already configured on your controller." :
                "Enter the 64-character pairing key from the relay configuration."; return
        }
        guard let latitude = Double(originLat), let longitude = Double(originLon),
              OperatingArea.validCoordinates(latitude, longitude),
              let radius = Double(radiusText), radius.isFinite, (5...200).contains(radius),
              let height = Double(heightText), height.isFinite, (2...20).contains(height) else {
            error = "Set an operating center, radius from 5–200 m, and Follow height from 2–20 m."; return
        }
        if manager.authorizationStatus == .denied || manager.authorizationStatus == .restricted {
            error = "Allow Location access in Settings to use GPS Follow."; return
        }
        if permissionGranted && manager.accuracyAuthorization != .fullAccuracy {
            error = "Enable Precise Location for GPS Follow."; return
        }
        guard SecretStore.save(secret, name: mode == .direct ? "direct" : "relay") else {
            error = "Could not save the pairing key securely. Unlock your iPhone and try again."; return
        }
        UserDefaults.standard.set(ip, forKey: "gpsfollow.ip")
        UserDefaults.standard.set(port, forKey: "gpsfollow.port")
        UserDefaults.standard.set(originLat, forKey: "gpsfollow.lat")
        UserDefaults.standard.set(originLon, forKey: "gpsfollow.lon")
        key = configuredKey
        filter = GPSFilter(area: OperatingArea(latitude: latitude, longitude: longitude, radius: radius, height: height))
        latest = nil
        targetCount = 0
        sequence = 0
        lastAcknowledgedSequence = 0
        lastAckMono = -100
        lastHelloMono = -100
        lastPublicationMono = -100
        running = true
        needsCenter = false
        status = "Waiting for GPS"
        UIApplication.shared.isIdleTimerDisabled = true
        if mode == .direct {
            let target = DirectTarget(key: configuredKey, radius: radius, height: height)
            target.statusChanged = { [weak self] in self?.linkStatus = $0 }
            direct = target
            target.link.open(ip: ip, port: portValue)
        } else {
            clientNonce = UUID().uuidString.replacingOccurrences(of: "-", with: "").lowercased()
            relayNonce = nil
            let target = UDPLink()
            target.received = { [weak self] in self?.receiveRelay($0) }
            target.stateChanged = { [weak self] in self?.linkStatus = $0 }
            relay = target
            target.open(ip: ip, port: portValue)
        }
        requestLocationPermission()
        if permissionGranted { manager.startUpdatingLocation() }
        ticker = Timer.scheduledTimer(withTimeInterval: 0.2, repeats: true) { [weak self] _ in self?.tick() }
    }

    func stop() {
        if running, mode == .relay, relayNonce != nil { sendRelay(kind: "stop", fix: nil) }
        running = false
        needsCenter = false
        ticker?.invalidate(); ticker = nil
        manager.stopUpdatingLocation()
        direct?.close(); direct = nil
        // UDP Stop is best effort. Cached target also expires on source freshness timeout.
        relay?.close(); relay = nil
        latest = nil
        status = "Stopped"
        linkStatus = "No connection"
        UIApplication.shared.isIdleTimerDisabled = false
    }

    func foregroundChanged(active: Bool) {
        if !active { stop() }
    }

    private func tick() {
        guard running else { return }
        now = Date()
        let mono = ProcessInfo.processInfo.systemUptime
        direct?.tick()
        if mode == .relay, relay?.ready == true, relayNonce == nil, mono - lastHelloMono >= 0.5 {
            lastHelloMono = mono
            sendRelay(kind: "hello", fix: nil)
        }
        if mode == .relay, relayNonce != nil, mono - lastAckMono > 1.5 { linkStatus = "Relay response lost" }
        guard let fix = latest, now.timeIntervalSince(fix.timestamp) >= -0.1,
              now.timeIntervalSince(fix.timestamp) <= 1, mono - lastFixMono <= 1 else {
            if latest != nil { status = "GPS is stale; target paused"; latest = nil }
            return
        }
        // Enforce the ceiling independently of Timer delivery/run-loop jitter.
        guard mono - lastPublicationMono >= 0.2 else { return }
        if mode == .direct {
            if direct?.publish(lat: fix.coordinate.latitude, lon: fix.coordinate.longitude) == true {
                lastPublicationMono = mono
                targetCount += 1
                status = "Sharing GPS target"
            } else { status = "GPS ready; waiting for controller setup" }
        } else if relayNonce != nil {
            sendRelay(kind: "position", fix: fix)
            lastPublicationMono = mono
            status = "Sending GPS target to relay"
        }
    }

    private func sendRelay(kind: String, fix: CLLocation?) {
        guard let key else { return }
        var payload: [String: Any] = ["v": 1, "kind": kind, "client_nonce": clientNonce,
                                     "sent_ms": Int64(Date().timeIntervalSince1970 * 1000)]
        if kind != "hello" {
            guard let relayNonce else { return }
            sequence += 1
            payload["relay_nonce"] = relayNonce
            payload["sequence"] = sequence
        }
        if let fix {
            payload["lat"] = fix.coordinate.latitude
            payload["lon"] = fix.coordinate.longitude
            payload["accuracy_m"] = fix.horizontalAccuracy
            payload["fix_ms"] = Int64(fix.timestamp.timeIntervalSince1970 * 1000)
            payload["speed_mps"] = fix.speed
        }
        if let data = AuthenticatedJSON.encode(payload, key: key) { relay?.send(data) }
    }

    private func receiveRelay(_ data: Data) {
        guard running, let key, let payload = AuthenticatedJSON.decode(data, key: key),
              payload["client_nonce"] as? String == clientNonce,
              let stamp = payload["sent_ms"] as? NSNumber,
              abs(Date().timeIntervalSince1970 * 1000 - stamp.doubleValue) <= 2000 else { return }
        if payload["kind"] as? String == "challenge", relayNonce == nil,
           let nonce = payload["relay_nonce"] as? String, nonce.count == 32,
           nonce.allSatisfy({ $0.isHexDigit }) {
            guard let area = filter?.area, let limits = payload["limits"] as? [String: Any],
                  let lat = limits["origin_lat"] as? NSNumber, let lon = limits["origin_lon"] as? NSNumber,
                  let radius = limits["radius_m"] as? NSNumber, let height = limits["hover_height_m"] as? NSNumber,
                  CLLocation(latitude: area.latitude, longitude: area.longitude).distance(from:
                    CLLocation(latitude: lat.doubleValue, longitude: lon.doubleValue)) <= 0.1,
                  abs(area.radius - radius.doubleValue) <= 0.001, abs(area.height - height.doubleValue) <= 0.001 else {
                error = "The app operating center, radius and height must match the relay configuration."
                stop(); return
            }
            relayNonce = nonce
            lastAckMono = ProcessInfo.processInfo.systemUptime
            linkStatus = "Relay paired; waiting for target acceptance"
        } else if payload["kind"] as? String == "ack", payload["relay_nonce"] as? String == relayNonce,
                  let ack = payload["sequence"] as? Int, ack > lastAcknowledgedSequence, ack <= sequence {
            lastAcknowledgedSequence = ack
            lastAckMono = ProcessInfo.processInfo.systemUptime
            let accepted = payload["status"] as? String == "accepted"
            let ready = payload["serial_ready"] as? Bool == true
            if accepted {
                targetCount += 1
                linkStatus = ready ? "Relay accepted GPS; controller ready" : "Relay accepted GPS; dry run or controller unavailable"
            } else { linkStatus = payload["reason"] as? String ?? "Relay rejected GPS" }
        }
    }

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        if permissionGranted {
            if manager.accuracyAuthorization != .fullAccuracy {
                error = "Enable Precise Location for GPS Follow."
                stop(); return
            }
            if running { manager.startUpdatingLocation() }
            else if needsCenter { manager.requestLocation() }
        } else if manager.authorizationStatus == .denied || manager.authorizationStatus == .restricted {
            error = "Location permission was denied."
            stop()
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let fix = locations.last else { return }
        guard manager.accuracyAuthorization == .fullAccuracy else {
            error = "Enable Precise Location for GPS Follow."
            stop(); return
        }
        now = Date()
        accuracy = fix.horizontalAccuracy
        fixDate = fix.timestamp
        if needsCenter && !running {
            let age = Date().timeIntervalSince(fix.timestamp)
            guard fix.horizontalAccuracy > 0, fix.horizontalAccuracy <= 8, age >= -0.1, age <= 1,
                  fix.sourceInformation?.isSimulatedBySoftware != true else {
                needsCenter = false; error = "Wait outdoors for a fresh, precise GPS fix and try again."; status = "Stopped"; return
            }
            originLat = String(format: "%.7f", fix.coordinate.latitude)
            originLon = String(format: "%.7f", fix.coordinate.longitude)
            needsCenter = false
            status = "Operating center set"
            return
        }
        guard running else { return }
        if let reason = filter?.reason(fix, now: now) {
            latest = nil
            status = reason
            return
        }
        latest = fix
        lastFixMono = ProcessInfo.processInfo.systemUptime
        status = "Fresh GPS ready"
    }
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        latest = nil
        status = "GPS unavailable; target paused"
        if needsCenter { self.error = "Could not get a precise location. Try outdoors."; needsCenter = false }
    }
}
