import Foundation
import SwiftUI
import UniformTypeIdentifiers

struct AppConnectionProfile: Codable, Equatable, Identifiable {
    var id: String
    var name: String
    var kind: String
    var recommended: Bool
    var editable: Bool
    var requirements: [String]
    var directions: [String]
    var limitations: String

    static let nateMicoAir = AppConnectionProfile(
        id: "nate-micoair-h743v2-relay", name: "Nate · MicoAir H743 v2 through PC",
        kind: "mavlink-classic-spp-relay", recommended: true, editable: false,
        requirements: ["MicoAir743v2-09858", "Windows COM9 at 115200", "GPS Follow PC companion", "Encrypted iPhone relay"],
        directions: [
            "Pair MicoAir743v2-09858 with Windows and verify the board identity before opening the link.",
            "Use COM9 at 115200 only after the companion identifies the expected H743 v2.",
            "Connect the iPhone and PC to the same secured network and paste the companion's private setup card."
        ],
        limitations: "The iPhone does not open the controller's Classic SPP serial port directly. Windows relays authenticated app traffic. This profile never arms, changes mode, writes parameters, or flashes firmware."
    )

    static let tx15OptionalBluetooth = AppConnectionProfile(
        id: "tx15-optional-bluetooth-module", name: "TX15 Max · optional Bluetooth module",
        kind: "edgetx-optional-uart4-bluetooth", recommended: false, editable: false,
        requirements: ["Physical compatible Bluetooth module", "Bluetooth-enabled TX15 EdgeTX build", "Verified UART4 wiring and protocol"],
        directions: [
            "Confirm a compatible Bluetooth module is physically installed on TX15 UART4 before changing firmware.",
            "Back up the radio and compile the exact TX15 target with BLUETOOTH enabled.",
            "Bench-test discovery and the module protocol before adding it to this app."
        ],
        limitations: "The stock TX15 Max has no detected Bluetooth device. Firmware alone cannot add the missing radio. EdgeTX Bluetooth is trainer or telemetry-mirror data, not a MAVLink Follow control link."
    )
}

enum AppProfileRules {
    static let builtins: [AppConnectionProfile] = [.nateMicoAir, .tx15OptionalBluetooth]
    static func validate(_ profile: AppConnectionProfile, builtin: Bool = false) throws -> AppConnectionProfile {
        func line(_ value: String, max: Int) throws -> String {
            let clean = value.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !clean.isEmpty, clean.count <= max, !clean.contains("\n"), !clean.contains("\0") else { throw AppProfileError("A profile field is blank or too long.") }
            return clean
        }
        guard (1...20).contains(profile.requirements.count), (1...20).contains(profile.directions.count) else { throw AppProfileError("Use 1–20 requirements and directions.") }
        var clean = profile
        clean.id = try line(profile.id, max: 80); clean.name = try line(profile.name, max: 100); clean.kind = try line(profile.kind, max: 80)
        clean.requirements = try profile.requirements.map { try line($0, max: 300) }
        clean.directions = try profile.directions.map { try line($0, max: 300) }
        clean.limitations = try line(profile.limitations, max: 600)
        clean.recommended = builtin && profile.recommended
        clean.editable = !builtin
        return clean
    }
    static func imported(_ data: Data) throws -> AppConnectionProfile {
        guard data.count <= 262_144 else { throw AppProfileError("Connection profile is too large.") }
        return try validate(JSONDecoder().decode(AppConnectionProfile.self, from: data))
    }
}

struct AppProfileError: LocalizedError {
    let message: String
    init(_ message: String) { self.message = message }
    var errorDescription: String? { message }
}

enum AppBackgroundPreset: String, CaseIterable, Identifiable {
    case nwMatrix = "NW Matrix"
    case solidBlack = "Solid Black"
    case carbon = "Carbon"
    case highContrast = "High Contrast"
    var id: String { rawValue }
    var background: Color { self == .carbon ? Color(red: 0.035, green: 0.035, blue: 0.035) : .black }
    var accent: Color { self == .highContrast ? .red : Color(red: 0.89, green: 0.1, blue: 0.18) }
    var showsMatrix: Bool { self == .nwMatrix }
    var showsCarbon: Bool { self == .carbon }
}

enum IPhoneDeviceProfile: String, CaseIterable, Identifiable {
    case automatic = "Automatic (recommended)"
    case iPhoneSE3 = "iPhone SE (3rd generation)"
    case iPhone12_13_14 = "iPhone 12 / 13 / 14"
    case iPhone12_13_14ProMax = "iPhone 12 / 13 / 14 Pro Max"
    case iPhone14_15Plus = "iPhone 14 Plus / 15 Plus"
    case iPhone15 = "iPhone 15"
    case iPhone15Pro = "iPhone 15 Pro"
    case iPhone15ProMax = "iPhone 15 Pro Max"
    case iPhone16 = "iPhone 16"
    case iPhone16Plus = "iPhone 16 Plus"
    case iPhone16Pro = "iPhone 16 Pro"
    case iPhone16ProMax = "iPhone 16 Pro Max"
    case otherModern = "Other supported iPhone"

    var id: String { rawValue }
    var layoutHint: String {
        switch self {
        case .automatic: return "Uses the current screen size and accessibility settings automatically."
        case .iPhoneSE3: return "Compact layout with larger tap targets and shorter labels."
        case .iPhone12_13_14, .iPhone15, .iPhone15Pro, .iPhone16, .iPhone16Pro: return "Standard layout tuned for a 6.1-inch display."
        case .iPhone14_15Plus, .iPhone16Plus: return "Wide layout tuned for a 6.7-inch display."
        case .iPhone12_13_14ProMax, .iPhone15ProMax, .iPhone16ProMax: return "Wide layout tuned for a Pro Max display."
        case .otherModern: return "Adaptive layout without a model-specific hint."
        }
    }
}

@MainActor final class AppProfileStore: ObservableObject {
    @Published var profiles = AppProfileRules.builtins
    @Published var selectedID = AppConnectionProfile.nateMicoAir.id
    @Published var message = "Automatically selected for Nate's MicoAir H743 v2 build"
    private let defaults = UserDefaults.standard
    private let profilesKey = "app_connection_profiles_v1"
    private let selectedKey = "app_connection_selected_v1"
    init() {
        if let data = defaults.data(forKey: profilesKey), let saved = try? JSONDecoder().decode([AppConnectionProfile].self, from: data) { profiles += saved.compactMap { try? AppProfileRules.validate($0) } }
        if let saved = defaults.string(forKey: selectedKey), profiles.contains(where: { $0.id == saved }) { selectedID = saved }
    }
    var selectedIndex: Int { profiles.firstIndex(where: { $0.id == selectedID }) ?? 0 }
    var selected: AppConnectionProfile { profiles[selectedIndex] }
    var selectedBinding: Binding<AppConnectionProfile> { Binding(get: { self.profiles[self.selectedIndex] }, set: { self.profiles[self.selectedIndex] = $0 }) }
    func choose(_ id: String) { guard profiles.contains(where: { $0.id == id }) else { return }; selectedID = id; defaults.set(id, forKey: selectedKey) }
    func duplicate() { var copy = selected; copy.id = UUID().uuidString.lowercased(); copy.name = "My connection"; copy.recommended = false; copy.editable = true; profiles.append(copy); selectedID = copy.id; save() }
    func importData(_ data: Data) {
        do { let item = try AppProfileRules.imported(data); guard !profiles.contains(where: { $0.id == item.id }) else { throw AppProfileError("Use a unique profile ID.") }; profiles.append(item); selectedID = item.id; save() }
        catch { message = "Import failed: \(error.localizedDescription)" }
    }
    func save() {
        do {
            guard selected.editable else { message = "Built-in profiles are read-only. Duplicate one to edit it."; return }
            profiles[selectedIndex] = try AppProfileRules.validate(selected)
            defaults.set(try JSONEncoder().encode(Array(profiles.dropFirst(AppProfileRules.builtins.count))), forKey: profilesKey)
            defaults.set(selectedID, forKey: selectedKey); message = "Saved locally · custom and unverified"
        } catch { message = error.localizedDescription }
    }
}

struct AppConnectionDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.json] }
    var data: Data
    init(profile: AppConnectionProfile) { let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]; data = (try? encoder.encode(profile)) ?? Data() }
    init(configuration: ReadConfiguration) throws { data = configuration.file.regularFileContents ?? Data() }
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper { FileWrapper(regularFileWithContents: data) }
}

struct AppProfilesView: View {
    @StateObject private var store = AppProfileStore()
    @AppStorage("appearance_preset") private var appearance = AppBackgroundPreset.nwMatrix.rawValue
    @AppStorage("iphone_device_profile") private var deviceProfile = IPhoneDeviceProfile.iPhone16.rawValue
    @State private var importing = false
    @State private var exporting = false
    var body: some View {
        NavigationStack {
            Form {
                Section("Connection preset") {
                    Picker("Preset", selection: Binding(get: { store.selectedID }, set: { store.choose($0) })) { ForEach(store.profiles) { Text($0.name).tag($0.id) } }
                    Text(store.selected.recommended ? "Recommended automatically for this build" : "Advanced or custom option").foregroundStyle(store.selected.recommended ? .green : .orange)
                    Text(store.selected.limitations).font(.footnote).foregroundStyle(.secondary)
                }
                Section("Requirements") { ForEach(store.selected.requirements, id: \.self) { Label($0, systemImage: "checklist") } }
                Section("Directions") { ForEach(Array(store.selected.directions.enumerated()), id: \.offset) { index, item in Text("\(index + 1). \(item)") } }
                if store.selected.editable {
                    Section("Edit custom profile") {
                        TextField("Name", text: store.selectedBinding.name)
                        TextField("Connection kind", text: store.selectedBinding.kind)
                        TextField("Limitations", text: store.selectedBinding.limitations, axis: .vertical)
                        ForEach(store.profiles[store.selectedIndex].requirements.indices, id: \.self) { index in
                            TextField("Requirement", text: Binding(get: { store.profiles[store.selectedIndex].requirements[index] }, set: { store.profiles[store.selectedIndex].requirements[index] = $0 }))
                        }
                        ForEach(store.profiles[store.selectedIndex].directions.indices, id: \.self) { index in
                            TextField("Direction", text: Binding(get: { store.profiles[store.selectedIndex].directions[index] }, set: { store.profiles[store.selectedIndex].directions[index] = $0 }))
                        }
                        Button("Save custom profile") { store.save() }
                    }
                }
                Section("Profiles") {
                    Button("New editable copy") { store.duplicate() }
                    Button("Import JSON") { importing = true }
                    Button("Export selected JSON") { exporting = true }
                    Text(store.message).font(.footnote).foregroundStyle(.secondary)
                }
                Section("Background") {
                    Picker("Style", selection: $appearance) { ForEach(AppBackgroundPreset.allCases) { Text($0.rawValue).tag($0.rawValue) } }
                    Text("The background choice stays on this device and never changes flight data, telemetry, mappings, or firmware.").font(.footnote).foregroundStyle(.secondary)
                }
                Section("iPhone compatibility") {
                    Picker("Device model", selection: $deviceProfile) {
                        ForEach(IPhoneDeviceProfile.allCases) { Text($0.rawValue).tag($0.rawValue) }
                    }
                    Text(IPhoneDeviceProfile(rawValue: deviceProfile)?.layoutHint ?? IPhoneDeviceProfile.automatic.layoutHint)
                        .font(.footnote).foregroundStyle(.secondary)
                    Text("This choice adjusts presentation hints only. Network security, telemetry validation and flight safeguards stay identical on every supported iPhone.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
            .modifier(DroneMatrixSurface()).navigationTitle("App Setup")
            .fileImporter(isPresented: $importing, allowedContentTypes: [.json]) { result in if case .success(let url) = result, url.startAccessingSecurityScopedResource() { defer { url.stopAccessingSecurityScopedResource() }; if let data = try? Data(contentsOf: url, options: .mappedIfSafe) { store.importData(data) } } }
            .fileExporter(isPresented: $exporting, document: AppConnectionDocument(profile: store.selected), contentType: .json, defaultFilename: "GPSFollow-connection") { _ in }
        }
    }
}
