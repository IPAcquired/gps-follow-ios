import Foundation
import Combine
import Darwin

struct PCSetup {
    let ip: String; let port: String; let key: String
    let lat: String; let lon: String; let radius: String; let height: String; let version: String
    let targetRole: TargetRole; let targetID: String; let expiresMS: Int64?
    static func parse(_ text: String) throws -> PCSetup {
        guard text.utf8.count <= 2048, !text.contains("\0") else { throw PrinterError.malformed }
        var lines = text.replacingOccurrences(of: "\r\n", with: "\n").components(separatedBy: "\n")
        if lines.last == "" { lines.removeLast() }
        let v2 = lines.first == "GPSFollow-local-setup-v2"
        let names = ["pc_ip", "udp_port", "pairing_key", "center_lat", "center_lon", "radius_m", "height_m", "protocol", "companion_version"] + (v2 ? ["target_role", "target_id", "expires_ms"] : [])
        guard lines.count == names.count + 1,
              lines[0] == (v2 ? "GPSFollow-local-setup-v2" : "GPSFollow-local-setup-v1") else { throw PrinterError.malformed }
        var values: [String] = []
        for (index, name) in names.enumerated() {
            let prefix = name + "="; guard lines[index + 1].hasPrefix(prefix) else { throw PrinterError.malformed }
            let value = String(lines[index + 1].dropFirst(prefix.count)); guard !value.contains("="), !value.contains("\r"), value == value.trimmingCharacters(in: .whitespaces) else { throw PrinterError.malformed }; values.append(value)
        }
        guard OperatingArea.privateIPv4(values[0]), values[0].split(separator: ".").allSatisfy({ String(UInt8($0) ?? 0) == $0 }),
              let port = UInt16(values[1]), port >= 1024,
              values[2].utf8.count == 64, MAVLink.key(values[2]) != nil,
              let lat = Double(values[3]), let lon = Double(values[4]), OperatingArea.validCoordinates(lat, lon),
              let radius = Double(values[5]), radius.isFinite, (5...200).contains(radius),
              let height = Double(values[6]), height.isFinite, (2...20).contains(height),
              values[7] == "aes-gcm-v2", values[8].utf8.count <= 40,
              !values[8].isEmpty, values[8].utf8.allSatisfy({ (32...126).contains($0) }) else { throw PrinterError.malformed }
        let role: TargetRole
        let targetID: String
        let expires: Int64?
        if v2 {
            guard let parsedRole = TargetRole(rawValue: values[9]),
                  !values[10].isEmpty, values[10].utf8.count <= 64,
                  values[10].allSatisfy({ $0.isASCII && ($0.isLetter || $0.isNumber || $0 == "-" || $0 == "_") }),
                  let parsedExpiry = Int64(values[11]), parsedExpiry > 0 else { throw PrinterError.malformed }
            role = parsedRole; targetID = values[10]; expires = parsedExpiry
            if role != .guest || Date().timeIntervalSince1970 * 1000 >= Double(parsedExpiry) { throw PrinterError.malformed }
        } else {
            role = .owner; targetID = "owner"; expires = nil
        }
        return PCSetup(ip: values[0], port: String(port), key: values[2], lat: values[3], lon: values[4], radius: values[5], height: values[6], version: values[8], targetRole: role, targetID: targetID, expiresMS: expires)
    }
}

struct PCService: Identifiable {
    let id: String; let name: String; let ip: String; let port: Int; let version: String
}

final class PCBrowser: NSObject, ObservableObject, NetServiceBrowserDelegate, NetServiceDelegate {
    @Published private(set) var services: [PCService] = []
    @Published var status = "Find a companion on this Wi-Fi"
    private let browser = NetServiceBrowser()
    private var resolving: [NetService] = []
    private var timeout: Timer?
    private var active = false
    override init() { super.init(); browser.delegate = self }
    func start() {
        stop(); services = []; status = "Looking for compatible PC companions…"
        active = true
        browser.searchForServices(ofType: "_gpsfollow._udp.", inDomain: "local.")
        timeout = Timer.scheduledTimer(withTimeInterval: 8, repeats: false) { [weak self] _ in
            self?.browser.stop(); self?.status = self?.services.isEmpty == true ? "No compatible PC found. Start bench pairing on the PC or use Paste PC setup." : "Choose your PC below; encrypted pairing still verifies it."
        }
    }
    func stop() { active = false; browser.stop(); resolving.forEach { $0.stop() }; resolving = []; timeout?.invalidate(); timeout = nil }
    func netServiceBrowser(_ browser: NetServiceBrowser, didFind service: NetService, moreComing: Bool) {
        guard active, resolving.count < 16 else { return }
        resolving.append(service); service.delegate = self; service.resolve(withTimeout: 4)
    }
    func netServiceBrowser(_ browser: NetServiceBrowser, didRemove service: NetService, moreComing: Bool) {
        services.removeAll { $0.id == service.domain + service.type + service.name }
    }
    func netServiceBrowser(_ browser: NetServiceBrowser, didNotSearch errorDict: [String: NSNumber]) { status = "Local discovery is unavailable. Use Paste PC setup."; stop() }
    static func txt(_ data: Data, port: Int) -> String? {
        guard data.count <= 1024, (1024...65535).contains(port) else { return nil }
        let fields = NetService.dictionary(fromTXTRecord: data)
        guard fields.count == 3, Set(fields.keys) == Set(["protocol", "companion_version", "bench_only"]),
              fields["protocol"] == Data("aes-gcm-v2".utf8), fields["bench_only"] == Data("1".utf8),
              let raw = fields["companion_version"], raw.count <= 40, let version = String(data: raw, encoding: .utf8), !version.isEmpty,
              raw.allSatisfy({ (32...126).contains($0) }) else { return nil }
        return version
    }
    func netServiceDidResolveAddress(_ sender: NetService) {
        guard active, let data = sender.txtRecordData(), let version = Self.txt(data, port: sender.port), let addresses = sender.addresses else { return }
        let ips = Set(addresses.compactMap { bytes -> String? in
            bytes.withUnsafeBytes { raw -> String? in
                guard bytes.count >= MemoryLayout<sockaddr_in>.size, let base = raw.baseAddress else { return nil }
                let address = base.assumingMemoryBound(to: sockaddr.self)
                guard address.pointee.sa_family == UInt8(AF_INET) else { return nil }
                var host = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                guard getnameinfo(address, socklen_t(bytes.count), &host, socklen_t(host.count), nil, 0, NI_NUMERICHOST) == 0 else { return nil }
                let ip = String(cString: host); return OperatingArea.privateIPv4(ip) ? ip : nil
            }
        })
        guard ips.count == 1, let ip = ips.first else { return }
        let id = sender.domain + sender.type + sender.name
        services.removeAll { $0.id == id }
        services.append(PCService(id: id, name: String(sender.name.prefix(80)), ip: ip, port: sender.port, version: version))
        status = "Choose your PC. This advertisement has no private key and is not authenticated yet."
    }
}
