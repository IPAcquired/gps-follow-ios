import Foundation
import Network

enum PrinterError: LocalizedError {
    case invalidSetup, timeout, disconnected, malformed, rejected, wrongPrinter, cloudMode
    var errorDescription: String? {
        switch self {
        case .invalidSetup: return "Enter the printer’s private Wi-Fi IP and its access code."
        case .timeout: return "Printer timed out. Check Wi-Fi, LAN mode and the address, then retry."
        case .disconnected: return "Printer connection closed. You can reconnect."
        case .malformed: return "The printer sent an unsupported or incomplete reply."
        case .rejected: return "The printer rejected this connection. Check its access code."
        case .wrongPrinter: return "The model or serial number changed. Verify the selected printer before connecting."
        case .cloudMode: return "This printer reports cloud mode. Use Elegoo Matrix for account connection, or explicitly enable LAN mode on the printer."
        }
    }
}

// The continuation can be completed by either Network.framework's callback or
// the timeout callback. NSLock protects the only mutable state and guarantees
// exactly one resume, so this small bridge is safe to pass to sendable closures.
private final class CompletionGate<T: Sendable>: @unchecked Sendable {
    private let lock = NSLock()
    private var done = false
    private let continuation: CheckedContinuation<T, Error>
    init(_ continuation: CheckedContinuation<T, Error>) { self.continuation = continuation }
    @discardableResult func finish(_ result: Result<T, Error>) -> Bool {
        lock.lock(); guard !done else { lock.unlock(); return false }; done = true; lock.unlock()
        continuation.resume(with: result)
        return true
    }
}

final class PrinterSocket {
    private let connection: NWConnection
    private let queue = DispatchQueue(label: "NatesDrone.PrinterSocket")
    private var buffer = Data()
    private let deadline: TimeInterval
    init(host: String, port: UInt16, udp: Bool = false, deadline: TimeInterval = ProcessInfo.processInfo.systemUptime + 25) {
        connection = NWConnection(host: NWEndpoint.Host(host), port: NWEndpoint.Port(rawValue: port)!, using: udp ? .udp : .tcp)
        self.deadline = deadline
    }
    init(connection: NWConnection) { self.connection = connection; deadline = ProcessInfo.processInfo.systemUptime + 25 }
    func close() { connection.cancel() }
    deinit { connection.cancel() }
    private func operation<T: Sendable>(_ body: @escaping (CompletionGate<T>) -> Void) async throws -> T {
        let remaining = deadline - ProcessInfo.processInfo.systemUptime
        guard remaining > 0 else { connection.cancel(); throw PrinterError.timeout }
        let activeConnection = connection
        let callbackQueue = queue
        return try await withCheckedThrowingContinuation { continuation in
            let gate = CompletionGate(continuation)
            callbackQueue.asyncAfter(deadline: .now() + min(5, remaining)) {
                if gate.finish(.failure(PrinterError.timeout)) { activeConnection.cancel() }
            }
            body(gate)
        }
    }
    func open() async throws {
        let _: Bool = try await operation { gate in
            self.connection.stateUpdateHandler = { state in
                switch state {
                case .ready: gate.finish(.success(true))
                case .failed, .cancelled: gate.finish(.failure(PrinterError.disconnected))
                default: break
                }
            }
            self.connection.start(queue: self.queue)
        }
    }
    func send(_ data: Data) async throws {
        let _: Bool = try await operation { gate in
            self.connection.send(content: data, completion: .contentProcessed { error in
                gate.finish(error == nil ? .success(true) : .failure(PrinterError.disconnected))
            })
        }
    }
    func receive() async throws -> Data {
        let activeConnection = connection
        try await operation { gate in
            activeConnection.receive(minimumIncompleteLength: 1, maximumLength: 65_536) { data, _, complete, error in
                if let data, !data.isEmpty { gate.finish(.success(data)) }
                else { gate.finish(.failure(PrinterError.disconnected)) }
                if error != nil || complete { activeConnection.cancel() }
            }
        }
    }
    func datagram() async throws -> Data {
        let activeConnection = connection
        try await operation { gate in
            activeConnection.receiveMessage { data, _, _, error in
                if error != nil { gate.finish(.failure(PrinterError.disconnected)); return }
                // Cancellation can complete a receive with no data and no NWError.
                guard let data else { gate.finish(.failure(PrinterError.disconnected)); return }
                guard !data.isEmpty, data.count <= 8192 else { gate.finish(.failure(PrinterError.malformed)); return }
                gate.finish(.success(data))
            }
        }
    }
    func exactly(_ count: Int) async throws -> Data {
        guard count >= 0, count <= 65_536 else { throw PrinterError.malformed }
        while buffer.count < count {
            let next = try await receive()
            guard buffer.count + next.count <= 131_072 else { throw PrinterError.malformed }
            buffer.append(next)
        }
        let value = Data(buffer.prefix(count)); buffer.removeFirst(count); return value
    }
    func mqttPacket() async throws -> (UInt8, Data) {
        let first = (try await exactly(1))[0]
        var remaining = 0, multiplier = 1, bytes = 0
        while true {
            let byte = (try await exactly(1))[0]; bytes += 1
            remaining += Int(byte & 127) * multiplier
            guard bytes <= 4, remaining <= 65_536 else { throw PrinterError.malformed }
            if byte & 128 == 0 { break }; multiplier *= 128
        }
        guard bytes == 1 || remaining >= Int(pow(128.0, Double(bytes - 1))) else { throw PrinterError.malformed }
        return (first, try await exactly(remaining))
    }
}

enum MQTTWire {
    static func word(_ n: UInt16) -> Data { Data([UInt8(n >> 8), UInt8(n & 255)]) }
    static func string(_ value: String) throws -> Data {
        let bytes = Data(value.utf8); guard bytes.count <= 65535 else { throw PrinterError.malformed }; return word(UInt16(bytes.count)) + bytes
    }
    static func packet(_ type: UInt8, _ payload: Data) -> Data {
        var remaining = payload.count, result = Data([type])
        repeat { var byte = UInt8(remaining % 128); remaining /= 128; if remaining > 0 { byte |= 128 }; result.append(byte) } while remaining > 0
        return result + payload
    }
    static func connect(client: String, code: String) throws -> Data {
        try packet(0x10, string("MQTT") + Data([4, 0xC2, 0, 20]) + string(client) + string("elegoo") + string(code))
    }
    static func subscribe(topics: [String]) throws -> Data {
        var payload = word(1)
        for topic in topics { payload += try string(topic) + Data([1]) }
        return packet(0x82, payload)
    }
    static func publish(topic: String, body: Data, packetID: UInt16) throws -> Data {
        try packet(0x32, string(topic) + word(packetID) + body)
    }
    static func publication(_ header: UInt8, _ bytes: Data) throws -> (String, Data, UInt16?) {
        guard header >> 4 == 3, header & 1 == 0, bytes.count >= 2 else { throw PrinterError.malformed }
        let length = Int(bytes[0]) * 256 + Int(bytes[1]); var offset = 2 + length
        guard length > 0, length <= 200, bytes.count >= offset,
              let topic = String(data: bytes[2..<offset], encoding: .utf8) else { throw PrinterError.malformed }
        let qos = (header >> 1) & 3; guard qos <= 1 else { throw PrinterError.malformed }
        guard qos != 0 || header & 8 == 0 else { throw PrinterError.malformed }
        var id: UInt16?
        if qos == 1 {
            guard bytes.count >= offset + 2 else { throw PrinterError.malformed }
            id = UInt16(bytes[offset]) * 256 + UInt16(bytes[offset + 1]); offset += 2
            guard id != 0 else { throw PrinterError.malformed }
        }
        return (topic, Data(bytes.dropFirst(offset)), id)
    }
}
