import SwiftUI
import UIKit

@main
struct GPSFollowApp: App {
    @StateObject private var model = GPSModel()
    @Environment(\.scenePhase) private var scenePhase
    var body: some Scene {
        WindowGroup {
            ContentView(model: model)
                .onChange(of: scenePhase) { _, phase in
                    // A permission sheet temporarily makes the app inactive in the foreground.
                    if phase == .background { model.foregroundChanged(active: false) }
                }
        }
    }
}

private let supportEmail = "nate@tracktorqueautomotive.com"

struct ContactUsView: View {
    @Environment(\.openURL) private var openURL
    var body: some View {
        NavigationStack {
            Form {
                Section("Contact Us") {
                    Text("Updates, suggestions, bug reports, and compatibility requests are greatly appreciated.")
                    LabeledContent("Business email", value: supportEmail)
                    Button("Email Nate") {
                        if let url = URL(string: "mailto:\(supportEmail)?subject=GPS%20Follow%20feedback") { openURL(url) }
                    }
                    .buttonStyle(.borderedProminent).tint(.red)
                }
                Section("Helpful details to include") {
                    Text("Phone model and iOS version")
                    Text("Flight stack: ArduPilot, PX4, iNav, or Betaflight")
                    Text("Connection type and the exact error message")
                    Text("Never include pairing keys, passwords, or binding phrases.")
                }
                AppBrandFooter()
            }
            .modifier(DroneMatrixSurface())
            .navigationTitle("Contact Us")
        }
    }
}

struct WelcomeContactView: View {
    @Binding var hideOnLaunch: Bool
    @Binding var isPresented: Bool
    @Environment(\.openURL) private var openURL
    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 18) {
                Image(systemName: "paperplane.circle.fill").font(.system(size: 54)).foregroundStyle(.red)
                Text("Welcome to GPS Follow").font(.largeTitle.bold())
                Text("If you find an issue or want an update, suggestion, device, or flight-controller profile added, please get in touch. Your feedback is greatly appreciated.")
                Button("Email \(supportEmail)") {
                    if let url = URL(string: "mailto:\(supportEmail)?subject=GPS%20Follow%20feedback") { openURL(url) }
                }
                .buttonStyle(.borderedProminent).tint(.red)
                Toggle("Do not show again", isOn: $hideOnLaunch)
                Text("You can always reopen Contact Us from the app tabs. Closing this screen never blocks the app.")
                    .font(.footnote).foregroundStyle(.secondary)
                Spacer()
                Button("Continue") { isPresented = false }
                    .buttonStyle(.bordered).frame(maxWidth: .infinity)
            }
            .padding(24)
            .modifier(DroneMatrixSurface())
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Close") { isPresented = false } } }
        }
    }
}

@MainActor struct ContentView: View {
    @ObservedObject var model: GPSModel
    @State private var revealSecret = false
    @StateObject private var library = CADLibrary()
    @State private var phoneIP = LocalNetworkInfo.phoneWiFiIPv4()
    @StateObject private var pcBrowser = PCBrowser()
    @State private var setupMessage: String?
    @AppStorage("hide_welcome_contact") private var hideWelcomeContact = false
    @State private var showWelcomeContact = false

    var body: some View {
        TabView {
            connectionView
                .tabItem { Label("Connect / GPS", systemImage: "location.circle") }
            CADLibraryView(gps: model, library: library)
                .tabItem { Label("Drone CAD", systemImage: "cube.transparent") }
            PrinterView(library: library)
                .tabItem { Label("Printer", systemImage: "printer") }
            FlightLogsView(gps: model)
                .tabItem { Label("Flight Logs", systemImage: "doc.text.magnifyingglass") }
            ControllerProfilesView()
                .tabItem { Label("Controllers", systemImage: "gamecontroller") }
            AppProfilesView()
                .tabItem { Label("App Setup", systemImage: "slider.horizontal.3") }
            helpView
                .tabItem { Label("Q&A", systemImage: "questionmark.circle") }
            ContactUsView()
                .tabItem { Label("Contact Us", systemImage: "envelope") }
        }
        .font(.system(.body, design: .rounded))
        .tint(.red)
        .preferredColorScheme(.dark)
        .onReceive(Timer.publish(every: 0.2, on: .main, in: .common).autoconnect()) { model.now = $0 }
        .onReceive(Timer.publish(every: 5, on: .main, in: .common).autoconnect()) { _ in phoneIP = LocalNetworkInfo.phoneWiFiIPv4() }
        .onAppear { if !hideWelcomeContact { showWelcomeContact = true } }
        .sheet(isPresented: $showWelcomeContact) {
            WelcomeContactView(hideOnLaunch: $hideWelcomeContact, isPresented: $showWelcomeContact)
                .interactiveDismissDisabled(false)
        }
    }

    private var connectionView: some View {
        NavigationStack {
            Form {
                Section("Set up without digging") {
                    PasteButton(payloadType: String.self) { values in
                        guard let text = values.first else { return }
                        do { setupMessage = model.applySetup(try PCSetup.parse(text)) ? "PC setup loaded privately. Check the connection below, then tap Start." : "Setup was not applied; check the message below." }
                        catch { setupMessage = "That is not a valid PC setup card. Use Copy iPhone setup in the companion and paste it here." }
                    }.disabled(model.running)
                    Text("On the PC, choose Copy iPhone setup. Paste here transfers the current PC address, port, private key and matching operating area in one explicit step. It never starts GPS sharing or flight.")
                        .font(.footnote).foregroundStyle(.secondary)
                    if let setupMessage { Text(setupMessage).font(.subheadline) }
                    Button("Find my PC on Wi-Fi") { pcBrowser.start() }.disabled(model.running)
                    Text(pcBrowser.status).font(.footnote).foregroundStyle(.secondary)
                    ForEach(pcBrowser.services) { pc in
                        Button("Use \(pc.name) · \(pc.ip):\(pc.port) · \(pc.version)") {
                            guard !model.running else { return }
                            if model.mode != .relay { model.mode = .relay; model.modeChanged() }
                            model.ip = pc.ip; model.port = String(pc.port)
                            setupMessage = "Selected PC address. Your private key was kept; encrypted pairing still needs to succeed."
                        }.disabled(model.running)
                    }
                }
                Section {
                    LabeledContent("This iPhone Wi-Fi IP", value: phoneIP ?? "Wi-Fi address not detected")
                    LabeledContent(model.mode == .relay ? "PC Wi-Fi IP" : "Telemetry Wi-Fi IP", value: model.ip.isEmpty ? "Copy from the PC companion" : model.ip)
                    LabeledContent("UDP port", value: model.port)
                    LabeledContent("Pairing key", value: model.secret.isEmpty ? "Not entered" : "Saved privately / masked")
                    Text(versionText).font(.footnote).foregroundStyle(.secondary)
                    Text("Relay compatibility: AES-GCM v2 · Windows companion 1.1 or newer using protocol v2.")
                        .font(.footnote).foregroundStyle(.secondary)
                } header: {
                    Text("Your connection at a glance")
                } footer: {
                    Text("The iPhone address is read from this phone’s Wi-Fi. Choose a discovered PC or paste its current setup card. Discovery shares no key or GPS; a selected address is not trusted until encrypted pairing succeeds. Never put the iPhone address in the PC-address field.")
                }
                Section("Connect in four steps") {
                    Text("1. Open the matching Windows companion on the PC.")
                    Text("2. Put the phone and PC on the same secured local Wi-Fi.")
                    Text("3. Copy the PC Wi-Fi IP, UDP port and private pairing key shown together on the companion’s Connect screen.")
                    Text("4. Start bench pairing on the PC, then tap Start GPS sharing here.")
                }
                Section {
                    LabeledContent("Target", value: model.targetRoleText)
                    LabeledContent("Target lock", value: model.targetRole == .owner ? "Owner phone only" : model.targetID)
                    LabeledContent("Invitation", value: model.invitationText)
                    Label(model.status, systemImage: model.running ? "location.fill" : "location.slash")
                        .font(.headline)
                    LabeledContent("GPS accuracy", value: model.accuracyText)
                    LabeledContent("Recommended separation", value: model.minimumSeparationText)
                    LabeledContent("Fix age", value: model.fixAge)
                    Text(model.linkStatus).font(.subheadline).foregroundStyle(.secondary)
                    LabeledContent(model.mode == .direct ? "Target packets queued" : "Targets accepted by relay", value: "\(model.targetCount)")
                    Button(model.running ? "Stop GPS sharing" : "Start GPS sharing") {
                        model.running ? model.stop() : model.start()
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.red)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 6)
                } footer: {
                    Text("Keep this app open. GPS sharing stops when you leave it or lock the phone. Guest Target uses a separate expiring key and never receives the owner's key. Start shares a GPS target; it does not arm the drone or enable Follow.")
                }
                if let error = model.error {
                    Section { Text(error).foregroundStyle(.red) }
                }
                Section {
                    Picker("Transport", selection: $model.mode) {
                        ForEach(TransportMode.allCases) { Text($0.rawValue).tag($0) }
                    }
                    .onChange(of: model.mode) { _, _ in model.modeChanged() }
                    TextField(model.mode == .direct ? "Telemetry Wi-Fi address" : "PC Wi-Fi address (not this iPhone)", text: $model.ip)
                        .keyboardType(.decimalPad).textInputAutocapitalization(.never).autocorrectionDisabled()
                    TextField("UDP port", text: $model.port).keyboardType(.numberPad)
                    if revealSecret {
                        TextField("64-character key", text: $model.secret)
                            .textInputAutocapitalization(.never).autocorrectionDisabled().font(.system(.caption, design: .monospaced))
                    } else {
                        SecureField(model.mode == .direct ? "MAVLink signing key" : "Relay pairing key", text: $model.secret)
                            .textInputAutocapitalization(.never).autocorrectionDisabled()
                    }
                    Toggle("Show key", isOn: $revealSecret)
                } header: {
                    Text("Connection")
                } footer: {
                    Text(model.mode == .direct ? "Requires compatible Wi-Fi MAVLink telemetry with signed MAVLink 2 already configured on your controller. The module model still needs to be confirmed." :
                        "Encrypted phone connection. Use the matching secure companion and its private pairing key on the same local Wi-Fi.")
                }
                .disabled(model.running)
                Section {
                    Button("Use current location as center") { model.useCurrentLocationAsCenter() }
                    TextField("Center latitude", text: $model.originLat).keyboardType(.numbersAndPunctuation)
                    TextField("Center longitude", text: $model.originLon).keyboardType(.numbersAndPunctuation)
                    LabeledContent("Radius (m)") { TextField("50", text: $model.radiusText).keyboardType(.decimalPad).multilineTextAlignment(.trailing) }
                    LabeledContent("Height above launch level (m)") { TextField("5", text: $model.heightText).keyboardType(.decimalPad).multilineTextAlignment(.trailing) }
                } header: {
                    Text("Operating area")
                } footer: {
                    Text("Height is above the aircraft’s home/launch level. It does not measure clearance above the phone, roofs, hills or ground. Match the prepared Follow offset and keep your transmitter connected for pilot control.")
                }
                .disabled(model.running)
                Section {
                    Text("GPS target only. This app does not identify landing surfaces or provide obstacle avoidance.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
            .modifier(DroneMatrixSurface())
            .safeAreaInset(edge: .bottom, spacing: 0) {
                brandFooter
            }
            .navigationTitle("Nate’s Drone")
            .onAppear { if !model.running { pcBrowser.start() } }
            .onDisappear { pcBrowser.stop() }
            .scrollDismissesKeyboard(.interactively)
            .toolbar { ToolbarItemGroup(placement: .keyboard) { Spacer(); Button("Done") {
                UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
            } } }
        }
    }

    private var brandFooter: some View {
        Text("Made by Nate Wrench 2026")
            .font(.footnote)
            .foregroundStyle(.secondary)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 8)
            .background(.bar)
    }

    private var versionText: String {
        let version = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "Unknown"
        let build = Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "Unknown"
        return "Version \(version) · build \(build)"
    }

    private func controlRow(_ control: String, _ action: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(control).font(.subheadline.weight(.semibold))
            Text(action).font(.subheadline).foregroundStyle(.secondary)
        }
        .padding(.vertical, 3)
    }

    private var helpView: some View {
        NavigationStack {
            Form {
                Section {
                    Label("Your drone controls and GPS connection", systemImage: "info.circle")
                        .font(.headline)
                    Text("This guide describes the saved AERO radio profile. The Windows companion currently validates phone GPS on the bench; it does not connect to or command the flight controller.")
                        .font(.subheadline).foregroundStyle(.secondary)
                    Text(versionText).font(.footnote).foregroundStyle(.secondary)
                }

                Section("Drone control map") {
                    DisclosureGroup("Buttons 1–6 · flight modes") {
                        controlRow("1 · Stabilize", "Self-levels the drone. You control its altitude and movement.")
                        controlRow("2 · AltHold", "Holds altitude while you steer. It can still drift horizontally.")
                        controlRow("3 · Loiter", "GPS position hold and hover. It needs healthy navigation.")
                        controlRow("4 · Brake", "Brakes and holds position when navigation is healthy.")
                        controlRow("5 · RTL", "Return to Launch: returns toward the saved launch position. It needs healthy navigation.")
                        controlRow("6 · Land", "Descends to land. It cannot identify a safe landing surface.")
                    }
                    DisclosureGroup("SA · arm, disarm and return") {
                        controlRow("UP · Disarm", "Requests disarm and can stop the motors. This is not a pause button in flight.")
                        controlRow("MIDDLE · Arm", "Requests arming, subject to the aircraft checks. Moving through this position can request arm; S1 is the planned gear knob, with travel not commissioned.")
                        controlRow("DOWN · RTL", "Requests Return to Launch on its separate channel.")
                    }
                    DisclosureGroup("SD · three-position mode override") {
                        controlRow("UP", "Uses the selected button 1–6.")
                        controlRow("MIDDLE", "Overrides the buttons to AltHold.")
                        controlRow("DOWN · Land", "Overrides the buttons to Land. It does not select Stabilize or a battery-bypass AltHold mode.")
                    }
                    DisclosureGroup("SF · two-position Brake switch") {
                        controlRow("DOWN", "Requests Brake.")
                        controlRow("UP", "Restores the previous selected mode only if the controller is still in Brake. Another mode command can override it; this switch does not lock mode priority.")
                    }
                    DisclosureGroup("SE · obstacle-avoidance button") {
                        Text("Successive presses latch avoidance ON and OFF. The front and side sensors keep reporting in either state.")
                        Text("The saved behavior is Stop in Loiter: braking before detected obstacles. It does not add an automatic swerve fallback, and there is no rear sensor coverage.")
                        Text("Missing, stale or implausible LiDAR data is marked unavailable and excluded from that direction. It is never changed into a fake near obstacle or fake clear path. Stabilize and AltHold remain pilot-controlled without horizontal proximity; with avoidance enabled, a failed required direction can request a controlled stop until recovery or until avoidance is deliberately turned off.")
                        Text("Sensor isolation does not bypass GPS, compass, receiver, EKF or battery failsafes.")
                    }
                    DisclosureGroup("SB and SC") {
                        controlRow("SB · AutoTune", "AutoTune is assigned. Physical activation has not been verified; do not treat it as a completed tune.")
                        controlRow("SC · LEDs preserved", "SC retains its existing radio lighting controls. It is not assigned to landing gear.")
                        controlRow("M5 · external LED switch signal", "M5 provides a constant high PWM control signal. It does not power the LEDs; LED power remains on the external switch load terminals.")
                        controlRow("S1 · proportional gear · CH8", "S1 moves all four landing-gear servos on M6–M9 according to knob position. Initial output is limited to 1450–1550 microseconds. Each linkage direction and safe endpoint still needs mechanical commissioning. SB AutoTune is restored.")
                    }
                    DisclosureGroup("AERO GEAR LAB · bench only") {
                        Text("AERO GEAR LAB is a separate TX15 model for supported, prop-off landing-gear commissioning. Only S1/CH8 is active; throttle is held low and every other control channel is locked inactive.")
                        Text("Never select AERO GEAR LAB for flight. Return to AERO after recording each leg direction and safe endpoint.")
                    }
                    DisclosureGroup("TX15 telemetry and battery estimate") {
                        Text("Page one restores the four rotary gauges. Additional pages show FC voltage, GPS, speed, altitude, attitude, flight mode and radio-link readings.")
                        Text("The 6S battery page labels its voltage-based percentage EST. Load and voltage sag change this estimate. Consumed mAh is not calibrated; this display does not change battery failsafes.")
                        Text("Individual LiDAR and ESC data require a matching telemetry transport and decoder; unavailable data must not be treated as valid zero readings.")
                    }
                    DisclosureGroup("Where is the Follow button?") {
                        Text("Follow is disabled: FOLL_ENABLE is 0, and no Follow button is assigned. This app publishes a GPS target only. It does not enable Follow, arm the drone, or change its flight mode, home position or parameters.")
                    }
                }

                Section("SD DOWN landing override") {
                    Text("The latest verified TX15 AERO profile maps SD DOWN to Land. The aircraft descends using ArduPilot Land behavior; it cannot identify whether the surface below is safe.")
                    Text("SD MIDDLE is normal AltHold. SD UP returns control to buttons 1–6. Button 6 also selects Land. SA UP can disarm and stop the motors; do not use it as a flight pause.")
                }

                Section("Connection Q&A") {
                    DisclosureGroup("How do I follow someone else?") {
                        Text("On the Windows companion, create a temporary Guest Target invitation for that person's phone. Send only the expiring setup card, then have them paste it into this app and keep the app open. The companion must explicitly run that guest configuration. Stop the relay or delete the guest file to revoke it.")
                        Text("Use at least the recommended separation shown on Connect. If the guest GPS becomes stale, inaccurate, jumps, exceeds walking speed, leaves the operating area, or the invitation expires, target publication stops.")
                        Text("The app never picks a person by proximity or camera. Follow Me accepts only the owner setup. Follow Guest accepts only the one guest identity shown under Target lock, and the companion requires that exact ID when starting the guest relay.")
                    }
                    DisclosureGroup("Is my phone connection encrypted?") {
                        Text("Yes, the matching secure app and Windows companion encrypt and check each phone-to-PC message, including replies. They reject older, unencrypted relay messages.")
                        Text("This protects that connection. It does not secure every radio or controller link, and no system is hackproof. Keep the Wi-Fi secured and the pairing key private.")
                        Text("Direct telemetry is a separate advanced option. Signed MAVLink checks who sent a message; it does not hide the coordinates. A compatible, secured gateway and verified controller signing are still required.")
                    }
                    DisclosureGroup("How do I connect to the Windows companion?") {
                        Text("Connect the iPhone and PC to the same secured local Wi-Fi network. In Connection, choose Optional Windows relay.")
                        Text("Use the PC’s current Wi-Fi address and UDP port shown on the companion. The companion refreshes the PC address from Windows; do not reuse an old saved address when you change networks. This app shows the iPhone’s own Wi-Fi address separately.")
                        Text("Use the private pairing key from the companion. Match the center latitude, center longitude, radius and height exactly on both devices. Saving fresh companion settings creates a new key; update the phone’s key too.")
                        Text("Start bench pairing on the PC, then Start GPS sharing here. Keep this app open and the phone unlocked.")
                    }
                    DisclosureGroup("Which iPhone permissions do I need?") {
                        Text("Allow location While Using the App with Precise Location enabled. Allow Local Network access when prompted. If you denied a permission, open iPhone Settings for GPS Follow and change it there.")
                        Text("Use a clear view of the sky for better GPS accuracy. GPS sharing stops when this app goes into the background or the phone locks.")
                    }
                    DisclosureGroup("Why does it say controller unavailable?") {
                        Text("That is expected with the current bench-only Windows companion. It can check fresh, encrypted phone GPS but has no flight-controller connection. Accepted phone targets do not mean the drone is connected or ready to fly.")
                    }
                    DisclosureGroup("Does this need internet?") {
                        Text("Runtime pairing uses local Wi-Fi and does not need internet. Both devices must still share a working local network. A secured local router can work offline; Windows hotspot availability without internet depends on the adapter and driver.")
                        Text("Internet is needed separately to download a new app build or package.")
                    }
                    DisclosureGroup("Can I use the H743’s built-in Bluetooth?") {
                        Text("The current onboard Bluetooth module uses Classic SPP. It is not an iPhone BLE/GATT telemetry device, and changing H743 firmware cannot create the required BLE hardware. Use the Windows relay or an independently verified compatible Wi-Fi telemetry gateway.")
                        Text("App Setup selects Nate’s MicoAir H743 v2 relay preset by default. It records COM9 at 115200 as the expected Windows path, but the companion still verifies the live device before use instead of trusting a saved port name.")
                    }
                    DisclosureGroup("Can the TX15 Max connect by Bluetooth?") {
                        Text("Only when a compatible optional Bluetooth module is physically installed and the exact TX15 EdgeTX target is built with Bluetooth support. Firmware cannot create hardware that is missing.")
                        Text("That EdgeTX link is for trainer or telemetry-mirror data. It is not the MAVLink Follow control path. Choose the TX15 optional-module preset in App Setup only after its hardware and UART4 connection are independently verified.")
                    }
                    DisclosureGroup("What do center, radius and height mean?") {
                        Text("The center and radius define the allowed GPS target area. Using the phone’s current location as center does not change the aircraft’s home position; update the companion to the same center before starting.")
                        Text("Height is above the aircraft’s home or launch level. It does not measure clearance above the phone, ground, roofs or hills. This app does not identify landing surfaces or provide obstacle avoidance.")
                    }
                    DisclosureGroup("Where should I keep the pairing key?") {
                        Text("The companion stores it encrypted for your Windows user. Use its Show key locally or Copy key control to transfer it to your phone. Keep the key private; do not put it in public downloads, screenshots or the app source.")
                    }
                }

                Section("Updates and installation") {
                    LabeledContent("Installed iPhone app", value: versionText)
                    Text("The desktop and iPhone app have separate version numbers. For relay pairing, both must support AES-GCM protocol v2; a matching number alone is not proof of compatibility.")
                    DisclosureGroup("How do I get the latest version?") {
                        Text("Download the latest verified IPA from the app’s release bundle and use the matching Windows companion package. The build page below shows which native builds passed.")
                        Text("Some build artifacts are an unsigned app ZIP rather than an IPA. For Sideloadly, choose the packaged GPSFollow IPA supplied with the release. Downloading a build does not install it automatically.")
                        Link("Get latest app", destination: URL(string: "https://github.com/IPAcquired/gps-follow-companion/releases/latest")!)
                        Link("Check build status", destination: URL(string: "https://github.com/IPAcquired/gps-follow-companion/actions/workflows/ios-build.yml")!)
                    }
                    DisclosureGroup("How do I install or renew the iPhone app?") {
                        Text("Load the latest IPA in your existing Sideloadly installation and sign it using the same Apple ID locally. You handle Apple authentication and verification; never enter credentials in chat.")
                        Text("A free personal signing profile normally needs renewal after seven days. Re-sign and reinstall through Sideloadly when needed. This app has no automatic over-the-air updater, and the download is unsigned until you sign it for your phone.")
                    }
                }
            }
            .modifier(DroneMatrixSurface())
            .safeAreaInset(edge: .bottom, spacing: 0) { brandFooter }
            .navigationTitle("Q&A")
        }
    }
}

// Static artwork: no frame timer, animation or network work competes with GPS.
// Reduced Motion uses the same still composition with quieter contrast.
struct DroneMatrixBackground: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @AppStorage("appearance_preset") private var appearanceName = AppBackgroundPreset.nwMatrix.rawValue
    var body: some View {
        let preset = AppBackgroundPreset(rawValue: appearanceName) ?? .nwMatrix
        Canvas { context, size in
            let logoWidth = min(size.width * 0.86, 440)
            let origin = CGPoint(x: (size.width - logoWidth) / 2, y: size.height * 0.24)
            func monogram(_ points: [(CGFloat, CGFloat)], color: Color) {
                var path = Path()
                for (index, point) in points.enumerated() {
                    let position = CGPoint(x: origin.x + point.0 * logoWidth,
                                           y: origin.y + point.1 * logoWidth)
                    if index == 0 { path.move(to: position) } else { path.addLine(to: position) }
                }
                context.stroke(path, with: .color(color.opacity(reduceMotion ? 0.05 : 0.08)),
                               style: StrokeStyle(lineWidth: logoWidth * 0.08, lineCap: .round, lineJoin: .round))
            }
            if preset == .nwMatrix {
                monogram([(0.08, 0.68), (0.08, 0.08), (0.44, 0.68), (0.44, 0.08)], color: preset.accent)
                monogram([(0.44, 0.08), (0.57, 0.68), (0.74, 0.33), (0.88, 0.68), (0.98, 0.08)], color: .white)
            }
            let spacing: CGFloat = 28
            let columns = min(18, max(1, Int(size.width / spacing)))
            let rows = min(36, max(1, Int(size.height / spacing)))
            for column in 0..<columns where preset.showsMatrix || preset.showsCarbon {
                for row in 0..<rows where (column * 5 + row * 3) % 7 < 3 {
                    let glyph = (column + row) % 2 == 0 ? "0" : "1"
                    let opacity = reduceMotion ? 0.09 : 0.13
                    context.draw(Text(glyph).font(.system(size: 12, design: .monospaced))
                        .foregroundColor(preset.accent.opacity(opacity)),
                        at: CGPoint(x: CGFloat(column) * spacing + 14, y: CGFloat(row) * spacing + 14))
                }
            }
        }
        .background(preset.background)
        .ignoresSafeArea()
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}

struct DroneMatrixSurface: ViewModifier {
    func body(content: Content) -> some View {
        content
            .scrollContentBackground(.hidden)
            .background { DroneMatrixBackground() }
    }
}
