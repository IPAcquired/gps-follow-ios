import SwiftUI

@main
struct GPSFollowApp: App {
    @StateObject private var model = GPSModel()
    @Environment(\.scenePhase) private var scenePhase
    var body: some Scene {
        WindowGroup {
            ContentView(model: model)
                .onChange(of: scenePhase) { _, phase in
                    // A permission sheet temporarily makes the app inactive in the foreground.
                    if phase == .background { model.foregroundChanged(active: false) }
                }
        }
    }
}

struct ContentView: View {
    @ObservedObject var model: GPSModel
    @State private var revealSecret = false

    var body: some View {
        TabView {
            connectionView
                .tabItem { Label("Connection", systemImage: "location.circle") }
            helpView
                .tabItem { Label("Q&A", systemImage: "questionmark.circle") }
        }
        .onReceive(Timer.publish(every: 0.2, on: .main, in: .common).autoconnect()) { model.now = $0 }
    }

    private var connectionView: some View {
        NavigationStack {
            Form {
                Section {
                    Label(model.status, systemImage: model.running ? "location.fill" : "location.slash")
                        .font(.headline)
                    LabeledContent("GPS accuracy", value: model.accuracyText)
                    LabeledContent("Fix age", value: model.fixAge)
                    Text(model.linkStatus).font(.subheadline).foregroundStyle(.secondary)
                    LabeledContent(model.mode == .direct ? "Target packets queued" : "Targets accepted by relay", value: "\(model.targetCount)")
                    Button(model.running ? "Stop GPS sharing" : "Start GPS sharing") {
                        model.running ? model.stop() : model.start()
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(model.running ? .red : .blue)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 6)
                } footer: {
                    Text("Keep this app open. GPS sharing stops when you leave it or lock the phone. Start shares a GPS target; it does not arm the drone or enable Follow. Follow is currently disabled on your controller.")
                }
                if let error = model.error {
                    Section { Text(error).foregroundStyle(.red) }
                }
                Section {
                    Picker("Transport", selection: $model.mode) {
                        ForEach(TransportMode.allCases) { Text($0.rawValue).tag($0) }
                    }
                    .onChange(of: model.mode) { _, _ in model.modeChanged() }
                    TextField(model.mode == .direct ? "Telemetry Wi-Fi address" : "Laptop Wi-Fi address", text: $model.ip)
                        .keyboardType(.decimalPad).textInputAutocapitalization(.never).autocorrectionDisabled()
                    TextField("UDP port", text: $model.port).keyboardType(.numberPad)
                    if revealSecret {
                        TextField("64-character key", text: $model.secret)
                            .textInputAutocapitalization(.never).autocorrectionDisabled().font(.system(.caption, design: .monospaced))
                    } else {
                        SecureField(model.mode == .direct ? "MAVLink signing key" : "Relay pairing key", text: $model.secret)
                            .textInputAutocapitalization(.never).autocorrectionDisabled()
                    }
                    Toggle("Show key", isOn: $revealSecret)
                } header: {
                    Text("Connection")
                } footer: {
                    Text(model.mode == .direct ? "Requires compatible Wi-Fi MAVLink telemetry with signed MAVLink 2 already configured on your controller. The module model still needs to be confirmed." :
                        "Optional fallback: the iPhone and laptop must share a private Wi-Fi network. Use the key from your relay configuration.")
                }
                .disabled(model.running)
                Section {
                    Button("Use current location as center") { model.useCurrentLocationAsCenter() }
                    TextField("Center latitude", text: $model.originLat).keyboardType(.numbersAndPunctuation)
                    TextField("Center longitude", text: $model.originLon).keyboardType(.numbersAndPunctuation)
                    LabeledContent("Radius (m)") { TextField("50", text: $model.radiusText).keyboardType(.decimalPad).multilineTextAlignment(.trailing) }
                    LabeledContent("Height above launch level (m)") { TextField("5", text: $model.heightText).keyboardType(.decimalPad).multilineTextAlignment(.trailing) }
                } header: {
                    Text("Operating area")
                } footer: {
                    Text("Height is above the aircraft’s home/launch level. It does not measure clearance above the phone, roofs, hills or ground. Match the prepared Follow offset and keep your transmitter connected for pilot control.")
                }
                .disabled(model.running)
                Section {
                    Text("GPS target only. This app does not identify landing surfaces or provide obstacle avoidance.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
            .safeAreaInset(edge: .bottom, spacing: 0) {
                brandFooter
            }
            .navigationTitle("GPS Follow")
        }
    }

    private var brandFooter: some View {
        Text("Made by Nate Wrench 2026")
            .font(.footnote)
            .foregroundStyle(.secondary)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 8)
            .background(.bar)
    }

    private func controlRow(_ control: String, _ action: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(control).font(.subheadline.weight(.semibold))
            Text(action).font(.subheadline).foregroundStyle(.secondary)
        }
        .padding(.vertical, 3)
    }

    private var helpView: some View {
        NavigationStack {
            Form {
                Section {
                    Label("Your drone controls and GPS connection", systemImage: "info.circle")
                        .font(.headline)
                    Text("This guide describes the saved AERO radio profile. The Windows companion currently validates phone GPS on the bench; it does not connect to or command the flight controller.")
                        .font(.subheadline).foregroundStyle(.secondary)
                }

                Section("Drone control map") {
                    DisclosureGroup("Buttons 1–6 · flight modes") {
                        controlRow("1 · Stabilize", "Self-levels the drone. You control its altitude and movement.")
                        controlRow("2 · AltHold", "Holds altitude while you steer. It can still drift horizontally.")
                        controlRow("3 · Loiter", "GPS position hold and hover. It needs healthy navigation.")
                        controlRow("4 · Brake", "Brakes and holds position when navigation is healthy.")
                        controlRow("5 · RTL", "Return to Launch: returns toward the saved launch position. It needs healthy navigation.")
                        controlRow("6 · Land", "Descends to land. It cannot identify a safe landing surface.")
                    }
                    DisclosureGroup("SA · arm, disarm and return") {
                        controlRow("UP · Disarm", "Requests disarm and can stop the motors. This is not a pause button in flight.")
                        controlRow("MIDDLE · Arm", "Requests arming, subject to the controller’s checks.")
                        controlRow("DOWN · RTL", "Requests Return to Launch. Passing through MIDDLE can issue an arm request.")
                    }
                    DisclosureGroup("SD · three-position mode override") {
                        controlRow("UP", "Uses the selected button 1–6.")
                        controlRow("MIDDLE", "Overrides the buttons to AltHold.")
                        controlRow("DOWN", "Overrides the buttons to Stabilize.")
                    }
                    DisclosureGroup("SF · two-position Brake switch") {
                        controlRow("DOWN", "Requests Brake.")
                        controlRow("UP", "Restores the previous selected mode only if the controller is still in Brake. Another mode command can override it; this switch does not lock mode priority.")
                    }
                    DisclosureGroup("SE · obstacle-avoidance button") {
                        Text("Successive presses latch avoidance ON and OFF. The front and side sensors keep reporting in either state.")
                        Text("The saved behavior is Stop in Loiter: braking before detected obstacles. It does not add an automatic swerve fallback, and there is no rear sensor coverage.")
                    }
                    DisclosureGroup("SB and SC") {
                        controlRow("SB · AutoTune", "AutoTune is assigned. Physical activation has not been verified; do not treat it as a completed tune.")
                        controlRow("SC · radio lights", "Changes the transmitter’s RGB lights only.")
                    }
                    DisclosureGroup("Where is the Follow button?") {
                        Text("Follow is disabled: FOLL_ENABLE is 0, and no Follow button is assigned. This app publishes a GPS target only. It does not enable Follow, arm the drone, or change its flight mode, home position or parameters.")
                    }
                }

                Section("Connection Q&A") {
                    DisclosureGroup("How do I connect to the Windows companion?") {
                        Text("Connect the iPhone and PC to the same secured local Wi-Fi network. In Connection, choose Optional Windows relay.")
                        Text("Enter the PC’s current private Wi-Fi address and UDP port 45678. The PC address last checked was 192.168.1.152; addresses can change when you move networks, so check the companion’s current PC address.")
                        Text("Use the private pairing key from the companion. Match the center latitude, center longitude, radius and height exactly on both devices. Saving fresh companion settings creates a new key; update the phone’s key too.")
                        Text("Start bench pairing on the PC, then Start GPS sharing here. Keep this app open and the phone unlocked.")
                    }
                    DisclosureGroup("Which iPhone permissions do I need?") {
                        Text("Allow location While Using the App with Precise Location enabled. Allow Local Network access when prompted. If you denied a permission, open iPhone Settings for GPS Follow and change it there.")
                        Text("Use a clear view of the sky for better GPS accuracy. GPS sharing stops when this app goes into the background or the phone locks.")
                    }
                    DisclosureGroup("Why does it say controller unavailable?") {
                        Text("That is expected with the current bench-only Windows companion. It can check fresh, authenticated phone GPS but has no flight-controller connection. Accepted phone targets do not mean the drone is connected or ready to fly.")
                    }
                    DisclosureGroup("Does this need internet?") {
                        Text("Runtime pairing uses local Wi-Fi and does not need internet. Both devices must still share a working local network. A secured local router can work offline; Windows hotspot availability without internet depends on the adapter and driver.")
                        Text("Internet is needed separately to download a new app build or package.")
                    }
                    DisclosureGroup("Can I use the H743’s built-in Bluetooth?") {
                        Text("The current onboard Bluetooth module uses Classic SPP. It is not an iPhone BLE/GATT telemetry device, and changing H743 firmware cannot create the required BLE hardware. Use the Windows relay or an independently verified compatible Wi-Fi telemetry gateway.")
                    }
                    DisclosureGroup("What do center, radius and height mean?") {
                        Text("The center and radius define the allowed GPS target area. Using the phone’s current location as center does not change the aircraft’s home position; update the companion to the same center before starting.")
                        Text("Height is above the aircraft’s home or launch level. It does not measure clearance above the phone, ground, roofs or hills. This app does not identify landing surfaces or provide obstacle avoidance.")
                    }
                    DisclosureGroup("Where should I keep the pairing key?") {
                        Text("The companion stores it encrypted for your Windows user. Use its Show key locally or Copy key control to transfer it to your phone. Keep the key private; do not put it in public downloads, screenshots or the app source.")
                    }
                }

                Section("Updates and installation") {
                    DisclosureGroup("How do I get the latest version?") {
                        Text("Download the latest verified IPA from the app’s release bundle and use the matching Windows companion package. The build page below shows which native builds passed.")
                        Text("Some build artifacts are an unsigned app ZIP rather than an IPA. For Sideloadly, choose the packaged GPSFollow IPA supplied with the release. Downloading a build does not install it automatically.")
                        Link("Open build and update page", destination: URL(string: "https://github.com/IPAcquired/gps-follow-ios/actions/workflows/ios-build.yml")!)
                    }
                    DisclosureGroup("How do I install or renew the iPhone app?") {
                        Text("Load the latest IPA in your existing Sideloadly installation and sign it using the same Apple ID locally. You handle Apple authentication and verification; never enter credentials in chat.")
                        Text("A free personal signing profile normally needs renewal after seven days. Re-sign and reinstall through Sideloadly when needed. This app has no automatic over-the-air updater, and the download is unsigned until you sign it for your phone.")
                    }
                }
            }
            .safeAreaInset(edge: .bottom, spacing: 0) { brandFooter }
            .navigationTitle("Q&A")
        }
    }
}
