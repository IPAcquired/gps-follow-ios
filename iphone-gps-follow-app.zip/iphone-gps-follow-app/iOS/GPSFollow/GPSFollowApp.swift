import SwiftUI

@main
struct GPSFollowApp: App {
    @StateObject private var model = GPSModel()
    @Environment(\.scenePhase) private var scenePhase
    var body: some Scene {
        WindowGroup {
            ContentView(model: model)
                .onChange(of: scenePhase) { _, phase in
                    // A permission sheet temporarily makes the app inactive in the foreground.
                    if phase == .background { model.foregroundChanged(active: false) }
                }
        }
    }
}

struct ContentView: View {
    @ObservedObject var model: GPSModel
    @State private var revealSecret = false

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Label(model.status, systemImage: model.running ? "location.fill" : "location.slash")
                        .font(.headline)
                    LabeledContent("GPS accuracy", value: model.accuracyText)
                    LabeledContent("Fix age", value: model.fixAge)
                    Text(model.linkStatus).font(.subheadline).foregroundStyle(.secondary)
                    LabeledContent(model.mode == .direct ? "Target packets queued" : "Targets accepted by relay", value: "\(model.targetCount)")
                    Button(model.running ? "Stop GPS sharing" : "Start GPS sharing") {
                        model.running ? model.stop() : model.start()
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(model.running ? .red : .blue)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 6)
                } footer: {
                    Text("Keep this app open. GPS sharing stops when you leave it or lock the phone. Start shares a target; select Follow yourself using your transmitter.")
                }
                if let error = model.error {
                    Section { Text(error).foregroundStyle(.red) }
                }
                Section {
                    Picker("Transport", selection: $model.mode) {
                        ForEach(TransportMode.allCases) { Text($0.rawValue).tag($0) }
                    }
                    .onChange(of: model.mode) { _, _ in model.modeChanged() }
                    TextField(model.mode == .direct ? "Telemetry Wi-Fi address" : "Laptop Wi-Fi address", text: $model.ip)
                        .keyboardType(.decimalPad).textInputAutocapitalization(.never).autocorrectionDisabled()
                    TextField("UDP port", text: $model.port).keyboardType(.numberPad)
                    if revealSecret {
                        TextField("64-character key", text: $model.secret)
                            .textInputAutocapitalization(.never).autocorrectionDisabled().font(.system(.caption, design: .monospaced))
                    } else {
                        SecureField(model.mode == .direct ? "MAVLink signing key" : "Relay pairing key", text: $model.secret)
                            .textInputAutocapitalization(.never).autocorrectionDisabled()
                    }
                    Toggle("Show key", isOn: $revealSecret)
                } header: {
                    Text("Connection")
                } footer: {
                    Text(model.mode == .direct ? "Requires compatible Wi-Fi MAVLink telemetry with signed MAVLink 2 already configured on your controller. The module model still needs to be confirmed." :
                        "Optional fallback: the iPhone and laptop must share a private Wi-Fi network. Use the key from your relay configuration.")
                }
                .disabled(model.running)
                Section {
                    Button("Use current location as center") { model.useCurrentLocationAsCenter() }
                    TextField("Center latitude", text: $model.originLat).keyboardType(.numbersAndPunctuation)
                    TextField("Center longitude", text: $model.originLon).keyboardType(.numbersAndPunctuation)
                    LabeledContent("Radius (m)") { TextField("50", text: $model.radiusText).keyboardType(.decimalPad).multilineTextAlignment(.trailing) }
                    LabeledContent("Height above launch level (m)") { TextField("5", text: $model.heightText).keyboardType(.decimalPad).multilineTextAlignment(.trailing) }
                } header: {
                    Text("Operating area")
                } footer: {
                    Text("Height is above the aircraft’s home/launch level. It does not measure clearance above the phone, roofs, hills or ground. Match the prepared Follow offset and keep your transmitter connected for pilot control.")
                }
                .disabled(model.running)
                Section {
                    Text("GPS target only. This app does not identify landing surfaces or provide obstacle avoidance.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
            .safeAreaInset(edge: .bottom, spacing: 0) {
                Text("Made by Nate Wrench 2026")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 8)
                    .background(.bar)
            }
            .navigationTitle("GPS Follow")
            .onReceive(Timer.publish(every: 0.2, on: .main, in: .common).autoconnect()) { model.now = $0 }
        }
    }
}
