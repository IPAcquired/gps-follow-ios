import Foundation
import CoreFoundation

struct PrinterIdentity: Equatable {
    let ip: String
    let serial: String
    let model: String
    let name: String
}
struct PrinterSnapshot {
    let identity: PrinterIdentity
    let state: String
    let progress: Double?
    let nozzle: Double?
    let bed: Double?
    let version: String
    let checked: Date
}
enum PrinterJSON {
    static func object(_ data: Data) throws -> [String: Any] {
        guard !data.isEmpty, data.count <= 65_536 else { throw PrinterError.malformed }
        var depth = 0, quoted = false, escaped = false
        for byte in data {
            if quoted {
                if escaped { escaped = false } else if byte == 92 { escaped = true } else if byte == 34 { quoted = false }
            } else if byte == 34 { quoted = true }
            else if byte == 123 || byte == 91 { depth += 1; if depth > 12 { throw PrinterError.malformed } }
            else if byte == 125 || byte == 93 { depth -= 1; if depth < 0 { throw PrinterError.malformed } }
        }
        // Foundation otherwise silently overwrites duplicate keys. Compare decoded keys per object, including Unicode escapes.
        let bytes = Array(data); var scopes: [(object: Bool, keys: Set<String>)] = []; var index = 0
        while index < bytes.count {
            let byte = bytes[index]
            if byte == 123 || byte == 91 { scopes.append((byte == 123, [])); index += 1; continue }
            if byte == 125 || byte == 93 { guard !scopes.isEmpty else { throw PrinterError.malformed }; scopes.removeLast(); index += 1; continue }
            if byte == 34 {
                let start = index; index += 1; var escaped = false
                while index < bytes.count {
                    let next = bytes[index]; index += 1
                    if escaped { escaped = false } else if next == 92 { escaped = true } else if next == 34 { break }
                }
                var next = index
                while next < bytes.count && [9, 10, 13, 32].contains(bytes[next]) { next += 1 }
                if next < bytes.count && bytes[next] == 58 {
                    guard !scopes.isEmpty, scopes[scopes.count - 1].object,
                          let decoded = try? JSONSerialization.jsonObject(with: Data([91] + Array(bytes[start..<index]) + [93])) as? [String], let key = decoded.first,
                          !scopes[scopes.count - 1].keys.contains(key) else { throw PrinterError.malformed }
                    scopes[scopes.count - 1].keys.insert(key)
                }
                continue
            }
            index += 1
        }
        guard let value = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { throw PrinterError.malformed }
        func finite(_ value: Any) -> Bool {
            if let n = value as? NSNumber { return n.doubleValue.isFinite }
            if let a = value as? [Any] { return a.allSatisfy(finite) }
            if let d = value as? [String: Any] { return d.values.allSatisfy(finite) }; return true
        }
        guard finite(value) else { throw PrinterError.malformed }
        return value
    }
    static func integer(_ value: Any?) -> Int? {
        guard let n = value as? NSNumber, CFGetTypeID(n) != CFBooleanGetTypeID(),
              !["d", "f"].contains(String(cString: n.objCType)), n.doubleValue >= Double(Int32.min), n.doubleValue <= Double(Int32.max) else { return nil }
        return n.intValue
    }
    static func number(_ value: Any?, range: ClosedRange<Double>) -> Double? {
        guard let n = value as? NSNumber, CFGetTypeID(n) != CFBooleanGetTypeID(), n.doubleValue.isFinite, range.contains(n.doubleValue) else { return nil }; return n.doubleValue
    }
    // The official CC2 discovery contract permits JSON booleans or exact integer 0/1 flags.
    static func flag(_ value: Any?) -> Bool? {
        guard let n = value as? NSNumber else { return nil }
        if CFGetTypeID(n) == CFBooleanGetTypeID() { return n.boolValue }
        guard let value = integer(n), value == 0 || value == 1 else { return nil }
        return value == 1
    }
    static func serial(_ value: Any?) -> String? {
        guard let value = value as? String, !value.isEmpty, value.utf8.count <= 64,
              value.utf8.allSatisfy({ (48...57).contains($0) || (65...90).contains($0) || (97...122).contains($0) || $0 == 45 || $0 == 95 }) else { return nil }
        return value
    }
    static func isCC2(_ model: String) -> Bool {
        ["centauricarbon2", "elegoocentauricarbon2"].contains(model.lowercased().filter { $0.isLetter || $0.isNumber })
    }
    static func discovery(_ data: Data, ip: String) throws -> PrinterIdentity {
        let reply = try object(data)
        guard integer(reply["id"]) == 0, let result = reply["result"] as? [String: Any],
              let model = result["machine_model"] as? String, model.utf8.count <= 80, isCC2(model),
              let serial = serial(result["sn"]), let name = result["host_name"] as? String, name.utf8.count <= 120 else { throw PrinterError.wrongPrinter }
        guard flag(result["token_status"]) != nil, let lan = flag(result["lan_status"]) else { throw PrinterError.malformed }
        guard lan else { throw PrinterError.cloudMode }
        return PrinterIdentity(ip: ip, serial: serial, model: model, name: name)
    }
    static func result(_ data: Data, id: Int, method: Int? = nil) throws -> [String: Any] {
        let object = try self.object(data)
        guard integer(object["id"]) == id, let result = object["result"] as? [String: Any], integer(result["error_code"]) == 0 else { throw PrinterError.rejected }
        if let method, object["method"] != nil, integer(object["method"]) != method { throw PrinterError.rejected }
        return result
    }
}

@MainActor final class PrinterClient {
    private var sockets: [PrinterSocket] = []
    private var cancelled = false
    private var deadline = ProcessInfo.processInfo.systemUptime + 25
    func close() { cancelled = true; sockets.forEach { $0.close() }; sockets.removeAll() }
    private func socket(host: String, port: UInt16, udp: Bool = false) -> PrinterSocket {
        let value = PrinterSocket(host: host, port: port, udp: udp, deadline: deadline); sockets.append(value); return value
    }
    func discover(ip: String) async throws -> PrinterIdentity {
        guard OperatingArea.privateIPv4(ip) else { throw PrinterError.invalidSetup }
        cancelled = false; deadline = ProcessInfo.processInfo.systemUptime + 10; defer { close() }
        let udp = socket(host: ip, port: 52700, udp: true)
        try await udp.open(); try await udp.send(Data("{\"id\":0,\"method\":7000}".utf8))
        return try PrinterJSON.discovery(try await udp.datagram(), ip: ip)
    }
    // Ports are fixed by the official CC2 contract. Internal overrides only exercise local fake endpoints in native tests.
    func status(ip: String, code: String, pinnedSerial: String?, discoveryPort: UInt16 = 52700, httpPort: UInt16 = 80, mqttPort: UInt16 = 1883, testingLoopback: Bool = false) async throws -> PrinterSnapshot {
        guard OperatingArea.privateIPv4(ip) || (testingLoopback && ip == "127.0.0.1"),
              (1...64).contains(code.utf8.count), code.utf8.allSatisfy({ (33...126).contains($0) }) else { throw PrinterError.invalidSetup }
        cancelled = false
        defer { close() }
        deadline = ProcessInfo.processInfo.systemUptime + 25
        func check() throws { if cancelled { throw PrinterError.disconnected }; if ProcessInfo.processInfo.systemUptime > deadline { throw PrinterError.timeout } }
        let udp = socket(host: ip, port: discoveryPort, udp: true)
        try await udp.open(); try await udp.send(Data("{\"id\":0,\"method\":7000}".utf8))
        let identity = try PrinterJSON.discovery(try await udp.datagram(), ip: ip); udp.close()
        if let pinnedSerial, pinnedSerial != identity.serial { throw PrinterError.wrongPrinter }
        try check()
        let http = socket(host: ip, port: httpPort)
        try await http.open()
        let httpRequest = "GET /system/info HTTP/1.1\r\nHost: \(ip)\r\nX-Token: \(code)\r\nConnection: close\r\nAccept: application/json\r\n\r\n"
        try await http.send(Data(httpRequest.utf8))
        var response = Data(), body: Data?
        while body == nil {
            try check(); response.append(try await http.receive())
            guard response.count <= 65_536 else { throw PrinterError.malformed }
            body = try HTTPPrinterWire.body(response)
        }
        http.close()
        let info = try PrinterJSON.object(body!)
        guard PrinterJSON.integer(info["error_code"]) == 0 else { throw PrinterError.rejected }
        guard let system = info["system_info"] as? [String: Any], PrinterJSON.serial(system["sn"]) == identity.serial else { throw PrinterError.wrongPrinter }
        try check()
        let mqtt = socket(host: ip, port: mqttPort)
        try await mqtt.open()
        let clientID = "1_PC_" + String(Int.random(in: 1000...9999))
        let prefix = "elegoo/\(identity.serial)/"
        let responseTopic = prefix + clientID + "/api_response"
        let registrationTopic = prefix + clientID + "_req/register_response"
        try await mqtt.send(MQTTWire.connect(client: clientID, code: code))
        let connack = try await mqtt.mqttPacket()
        guard connack.0 == 0x20, connack.1 == Data([0, 0]) else { throw PrinterError.rejected }
        try await mqtt.send(MQTTWire.subscribe(topics: [responseTopic, prefix + "api_status", registrationTopic]))
        let suback = try await mqtt.mqttPacket()
        guard suback.0 == 0x90, suback.1 == Data([0, 1, 1, 1, 1]) else { throw PrinterError.rejected }
        let register = try JSONSerialization.data(withJSONObject: ["client_id": clientID, "request_id": clientID + "_req"])
        try await mqtt.send(MQTTWire.publish(topic: prefix + "api_register", body: register, packetID: 2))
        var receivedCount = 0
        var pendingAcks: Set<UInt16> = [2]
        func message(topic expected: String, id: Int? = nil, method: Int? = nil) async throws -> [String: Any] {
            while receivedCount < 40 {
                try check(); receivedCount += 1
                let (header, payload) = try await mqtt.mqttPacket()
                if header == 0x40 {
                    guard payload.count == 2 else { throw PrinterError.malformed }
                    let ack = UInt16(payload[0]) * 256 + UInt16(payload[1])
                    guard pendingAcks.remove(ack) != nil else { throw PrinterError.malformed }; continue
                }
                let (topic, body, packetID) = try MQTTWire.publication(header, payload)
                if let packetID { try await mqtt.send(MQTTWire.packet(0x40, MQTTWire.word(packetID))) }
                guard topic == expected else { continue } // Ignore status deltas; never invent a full baseline.
                if let id { return try PrinterJSON.result(body, id: id, method: method) }
                return try PrinterJSON.object(body)
            }
            throw PrinterError.malformed
        }
        let registered = try await message(topic: registrationTopic)
        guard registered["client_id"] as? String == clientID, registered["error"] as? String == "ok" else { throw PrinterError.rejected }
        func request(method: Int, id: Int, packetID: UInt16) async throws -> [String: Any] {
            let payload = try JSONSerialization.data(withJSONObject: ["id": id, "method": method, "params": [String: Any]()])
            pendingAcks.insert(packetID)
            try await mqtt.send(MQTTWire.publish(topic: prefix + clientID + "/api_request", body: payload, packetID: packetID))
            return try await message(topic: responseTopic, id: id, method: method)
        }
        let requestID = Int.random(in: 1...(Int(Int32.max) - 1))
        let attributes = try await request(method: 1001, id: requestID, packetID: 3)
        guard PrinterJSON.serial(attributes["sn"]) == identity.serial, attributes["machine_model"] as? String == identity.model else { throw PrinterError.wrongPrinter }
        let status = try await request(method: 1002, id: requestID + 1, packetID: 4)
        guard let machine = status["machine_status"] as? [String: Any], let state = PrinterJSON.integer(machine["status"]) else { throw PrinterError.malformed }
        let progress = PrinterJSON.number(machine["progress"], range: 0...100)
        let extruder = status["extruder"] as? [String: Any], bed = status["heater_bed"] as? [String: Any]
        let software = attributes["software_version"] as? [String: Any]
        try check()
        return PrinterSnapshot(identity: identity, state: [0: "Initializing", 1: "Idle", 2: "Printing"][state] ?? "Unknown state",
            progress: progress, nozzle: PrinterJSON.number(extruder?["temperature"], range: -20...400), bed: PrinterJSON.number(bed?["temperature"], range: -20...150),
            version: String((software?["ota_version"] as? String ?? "Unknown").prefix(80)), checked: Date())
    }
}

enum HTTPPrinterWire {
    static func body(_ data: Data) throws -> Data? {
        guard data.count <= 65_536 else { throw PrinterError.malformed }
        let marker = Data("\r\n\r\n".utf8)
        guard let split = data.range(of: marker) else { if data.count > 8192 { throw PrinterError.malformed }; return nil }
        guard let header = String(data: data[..<split.lowerBound], encoding: .utf8), header.utf8.count <= 8192 else { throw PrinterError.malformed }
        let lines = header.components(separatedBy: "\r\n")
        guard ["HTTP/1.1 200", "HTTP/1.0 200"].contains(where: { lines[0].hasPrefix($0 + " ") }) else { throw PrinterError.rejected }
        var fields: [String: String] = [:]
        for line in lines.dropFirst() {
            guard let colon = line.firstIndex(of: ":") else { throw PrinterError.malformed }
            let name = line[..<colon].lowercased(), value = line[line.index(after: colon)...].trimmingCharacters(in: .whitespaces)
            guard fields[name] == nil else { throw PrinterError.malformed }; fields[name] = value
        }
        let payload = Data(data[split.upperBound...])
        if let transfer = fields["transfer-encoding"] {
            guard transfer.lowercased() == "chunked", fields["content-length"] == nil else { throw PrinterError.malformed }
            var offset = 0, result = Data(), chunks = 0
            while offset < payload.count {
                guard let lineEnd = payload.range(of: Data([13, 10]), in: offset..<payload.count) else { return nil }
                guard lineEnd.lowerBound - offset <= 8, let sizeText = String(data: payload[offset..<lineEnd.lowerBound], encoding: .ascii), let size = Int(sizeText, radix: 16), size >= 0, size <= 65_536 else { throw PrinterError.malformed }
                offset = lineEnd.upperBound; chunks += 1; guard chunks <= 256, result.count + size <= 65_536 else { throw PrinterError.malformed }
                guard payload.count >= offset + size + 2 else { return nil }
                guard payload[offset + size] == 13, payload[offset + size + 1] == 10 else { throw PrinterError.malformed }
                if size == 0 { return result }
                result.append(payload[offset..<(offset + size)]); offset += size + 2
            }
            return nil
        }
        guard let lengthText = fields["content-length"], let length = Int(lengthText), (1...65_536).contains(length) else { throw PrinterError.malformed }
        if payload.count < length { return nil }; guard payload.count == length else { throw PrinterError.malformed }; return payload
    }
}
