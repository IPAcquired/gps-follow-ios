import XCTest
@testable import GPSFollow

final class CADTransferIntegrationTests: XCTestCase {
    private var stl: Data { Data("solid test\nendsolid test\n".utf8) }

    func testVerifiedTransferSavesNewCopiesWithoutOverwriting() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let library = CADLibrary(directory: directory)
        let first = try library.importTransfer(name: "leg.stl", data: stl)
        let second = try library.importTransfer(name: "leg.stl", data: stl)
        XCTAssertNotEqual(first.url, second.url)
        XCTAssertEqual(library.items.count, 2)
        XCTAssertEqual(try library.transferData(first), stl)
        XCTAssertEqual(try Data(contentsOf: second.url), stl)
    }

    func testTransferRejectsUnlistedExternalFile() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let library = CADLibrary(directory: directory)
        let unlisted = directory.appendingPathComponent("outside.stl")
        try stl.write(to: unlisted)
        let fabricated = CADItem(url: unlisted, name: "outside.stl", bytes: stl.count)
        // A file within the store becomes listed after refresh; an external path never does.
        let external = directory.deletingLastPathComponent().appendingPathComponent(UUID().uuidString + ".stl")
        defer { try? FileManager.default.removeItem(at: external) }
        try stl.write(to: external)
        let foreign = CADItem(url: external, name: fabricated.name, bytes: stl.count)
        XCTAssertThrowsError(try library.transferData(foreign))
    }

    func testTransferRejectsOversizeAndInvalidHeaderWithoutSaving() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let library = CADLibrary(directory: directory)
        XCTAssertThrowsError(try library.importTransfer(name: "leg.stl", data: Data(repeating: 0, count: CADTransferWire.maxFile + 1)))
        XCTAssertThrowsError(try library.importTransfer(name: "leg.stl", data: Data("not an STL".utf8)))
        XCTAssertThrowsError(try library.importTransfer(name: "update.ipa", data: stl))
        XCTAssertTrue(library.items.isEmpty)
    }

    @MainActor func testInvalidSetupAndStopNeverStartTransfer() {
        let model = CADTransferModel()
        model.start(ip: "203.0.113.1", secret: String(repeating: "01", count: 32), port: "8766")
        XCTAssertNotNil(model.error)
        XCTAssertFalse(model.busy)
        XCTAssertFalse(model.connected)
        model.stop()
        XCTAssertNil(model.error)
        XCTAssertEqual(model.status, "Stopped")
        XCTAssertTrue(model.remoteItems.isEmpty)
    }

    func testFlightLogContentIsSeparateFromCADAndBounded() throws {
        var log = Data([0xA3, 0x95, 0x80, 1, 7]); log.append(Data(repeating: 0, count: 84))
        XCTAssertNoThrow(try CADTransferWire.validate(log, name: "0099.bin", content: .flightLog))
        XCTAssertThrowsError(try CADTransferWire.validate(log, name: "0099.bin", content: .cad))
        XCTAssertThrowsError(try CADTransferWire.validate(stl, name: "part.bin", content: .flightLog))
        XCTAssertThrowsError(try CADTransferWire.validate(Data(repeating: 0, count: 32 * 1024 * 1024 + 1), name: "large.bin", content: .flightLog))
    }

    func testFlightLogRemoteItemAllowsBinButCADDoesNot() throws {
        let raw: [String: Any] = ["id": String(repeating: "a", count: 32), "name": "0100.BIN", "bytes": 1024,
                                  "sha256": String(repeating: "b", count: 64)]
        XCTAssertEqual(try CADTransferWire.item(raw, content: .flightLog).name, "0100.bin")
        XCTAssertThrowsError(try CADTransferWire.item(raw, content: .cad))
    }
}
