import XCTest
import CryptoKit
import CoreLocation
@testable import GPSFollow

final class MAVLinkTests: XCTestCase {
    private func fixtures() throws -> [String: Any] {
        let url = try XCTUnwrap(Bundle(for: Self.self).url(forResource: "fixtures", withExtension: "json"))
        return try XCTUnwrap(JSONSerialization.jsonObject(with: Data(contentsOf: url)) as? [String: Any])
    }

    func testGlobalPositionMatchesPymavlinkFixture() throws {
        let expected = try fixtures()
        let payload = MAVLink.position(lat: 41.1234567, lon: -87.7654321, uptimeMS: 123456)
        XCTAssertEqual(payload.count, 28)
        XCTAssertEqual(MAVLink.hex(Data(MAVLink.unsignedPacket(id: 33, payload: payload, sequence: 7))),
                       expected["global_position_int_hex"] as? String)
        XCTAssertEqual(Array(payload[12..<26]), Array(repeating: 0, count: 14))
        XCTAssertEqual(Array(payload[26..<28]), [255, 255])
    }

    func testSigningMatchesPymavlinkFixture() throws {
        let expected = try fixtures()
        let key = Data((0...31).map { UInt8($0) })
        let target = MAVLink.signedPacket(id: 33,
            payload: MAVLink.position(lat: 41.1234567, lon: -87.7654321, uptimeMS: 123456),
            sequence: 7, key: key, linkID: 43, timestamp: 1_000_000)
        XCTAssertEqual(MAVLink.hex(target), expected["signed_global_position_int_hex"] as? String)
        let heartbeat = MAVLink.signedPacket(id: 0, payload: MAVLink.heartbeat(), sequence: 7,
                                            key: key, linkID: 43, timestamp: 1_000_000)
        XCTAssertEqual(MAVLink.hex(heartbeat), expected["signed_heartbeat_hex"] as? String)
    }

    private func controllerPacket(id: UInt32, payload: [UInt8], key: Data,
                                  timestamp: UInt64, sequence: UInt8 = 1) -> Data {
        var frame = MAVLink.unsignedPacket(id: id, payload: payload, sequence: sequence, signed: true)
        frame[5] = 1; frame[6] = 1
        let check = MAVLink.crc(Array(frame[1..<(10 + payload.count)]), extra: MAVLink.crcExtras[id]!)
        frame[10 + payload.count] = UInt8(check & 255)
        frame[11 + payload.count] = UInt8(check >> 8)
        let trailer = [UInt8(1)] + MAVLink.little(timestamp, count: 6)
        return Data(frame + trailer + Array(SHA256.hash(data: key + Data(frame + trailer)).prefix(6)))
    }

    private func freshKey() -> Data {
        Data(SHA256.hash(data: Data(UUID().uuidString.utf8)))
    }

    func testSignedReceiverRejectsReplayTamperAndUnsigned() {
        let key = freshKey()
        let signer = MAVSigner(key: key)
        let timestamp = MAVSigner.timestamp()
        let packet = controllerPacket(id: 0, payload: MAVLink.heartbeat(), key: key, timestamp: timestamp)
        XCTAssertEqual(signer.decode(packet).count, 1)
        XCTAssertTrue(signer.decode(packet).isEmpty)
        var corrupt = controllerPacket(id: 0, payload: MAVLink.heartbeat(), key: key, timestamp: timestamp + 1)
        corrupt[corrupt.count - 1] ^= 1
        XCTAssertTrue(signer.decode(corrupt).isEmpty)
        let unsigned = Data(MAVLink.unsignedPacket(id: 0, payload: MAVLink.heartbeat(), sequence: 3))
        XCTAssertTrue(signer.decode(unsigned).isEmpty)
    }

    func testUID2TruncationRestoresZeroExtensions() {
        let key = freshKey()
        let signer = MAVSigner(key: key)
        let uid: [UInt8] = [0x1c, 0, 0x32, 0, 0x0d, 0x51, 0x34, 0x34, 0x36, 0x35, 0x36, 0x34]
        let payload = Array(repeating: UInt8(0), count: 60) + uid
        let messages = signer.decode(controllerPacket(id: 148, payload: payload, key: key, timestamp: MAVSigner.timestamp()))
        XCTAssertEqual(messages.count, 1)
        XCTAssertEqual(messages.first?.payload.count, 78)
        if let message = messages.first {
            XCTAssertEqual(MAVLink.hex(Data(message.payload[60..<78])), MAVLink.expectedUID)
        }
    }

    func testOnlyExactSelfEchoIsIgnored() {
        let key = freshKey()
        let signer = MAVSigner(key: key)
        let echo = signer.packet(id: 0, payload: MAVLink.heartbeat())
        XCTAssertTrue(signer.decode(echo).isEmpty)
        let other = MAVLink.signedPacket(id: 0, payload: MAVLink.heartbeat(), sequence: 10,
            key: key, linkID: 44, timestamp: MAVSigner.timestamp() + 10)
        XCTAssertEqual(signer.decode(other).first?.system, 42)
    }

    func testJSONAuthenticationInteroperabilityAndTamper() throws {
        let key = freshKey()
        let encoded = try XCTUnwrap(AuthenticatedJSON.encode(["v": AuthenticatedJSON.version, "kind": "hello"], key: key))
        XCTAssertEqual(AuthenticatedJSON.decode(encoded, key: key)?["kind"] as? String, "hello")
        XCTAssertNil(AuthenticatedJSON.decode(encoded, key: freshKey()))
    }

    private func secureWire(_ body: Data, key: Data, iv: Data = Data((0..<12).map { UInt8($0) }),
                            aad: Data = AuthenticatedJSON.aad, version: Any = 2) throws -> Data {
        let sealed = try AES.GCM.seal(body, using: SymmetricKey(data: key),
                                     nonce: AES.GCM.Nonce(data: iv), authenticating: aad)
        return try JSONSerialization.data(withJSONObject: ["v": version,
            "nonce": iv.base64EncodedString(), "ciphertext": sealed.ciphertext.base64EncodedString(),
            "tag": sealed.tag.base64EncodedString()])
    }

    func testAES256GCMPublishedZeroKnownVector() throws {
        let key = Data(repeating: 0, count: 32)
        let nonce = try AES.GCM.Nonce(data: Data(repeating: 0, count: 12))
        let sealed = try AES.GCM.seal(Data(repeating: 0, count: 16),
                                     using: SymmetricKey(data: key), nonce: nonce)
        XCTAssertEqual(MAVLink.hex(sealed.ciphertext), "cea7403d4d606b6e074ec5d3baf39d18")
        XCTAssertEqual(MAVLink.hex(sealed.tag), "d0d1c8a799996bf0265b98b5d48ab919")
    }

    func testSecureWireFixtureFromPythonAndCryptoKit() throws {
        // Public fixed fixture only; production never accepts a caller-supplied nonce.
        let key = Data((0...31).map { UInt8($0) })
        let iv = Data((0...11).map { UInt8($0) })
        let plaintext = Data("{\"kind\":\"hello\",\"v\":2}".utf8)
        let sealed = try AES.GCM.seal(plaintext, using: SymmetricKey(data: key),
            nonce: AES.GCM.Nonce(data: iv), authenticating: AuthenticatedJSON.aad)
        XCTAssertEqual(MAVLink.hex(sealed.ciphertext), "3c20bd72ab81e021af29f2e7dd865a41a1a0a50ec206")
        XCTAssertEqual(MAVLink.hex(sealed.tag), "9a84dffbdec12a6ee197b332332872f0")
        let wire = try secureWire(plaintext, key: key, iv: iv)
        XCTAssertEqual(AuthenticatedJSON.decode(wire, key: key)?["kind"] as? String, "hello")
        XCTAssertEqual(AuthenticatedJSON.aad, Data("GPSFollow/phone-pc/v2/aes-256-gcm".utf8))
    }

    func testSecureEncoderFreshNoncesAndHiddenCoordinates() throws {
        let key = freshKey()
        let payload: [String: Any] = ["v": 2, "kind": "position", "lat": 41.1234567, "lon": -87.7654321]
        var nonces: Set<String> = []
        for _ in 0..<256 {
            let wire = try XCTUnwrap(AuthenticatedJSON.encode(payload, key: key))
            let envelope = try XCTUnwrap(JSONSerialization.jsonObject(with: wire) as? [String: Any])
            let nonce = try XCTUnwrap(envelope["nonce"] as? String)
            XCTAssertEqual(Data(base64Encoded: nonce)?.count, 12)
            XCTAssertTrue(nonces.insert(nonce).inserted)
            XCTAssertFalse(String(decoding: wire, as: UTF8.self).contains("41.1234567"))
            XCTAssertEqual(AuthenticatedJSON.decode(wire, key: key)?["lat"] as? Double, 41.1234567)
        }
    }

    func testSecureEnvelopeRejectsTamperAndLegacyVersions() throws {
        let key = freshKey()
        let wire = try XCTUnwrap(AuthenticatedJSON.encode(["v": 2, "kind": "hello"], key: key))
        let envelope = try XCTUnwrap(JSONSerialization.jsonObject(with: wire) as? [String: Any])
        for name in ["nonce", "ciphertext", "tag"] {
            var altered = envelope
            var bytes = try XCTUnwrap(Data(base64Encoded: try XCTUnwrap(envelope[name] as? String)))
            bytes[0] ^= 1
            altered[name] = bytes.base64EncodedString()
            XCTAssertNil(AuthenticatedJSON.decode(try JSONSerialization.data(withJSONObject: altered), key: key))
        }
        XCTAssertNil(AuthenticatedJSON.decode(Data("{\"payload\":\"e30=\",\"mac\":\"00\"}".utf8), key: key))
        XCTAssertNil(AuthenticatedJSON.decode(try secureWire(Data("{\"v\":1}".utf8), key: key), key: key))
        XCTAssertNil(AuthenticatedJSON.decode(try secureWire(Data("{\"v\":2}".utf8), key: key, version: 1), key: key))
        XCTAssertNil(AuthenticatedJSON.decode(try secureWire(Data("{\"v\":true}".utf8), key: key), key: key))
        XCTAssertNil(AuthenticatedJSON.decode(try secureWire(Data("{\"v\":2.0}".utf8), key: key), key: key))
        XCTAssertNil(AuthenticatedJSON.decode(try secureWire(Data("{\"v\":2}".utf8), key: key, version: true), key: key))
    }

    func testSecureEnvelopeRejectsWrongAADKeyLengthsAndFields() throws {
        let key = freshKey()
        let body = Data("{\"v\":2}".utf8)
        XCTAssertNil(AuthenticatedJSON.decode(try secureWire(body, key: key, aad: Data("wrong domain".utf8)), key: key))
        let wire = try secureWire(body, key: key)
        XCTAssertNil(AuthenticatedJSON.decode(wire, key: Data(repeating: 0, count: 16)))
        XCTAssertNil(AuthenticatedJSON.encode(["v": 2], key: Data(repeating: 0, count: 16)))
        var envelope = try XCTUnwrap(JSONSerialization.jsonObject(with: wire) as? [String: Any])
        envelope["extra"] = "field"
        XCTAssertNil(AuthenticatedJSON.decode(try JSONSerialization.data(withJSONObject: envelope), key: key))
        envelope.removeValue(forKey: "extra")
        envelope["nonce"] = Data(repeating: 0, count: 8).base64EncodedString()
        XCTAssertNil(AuthenticatedJSON.decode(try JSONSerialization.data(withJSONObject: envelope), key: key))
        envelope["nonce"] = Data((0..<12).map { UInt8($0) }).base64EncodedString()
        envelope["tag"] = Data(repeating: 0, count: 8).base64EncodedString()
        XCTAssertNil(AuthenticatedJSON.decode(try JSONSerialization.data(withJSONObject: envelope), key: key))
    }

    func testSecureDecoderBoundsMalformedJSONAndOversizedPackets() throws {
        let key = freshKey()
        XCTAssertNil(AuthenticatedJSON.decode(Data((String(repeating: "[", count: 1500) + "0" + String(repeating: "]", count: 1500)).utf8), key: key))
        XCTAssertNil(AuthenticatedJSON.decode(Data(repeating: 65, count: 4097), key: key))
        let deepBody = Data(("{\"v\":2,\"x\":" + String(repeating: "[", count: 20) + "0" + String(repeating: "]", count: 20) + "}").utf8)
        XCTAssertNil(AuthenticatedJSON.decode(try secureWire(deepBody, key: key), key: key))
        let valid = try XCTUnwrap(AuthenticatedJSON.encode(["v": 2, "kind": "hello"], key: key))
        XCTAssertEqual(AuthenticatedJSON.decode(valid, key: key)?["kind"] as? String, "hello")
    }

    func testGPSFilterRejectsStaleInaccurateAndJumpingFixes() {
        let area = OperatingArea(latitude: 41, longitude: -87, radius: 50, height: 5)
        var filter = GPSFilter(area: area)
        let now = Date()
        func location(lat: Double = 41, accuracy: Double = 3, date: Date) -> CLLocation {
            CLLocation(coordinate: CLLocationCoordinate2D(latitude: lat, longitude: -87),
                       altitude: 99999, horizontalAccuracy: accuracy, verticalAccuracy: 999,
                       course: -1, speed: 0, timestamp: date)
        }
        XCTAssertNil(filter.reason(location(date: now), now: now))
        XCTAssertNotNil(filter.reason(location(accuracy: 12, date: now), now: now))
        XCTAssertNotNil(filter.reason(location(date: now.addingTimeInterval(-2)), now: now))
        XCTAssertNotNil(filter.reason(location(lat: 41.0002, date: now.addingTimeInterval(0.2)), now: now.addingTimeInterval(0.2)))
    }
}
