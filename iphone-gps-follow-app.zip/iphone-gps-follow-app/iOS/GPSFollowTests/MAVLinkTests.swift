import XCTest
import CryptoKit
import CoreLocation
@testable import GPSFollow

final class MAVLinkTests: XCTestCase {
    private func fixtures() throws -> [String: Any] {
        let url = try XCTUnwrap(Bundle(for: Self.self).url(forResource: "fixtures", withExtension: "json"))
        return try XCTUnwrap(JSONSerialization.jsonObject(with: Data(contentsOf: url)) as? [String: Any])
    }

    func testGlobalPositionMatchesPymavlinkFixture() throws {
        let expected = try fixtures()
        let payload = MAVLink.position(lat: 41.1234567, lon: -87.7654321, uptimeMS: 123456)
        XCTAssertEqual(payload.count, 28)
        XCTAssertEqual(MAVLink.hex(Data(MAVLink.unsignedPacket(id: 33, payload: payload, sequence: 7))),
                       expected["global_position_int_hex"] as? String)
        XCTAssertEqual(Array(payload[12..<26]), Array(repeating: 0, count: 14))
        XCTAssertEqual(Array(payload[26..<28]), [255, 255])
    }

    func testSigningMatchesPymavlinkFixture() throws {
        let expected = try fixtures()
        let key = Data((0...31).map { UInt8($0) })
        let target = MAVLink.signedPacket(id: 33,
            payload: MAVLink.position(lat: 41.1234567, lon: -87.7654321, uptimeMS: 123456),
            sequence: 7, key: key, linkID: 43, timestamp: 1_000_000)
        XCTAssertEqual(MAVLink.hex(target), expected["signed_global_position_int_hex"] as? String)
        let heartbeat = MAVLink.signedPacket(id: 0, payload: MAVLink.heartbeat(), sequence: 7,
                                            key: key, linkID: 43, timestamp: 1_000_000)
        XCTAssertEqual(MAVLink.hex(heartbeat), expected["signed_heartbeat_hex"] as? String)
    }

    private func controllerPacket(id: UInt32, payload: [UInt8], key: Data,
                                  timestamp: UInt64, sequence: UInt8 = 1) -> Data {
        var frame = MAVLink.unsignedPacket(id: id, payload: payload, sequence: sequence, signed: true)
        frame[5] = 1; frame[6] = 1
        let check = MAVLink.crc(Array(frame[1..<(10 + payload.count)]), extra: MAVLink.crcExtras[id]!)
        frame[10 + payload.count] = UInt8(check & 255)
        frame[11 + payload.count] = UInt8(check >> 8)
        let trailer = [UInt8(1)] + MAVLink.little(timestamp, count: 6)
        return Data(frame + trailer + Array(SHA256.hash(data: key + Data(frame + trailer)).prefix(6)))
    }

    private func freshKey() -> Data {
        Data(SHA256.hash(data: Data(UUID().uuidString.utf8)))
    }

    func testSignedReceiverRejectsReplayTamperAndUnsigned() {
        let key = freshKey()
        let signer = MAVSigner(key: key)
        let timestamp = MAVSigner.timestamp()
        let packet = controllerPacket(id: 0, payload: MAVLink.heartbeat(), key: key, timestamp: timestamp)
        XCTAssertEqual(signer.decode(packet).count, 1)
        XCTAssertTrue(signer.decode(packet).isEmpty)
        var corrupt = controllerPacket(id: 0, payload: MAVLink.heartbeat(), key: key, timestamp: timestamp + 1)
        corrupt[corrupt.count - 1] ^= 1
        XCTAssertTrue(signer.decode(corrupt).isEmpty)
        let unsigned = Data(MAVLink.unsignedPacket(id: 0, payload: MAVLink.heartbeat(), sequence: 3))
        XCTAssertTrue(signer.decode(unsigned).isEmpty)
    }

    func testUID2TruncationRestoresZeroExtensions() {
        let key = freshKey()
        let signer = MAVSigner(key: key)
        let uid: [UInt8] = [0x1c, 0, 0x32, 0, 0x0d, 0x51, 0x34, 0x34, 0x36, 0x35, 0x36, 0x34]
        let payload = Array(repeating: UInt8(0), count: 60) + uid
        let messages = signer.decode(controllerPacket(id: 148, payload: payload, key: key, timestamp: MAVSigner.timestamp()))
        XCTAssertEqual(messages.count, 1)
        XCTAssertEqual(messages.first?.payload.count, 78)
        if let message = messages.first {
            XCTAssertEqual(MAVLink.hex(Data(message.payload[60..<78])), MAVLink.expectedUID)
        }
    }

    func testOnlyExactSelfEchoIsIgnored() {
        let key = freshKey()
        let signer = MAVSigner(key: key)
        let echo = signer.packet(id: 0, payload: MAVLink.heartbeat())
        XCTAssertTrue(signer.decode(echo).isEmpty)
        let other = MAVLink.signedPacket(id: 0, payload: MAVLink.heartbeat(), sequence: 10,
            key: key, linkID: 44, timestamp: MAVSigner.timestamp() + 10)
        XCTAssertEqual(signer.decode(other).first?.system, 42)
    }

    func testJSONAuthenticationInteroperabilityAndTamper() throws {
        let key = freshKey()
        let encoded = try XCTUnwrap(AuthenticatedJSON.encode(["v": 1, "kind": "hello"], key: key))
        XCTAssertEqual(AuthenticatedJSON.decode(encoded, key: key)?["kind"] as? String, "hello")
        XCTAssertNil(AuthenticatedJSON.decode(encoded, key: freshKey()))
    }

    func testGPSFilterRejectsStaleInaccurateAndJumpingFixes() {
        let area = OperatingArea(latitude: 41, longitude: -87, radius: 50, height: 5)
        var filter = GPSFilter(area: area)
        let now = Date()
        func location(lat: Double = 41, accuracy: Double = 3, date: Date) -> CLLocation {
            CLLocation(coordinate: CLLocationCoordinate2D(latitude: lat, longitude: -87),
                       altitude: 99999, horizontalAccuracy: accuracy, verticalAccuracy: 999,
                       course: -1, speed: 0, timestamp: date)
        }
        XCTAssertNil(filter.reason(location(date: now), now: now))
        XCTAssertNotNil(filter.reason(location(accuracy: 12, date: now), now: now))
        XCTAssertNotNil(filter.reason(location(date: now.addingTimeInterval(-2)), now: now))
        XCTAssertNotNil(filter.reason(location(lat: 41.0002, date: now.addingTimeInterval(0.2)), now: now.addingTimeInterval(0.2)))
    }
}
