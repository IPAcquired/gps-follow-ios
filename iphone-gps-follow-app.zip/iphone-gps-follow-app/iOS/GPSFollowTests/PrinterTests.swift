import XCTest
import Network
@testable import GPSFollow

final class FakePrinter {
    let serial = "PUBLIC_TEST_CC2_001"
    let code = "PUBLIC_TEST_ACCESS"
    var listeners: [NWListener] = []
    var peers: [NWConnection] = []
    var channels: [PrinterSocket] = []
    var ports: [UInt16] = []
    var rejectAuth = false
    var rejectHTTPAuth = false
    var booleanFlags = false
    var wrongSerial = false
    var wrongRegistration = false
    var dropDiscovery = false
    var commandMethods: [Int] = []
    let queue = DispatchQueue(label: "NatesDrone.FakePrinter")
    func stop() { listeners.forEach { $0.cancel() }; peers.forEach { $0.cancel() }; channels.forEach { $0.close() } }
    func start() async throws {
        for kind in 0...2 {
            let params = kind == 0 ? NWParameters.udp : NWParameters.tcp
            params.requiredLocalEndpoint = .hostPort(host: "127.0.0.1", port: .any)
            let listener = try NWListener(using: params)
            listeners.append(listener)
            let port = try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<UInt16, Error>) in
                let lock = NSLock(); var completed = false
                func finish(_ result: Result<UInt16, Error>) -> Bool {
                    lock.lock(); guard !completed else { lock.unlock(); return false }; completed = true; lock.unlock(); continuation.resume(with: result); return true
                }
                listener.stateUpdateHandler = { state in
                    if case .ready = state { _ = finish(.success(listener.port!.rawValue)) }
                    if case .failed(let error) = state { _ = finish(.failure(error)) }
                }
                queue.asyncAfter(deadline: .now() + 5) { if finish(.failure(PrinterError.timeout)) { listener.cancel() } }
                listener.newConnectionHandler = { connection in
                    self.peers.append(connection)
                    if kind == 0 {
                        connection.start(queue: self.queue)
                        connection.receiveMessage { data, _, _, _ in
                            if self.dropDiscovery { return }
                            guard let data, String(data: data, encoding: .utf8)?.contains("7000") == true else { return }
                            let flags: Any = self.booleanFlags ? NSNumber(value: true) : NSNumber(value: 1)
                            let reply: [String: Any] = ["id": 0, "result": ["host_name": "Fake Carbon 2", "machine_model": "Centauri Carbon 2", "sn": self.serial, "token_status": flags, "lan_status": flags]]
                            connection.send(content: try! JSONSerialization.data(withJSONObject: reply), completion: .contentProcessed { _ in })
                        }
                    } else {
                        let socket = PrinterSocket(connection: connection); self.channels.append(socket)
                        Task {
                            do {
                                try await socket.open()
                                if kind == 1 {
                                    let request = try await socket.receive()
                                    guard String(data: request, encoding: .utf8)?.contains("X-Token: \(self.code)\r\n") == true else { socket.close(); return }
                                    let response: [String: Any] = self.rejectHTTPAuth ? ["error_code": 1] : ["error_code": 0, "system_info": ["sn": self.wrongSerial ? "WRONG_SERIAL" : self.serial]]
                                    let body = try JSONSerialization.data(withJSONObject: response)
                                    let header = "HTTP/1.1 200 OK\r\nContent-Length: \(body.count)\r\n\r\n"
                                    try await socket.send(Data(header.utf8) + body)
                                    socket.close()
                                } else { try await self.mqtt(socket) }
                            } catch { socket.close() }
                        }
                    }
                }
                listener.start(queue: queue)
            }
            ports.append(port)
        }
    }
    private func mqtt(_ socket: PrinterSocket) async throws {
        let (type, connect) = try await socket.mqttPacket()
        guard type == 0x10, connect.count > 12 else { throw PrinterError.malformed }
        let length = Int(connect[10]) * 256 + Int(connect[11])
        guard connect.count >= 12 + length else { throw PrinterError.malformed }
        let client = String(decoding: connect[12..<(12 + length)], as: UTF8.self)
        try await socket.send(MQTTWire.packet(0x20, Data([0, rejectAuth ? 5 : 0])))
        if rejectAuth { return }
        let subscribe = try await socket.mqttPacket(); guard subscribe.0 == 0x82 else { throw PrinterError.malformed }
        try await socket.send(MQTTWire.packet(0x90, Data([0, 1, 1, 1, 1])))
        let prefix = "elegoo/\(serial)/"
        let registration = try await socket.mqttPacket()
        let publication = try MQTTWire.publication(registration.0, registration.1)
        guard publication.0 == prefix + "api_register" else { throw PrinterError.malformed }
        try await socket.send(MQTTWire.packet(0x40, MQTTWire.word(publication.2!)))
        let registered: [String: Any] = ["client_id": wrongRegistration ? "wrong-client" : client, "error": "ok"]
        try await socket.send(MQTTWire.publish(topic: prefix + client + "_req/register_response", body: try JSONSerialization.data(withJSONObject: registered), packetID: 50))
        if wrongRegistration { return }
        for (method, packetID) in [(1001, UInt16(51)), (1002, UInt16(52))] {
            let ack = try await socket.mqttPacket(); guard ack.0 == 0x40 else { throw PrinterError.malformed }
            let packet = try await socket.mqttPacket(), request = try MQTTWire.publication(packet.0, packet.1)
            let object = try PrinterJSON.object(request.1)
            guard request.0 == prefix + client + "/api_request", PrinterJSON.integer(object["method"]) == method,
                  let id = PrinterJSON.integer(object["id"]), id > 0 else { throw PrinterError.malformed }
            commandMethods.append(method)
            try await socket.send(MQTTWire.packet(0x40, MQTTWire.word(request.2!)))
            let result: [String: Any] = method == 1001 ? ["error_code": 0, "sn": serial, "machine_model": "Centauri Carbon 2", "software_version": ["ota_version": "simulator-only"]] : ["error_code": 0, "machine_status": ["status": 1, "progress": 25], "extruder": ["temperature": 24.5], "heater_bed": ["temperature": 23.0]]
            try await socket.send(MQTTWire.publish(topic: prefix + client + "/api_response", body: try JSONSerialization.data(withJSONObject: ["id": id, "result": result]), packetID: packetID))
        }
    }
}

final class PrinterTests: XCTestCase {
    @MainActor func testRealLoopbackUDPHTTPMQTTStatusAndCleanDisconnect() async throws {
        let fake = FakePrinter(); fake.booleanFlags = true; try await fake.start(); defer { fake.stop() }
        let client = PrinterClient()
        let status = try await client.status(ip: "127.0.0.1", code: fake.code, pinnedSerial: fake.serial,
            discoveryPort: fake.ports[0], httpPort: fake.ports[1], mqttPort: fake.ports[2], testingLoopback: true)
        XCTAssertEqual(status.state, "Idle"); XCTAssertEqual(status.nozzle, 24.5); XCTAssertEqual(status.bed, 23)
        XCTAssertEqual(status.identity.serial, fake.serial); XCTAssertEqual(status.version, "simulator-only")
        XCTAssertEqual(fake.commandMethods, [1001, 1002]); client.close()
    }
    @MainActor func testAccessCodeRejectionDoesNotReadStatusOrMutate() async throws {
        let fake = FakePrinter(); fake.rejectAuth = true; try await fake.start(); defer { fake.stop() }
        do { _ = try await PrinterClient().status(ip: "127.0.0.1", code: fake.code, pinnedSerial: fake.serial,
            discoveryPort: fake.ports[0], httpPort: fake.ports[1], mqttPort: fake.ports[2], testingLoopback: true); XCTFail("Accepted rejected auth") }
        catch { XCTAssertEqual(error.localizedDescription, PrinterError.rejected.localizedDescription) }
        XCTAssertTrue(fake.commandMethods.isEmpty)
    }
    @MainActor func testHTTPSerialMismatchStopsBeforeMQTT() async throws {
        let fake = FakePrinter(); fake.wrongSerial = true; try await fake.start(); defer { fake.stop() }
        do { _ = try await PrinterClient().status(ip: "127.0.0.1", code: fake.code, pinnedSerial: fake.serial,
            discoveryPort: fake.ports[0], httpPort: fake.ports[1], mqttPort: fake.ports[2], testingLoopback: true); XCTFail("Accepted wrong printer") }
        catch { XCTAssertEqual(error.localizedDescription, PrinterError.wrongPrinter.localizedDescription) }
        XCTAssertTrue(fake.commandMethods.isEmpty)
    }
    @MainActor func testHTTPAccessErrorStopsBeforeMQTTWithAuthMessage() async throws {
        let fake = FakePrinter(); fake.rejectHTTPAuth = true; try await fake.start(); defer { fake.stop() }
        do { _ = try await PrinterClient().status(ip: "127.0.0.1", code: fake.code, pinnedSerial: fake.serial,
            discoveryPort: fake.ports[0], httpPort: fake.ports[1], mqttPort: fake.ports[2], testingLoopback: true); XCTFail("Accepted HTTP access rejection") }
        catch { XCTAssertEqual(error.localizedDescription, PrinterError.rejected.localizedDescription) }
        XCTAssertTrue(fake.commandMethods.isEmpty)
    }
    func testOfficialDiscoveryFlagsAcceptBoolAndIntegerOnly() throws {
        for flag in ["true", "1"] {
            let data = Data("{\"id\":0,\"result\":{\"machine_model\":\"Centauri Carbon 2\",\"sn\":\"PUBLIC_TEST_CC2_001\",\"host_name\":\"Fake\",\"token_status\":\(flag),\"lan_status\":\(flag)}}".utf8)
            XCTAssertEqual(try PrinterJSON.discovery(data, ip: "192.168.25.2").serial, "PUBLIC_TEST_CC2_001")
        }
        for flag in ["false", "0"] {
            let values = try JSONSerialization.jsonObject(with: Data("[\(flag)]".utf8)) as! [Any]
            XCTAssertEqual(PrinterJSON.flag(values[0]), false)
            let data = Data("{\"id\":0,\"result\":{\"machine_model\":\"Centauri Carbon 2\",\"sn\":\"PUBLIC_TEST_CC2_001\",\"host_name\":\"Fake\",\"token_status\":true,\"lan_status\":\(flag)}}".utf8)
            XCTAssertThrowsError(try PrinterJSON.discovery(data, ip: "192.168.25.2")) { error in
                XCTAssertEqual(error.localizedDescription, PrinterError.cloudMode.localizedDescription)
            }
        }
        for flag in ["\"1\"", "2", "null", "1.0"] {
            let data = Data("{\"id\":0,\"result\":{\"machine_model\":\"Centauri Carbon 2\",\"sn\":\"PUBLIC_TEST_CC2_001\",\"host_name\":\"Fake\",\"token_status\":\(flag),\"lan_status\":true}}".utf8)
            XCTAssertThrowsError(try PrinterJSON.discovery(data, ip: "192.168.25.2"))
        }
    }
    @MainActor func testWrongRegistrationClientRejected() async throws {
        let fake = FakePrinter(); fake.wrongRegistration = true; try await fake.start(); defer { fake.stop() }
        do { _ = try await PrinterClient().status(ip: "127.0.0.1", code: fake.code, pinnedSerial: fake.serial,
            discoveryPort: fake.ports[0], httpPort: fake.ports[1], mqttPort: fake.ports[2], testingLoopback: true); XCTFail("Accepted wrong registration") }
        catch { XCTAssertEqual(error.localizedDescription, PrinterError.rejected.localizedDescription) }
        XCTAssertTrue(fake.commandMethods.isEmpty)
    }
    func testHTTPFramingRefusesRedirectDuplicateLengthAndSupportsChunks() throws {
        XCTAssertThrowsError(try HTTPPrinterWire.body(Data("HTTP/1.1 302 Found\r\nContent-Length: 2\r\n\r\n{}".utf8)))
        XCTAssertThrowsError(try HTTPPrinterWire.body(Data("HTTP/1.1 200 OK\r\nContent-Length: 2\r\nContent-Length: 2\r\n\r\n{}".utf8)))
        XCTAssertNil(try HTTPPrinterWire.body(Data("HTTP/1.1 200 OK\r\nContent-Length: 4\r\n\r\n{}".utf8)))
        XCTAssertEqual(try HTTPPrinterWire.body(Data("HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n2\r\n{}\r\n0\r\n\r\n".utf8)), Data("{}".utf8))
    }
    func testMalformedMQTTAndRetainedStaleStatusRejected() {
        XCTAssertThrowsError(try MQTTWire.publication(0x33, Data([0, 1, 97, 0, 1, 123, 125])))
        XCTAssertThrowsError(try MQTTWire.publication(0x32, Data([0, 10, 97])))
        XCTAssertThrowsError(try PrinterJSON.result(Data("{\"id\":true,\"result\":{\"error_code\":0}}".utf8), id: 1))
        XCTAssertThrowsError(try PrinterJSON.result(Data("{\"id\":10,\"result\":{\"error_code\":1}}".utf8), id: 10))
        XCTAssertThrowsError(try MQTTWire.string(String(repeating: "x", count: 65536)))
        XCTAssertThrowsError(try MQTTWire.publication(0x38, Data([0, 1, 97, 123, 125])))
        XCTAssertThrowsError(try PrinterJSON.object(Data("{\"id\":1,\"id\":2}".utf8)))
        XCTAssertThrowsError(try PrinterJSON.object(Data("{\"sn\":\"a\",\"\\u0073n\":\"b\"}".utf8)))
        XCTAssertThrowsError(try PrinterJSON.object(Data("{\"value\":1e999}".utf8)))
    }
    @MainActor func testProductionRefusesLoopbackPublicIPAndHeaderInjection() async {
        for (ip, code) in [("8.8.8.8", "code"), ("127.0.0.1", "code"), ("192.168.1.2", "x\r\nInjected: true")] {
            do { _ = try await PrinterClient().status(ip: ip, code: code, pinnedSerial: nil); XCTFail("Unsafe setup accepted") }
            catch { XCTAssertEqual(error.localizedDescription, PrinterError.invalidSetup.localizedDescription) }
        }
    }
    @MainActor func testAddressChangeAndDisconnectClearSnapshotAndSelection() {
        let model = PrinterModel(); model.addressChanged(); XCTAssertNil(model.snapshot); XCTAssertNil(model.selected); XCTAssertFalse(model.busy)
        model.connect(); XCTAssertNotNil(model.error); model.disconnect(); XCTAssertFalse(model.busy)
    }
    func testAbsoluteDeadlineStopsSlowFragmentedMQTTBody() async throws {
        let parameters = NWParameters.tcp; parameters.requiredLocalEndpoint = .hostPort(host: "127.0.0.1", port: .any)
        let listener = try NWListener(using: parameters), queue = DispatchQueue(label: "SlowLocalFixture")
        var peer: NWConnection?
        defer { listener.cancel(); peer?.cancel() }
        let port = try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<UInt16, Error>) in
            let lock = NSLock(); var done = false
            func finish(_ result: Result<UInt16, Error>) {
                lock.lock(); guard !done else { lock.unlock(); return }; done = true; lock.unlock(); continuation.resume(with: result)
            }
            listener.stateUpdateHandler = { state in
                if case .ready = state { finish(.success(listener.port!.rawValue)) }
                if case .failed(let error) = state { finish(.failure(error)) }
            }
            queue.asyncAfter(deadline: .now() + 3) { finish(.failure(PrinterError.timeout)); listener.cancel() }
            listener.newConnectionHandler = { connection in
                peer = connection; connection.start(queue: queue)
                connection.send(content: Data([0x30, 5]), completion: .contentProcessed { _ in })
                for n in 1...5 {
                    queue.asyncAfter(deadline: .now() + Double(n) * 0.15) { connection.send(content: Data([UInt8(n)]), completion: .contentProcessed { _ in }) }
                }
            }
            listener.start(queue: queue)
        }
        let started = ProcessInfo.processInfo.systemUptime
        let socket = PrinterSocket(host: "127.0.0.1", port: port, deadline: started + 0.4); defer { socket.close() }
        try await socket.open()
        do { _ = try await socket.mqttPacket(); XCTFail("Slow fragments bypassed absolute deadline") }
        catch { XCTAssertEqual(error.localizedDescription, PrinterError.timeout.localizedDescription) }
        XCTAssertLessThan(ProcessInfo.processInfo.systemUptime - started, 1.5)
    }
    @MainActor func testUnsupportedElegooModelCannotSendCarbon2Requests() {
        let model = PrinterModel(); model.family = .carbon; model.ip = "192.168.25.2"
        model.discover(); XCTAssertFalse(model.busy); XCTAssertNotNil(model.error)
        model.connect(); XCTAssertFalse(model.busy); XCTAssertNil(model.snapshot)
        XCTAssertTrue(ElegooFamily.allCases.allSatisfy { $0 == .carbon2 || !$0.supported })
    }
    func testSavedProfileNameAndIdentityBounds() {
        XCTAssertTrue(PrinterProfile.validName("Workshop Carbon 2"))
        XCTAssertFalse(PrinterProfile.validName("  ")); XCTAssertFalse(PrinterProfile.validName("name\ncommand"))
        XCTAssertFalse(PrinterProfile.validName(String(repeating: "x", count: 65)))
    }
    @MainActor func testCancelledOperationDoesNotCloseFreshConnection() async throws {
        let slow = FakePrinter(); slow.dropDiscovery = true; try await slow.start(); defer { slow.stop() }
        let first = PrinterClient()
        let old = Task {
            do { _ = try await first.status(ip: "127.0.0.1", code: slow.code, pinnedSerial: slow.serial,
                discoveryPort: slow.ports[0], httpPort: slow.ports[1], mqttPort: slow.ports[2], testingLoopback: true); XCTFail("Cancelled operation succeeded") }
            catch { XCTAssertEqual(error.localizedDescription, PrinterError.disconnected.localizedDescription) }
        }
        try await Task.sleep(nanoseconds: 100_000_000); first.close()
        let fresh = FakePrinter(); try await fresh.start(); defer { fresh.stop() }
        let status = try await PrinterClient().status(ip: "127.0.0.1", code: fresh.code, pinnedSerial: fresh.serial,
            discoveryPort: fresh.ports[0], httpPort: fresh.ports[1], mqttPort: fresh.ports[2], testingLoopback: true)
        await old.value; XCTAssertEqual(status.state, "Idle")
    }
}
