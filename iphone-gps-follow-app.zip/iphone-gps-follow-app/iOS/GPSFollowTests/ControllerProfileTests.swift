import XCTest
@testable import GPSFollow

final class ControllerProfileTests: XCTestCase {
    func testVerifiedTX15MaxMappings() throws {
        let profile = try ControllerProfileRules.validate(.tx15Max, allowVerified: true)
        XCTAssertEqual(profile.name, "RadioMaster TX15 Max")
        XCTAssertEqual(Array(profile.mappings.prefix(6).map { "\($0.input)|\($0.channel)|\($0.action)" }), [
            "Button 1|CH12|Stabilize", "Button 2|CH12|AltHold", "Button 3|CH12|Loiter",
            "Button 4|CH12|Brake", "Button 5|CH12|RTL", "Button 6|CH12|Land"])
        XCTAssertTrue(profile.mappings.contains { $0.input == "SE press" && $0.channel == "CH9" })
        XCTAssertTrue(profile.mappings.contains { $0.input == "SA UP" && $0.channel == "CH10" && $0.action == "Disarm" })
        XCTAssertTrue(profile.mappings.contains { $0.input == "SA MIDDLE" && $0.channel == "CH10" && $0.action == "Arm" })
        XCTAssertTrue(profile.mappings.contains { $0.input == "SA DOWN" && $0.action == "RTL" })
        let gear = profile.mappings.filter { $0.input == "S1" }
        XCTAssertEqual(gear.count, 1)
        XCTAssertTrue(gear.allSatisfy { $0.channel == "CH8" && !$0.verified })
        XCTAssertFalse(profile.mappings.contains { $0.channel == "CH13" })
        XCTAssertTrue(profile.mappings.contains { $0.input == "SF DOWN" && $0.channel == "CH11" && $0.action == "Brake" })
        XCTAssertTrue(profile.mappings.contains { $0.input == "SD DOWN" && $0.action == "Land override" })
    }
    func testImportedProfileCannotClaimVerifiedAndCriticalConflictFails() throws {
        var custom = ControllerProfile.tx15Max; custom.name = "Other controller"; custom.verifiedPreset = true
        let imported = try ControllerProfileRules.imported(JSONEncoder().encode(custom))
        XCTAssertFalse(imported.verifiedPreset); XCTAssertTrue(imported.mappings.allSatisfy { !$0.verified })
        custom.mappings = [
            ControllerMapping(input: "Switch A", channel: "CH5", action: "Arm", verified: false),
            ControllerMapping(input: "switch a", channel: "CH6", action: "Disarm", verified: false)]
        XCTAssertThrowsError(try ControllerProfileRules.validate(custom))
    }
    func testExpressLRSAllowlistOnlyReturnsOfficialHTTPSPages() {
        XCTAssertFalse(ControllerProfileRules.automaticELRSFlashingSupported)
        XCTAssertNotNil(ControllerProfileRules.officialELRSURL("https://www.expresslrs.org/"))
        XCTAssertNotNil(ControllerProfileRules.officialELRSURL("https://expresslrs.github.io/web-flasher/"))
        XCTAssertNil(ControllerProfileRules.officialELRSURL("http://expresslrs.org/"))
        XCTAssertNil(ControllerProfileRules.officialELRSURL("https://example.com/flasher"))
    }
}
