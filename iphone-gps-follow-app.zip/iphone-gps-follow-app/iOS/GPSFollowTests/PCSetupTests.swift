import XCTest
@testable import GPSFollow

final class PCSetupTests: XCTestCase {
    private let card = "GPSFollow-local-setup-v1\npc_ip=192.168.25.2\nudp_port=45678\npairing_key=000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f\ncenter_lat=41.1\ncenter_lon=-87.1\nradius_m=50\nheight_m=5\nprotocol=aes-gcm-v2\ncompanion_version=1.2-r2\n"
    func testExplicitCardParsesMatchingEndpointsAndLimits() throws {
        let setup = try PCSetup.parse(card)
        XCTAssertEqual(setup.ip, "192.168.25.2"); XCTAssertEqual(setup.port, "45678")
        XCTAssertEqual(setup.version, "1.2-r2"); XCTAssertEqual(setup.key.count, 64)
        XCTAssertEqual(setup.lat, "41.1"); XCTAssertEqual(setup.height, "5")
        XCTAssertEqual(setup.targetRole, .owner); XCTAssertEqual(setup.targetID, "owner"); XCTAssertNil(setup.expiresMS)
        XCTAssertEqual(try PCSetup.parse(card.replacingOccurrences(of: "\n", with: "\r\n")).ip, setup.ip)
    }
    func testExpiringGuestCardParsesAndOwnerKeyIsNotImplied() throws {
        let expiry = Int64(Date().timeIntervalSince1970 * 1000) + 600_000
        let guest = card.replacingOccurrences(of: "GPSFollow-local-setup-v1", with: "GPSFollow-local-setup-v2") +
            "target_role=guest\ntarget_id=guest-abc123\nexpires_ms=\(expiry)\n"
        let setup = try PCSetup.parse(guest)
        XCTAssertEqual(setup.targetRole, .guest); XCTAssertEqual(setup.targetID, "guest-abc123")
        XCTAssertEqual(setup.expiresMS, expiry)
        XCTAssertThrowsError(try PCSetup.parse(guest.replacingOccurrences(of: "target_role=guest", with: "target_role=owner")))
    }
    func testCardRejectsDuplicatesExtrasWrongProtocolAndHugeInput() {
        for invalid in [card + "pc_ip=192.168.25.3\n", card.replacingOccurrences(of: "udp_port=45678", with: "pc_ip=192.168.25.3"), card.replacingOccurrences(of: "aes-gcm-v2", with: "plaintext-v1"), String(repeating: "x", count: 2049)] { XCTAssertThrowsError(try PCSetup.parse(invalid)) }
    }
    func testCardRejectsPublicIPInvalidKeyNonfiniteLimits() {
        for invalid in [card.replacingOccurrences(of: "192.168.25.2", with: "8.8.8.8"), card.replacingOccurrences(of: "radius_m=50", with: "radius_m=nan"), card.replacingOccurrences(of: "height_m=5", with: "height_m=21"), card.replacingOccurrences(of: "00010203", with: "zz010203")] { XCTAssertThrowsError(try PCSetup.parse(invalid)) }
    }
    func testBonjourTXTRejectsSecretsUntrustedProtocolAndBadPorts() {
        let fields = ["protocol": Data("aes-gcm-v2".utf8), "companion_version": Data("1.2-r2".utf8), "bench_only": Data("1".utf8)]
        XCTAssertEqual(PCBrowser.txt(NetService.data(fromTXTRecord: fields), port: 45678), "1.2-r2")
        var unsafe = fields; unsafe["pairing_key"] = Data("do-not-broadcast".utf8)
        XCTAssertNil(PCBrowser.txt(NetService.data(fromTXTRecord: unsafe), port: 45678))
        XCTAssertNil(PCBrowser.txt(NetService.data(fromTXTRecord: fields), port: 80))
        unsafe = fields; unsafe["protocol"] = Data("plaintext".utf8)
        XCTAssertNil(PCBrowser.txt(NetService.data(fromTXTRecord: unsafe), port: 45678))
    }
}
