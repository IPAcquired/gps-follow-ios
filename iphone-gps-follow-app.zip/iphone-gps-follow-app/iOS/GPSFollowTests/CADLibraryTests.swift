import XCTest
@testable import GPSFollow

final class CADLibraryTests: XCTestCase {
    private var folders: [URL] = []
    override func tearDownWithError() throws {
        for folder in folders { try FileManager.default.removeItem(at: folder) }
        folders = []
    }
    private func temporaryFolder() throws -> URL {
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        folders.append(folder)
        return folder
    }
    private func binarySTL(triangles: UInt32 = 1) -> Data {
        var data = Data(repeating: 0, count: 80)
        data.append(contentsOf: [UInt8(triangles & 255), UInt8((triangles >> 8) & 255), UInt8((triangles >> 16) & 255), UInt8((triangles >> 24) & 255)])
        data.append(Data(repeating: 0, count: 50))
        return data
    }
    func testFilenameCannotEscapeLibrary() throws {
        XCTAssertEqual(try CADPolicy.safeName("../../tray.stl"), "tray.stl")
        XCTAssertEqual(try CADPolicy.safeName("bad<>name.STL"), "bad__name.stl")
        XCTAssertFalse(try CADPolicy.safeName(String(repeating: "x", count: 300) + ".3mf").contains("/"))
        XCTAssertEqual(try CADPolicy.safeName(String(repeating: "x", count: 300) + ".3mf").count, 84)
        XCTAssertThrowsError(try CADPolicy.safeName("part.gcode"))
        XCTAssertThrowsError(try CADPolicy.safeName("part.stl.exe"))
    }
    func testHeaderChecksRejectMalformedAndTruncatedSTL() throws {
        XCTAssertNoThrow(try CADPolicy.validateHeader(binarySTL(), extension: "stl"))
        XCTAssertThrowsError(try CADPolicy.validateHeader(binarySTL(triangles: UInt32.max), extension: "stl"))
        XCTAssertThrowsError(try CADPolicy.validateHeader(Data(binarySTL().dropLast()), extension: "stl"))
        XCTAssertThrowsError(try CADPolicy.validateHeader(Data("hello".utf8), extension: "stl"))
        XCTAssertNoThrow(try CADPolicy.validateHeader(Data("solid part\nendsolid part\n".utf8), extension: "stl"))
        XCTAssertThrowsError(try CADPolicy.validateHeader(Data("solid part".utf8), extension: "stl"))
    }
    func test3MFOnlyChecksZIPHeaderAndNeverExtracts() {
        XCTAssertNoThrow(try CADPolicy.validateHeader(Data([0x50, 0x4b, 0x03, 0x04, 1]), extension: "3mf"))
        XCTAssertThrowsError(try CADPolicy.validateHeader(Data("not an archive".utf8), extension: "3mf"))
        XCTAssertThrowsError(try CADPolicy.validateHeader(Data(), extension: "3mf"))
    }
    func testImportPreservesBytesAndAvoidsNameCollisions() throws {
        let root = try temporaryFolder()
        let source = root.appendingPathComponent("landing leg.stl")
        let data = binarySTL()
        try data.write(to: source)
        let library = CADLibrary(directory: root.appendingPathComponent("library"))
        let a = try library.importFile(source)
        let b = try library.importFile(source)
        XCTAssertEqual(library.items.count, 2)
        XCTAssertNotEqual(a.url, b.url)
        XCTAssertEqual(try Data(contentsOf: a.url), data)
        XCTAssertEqual(a.name, "landing_leg.stl")
        library.remove(a)
        XCTAssertEqual(library.items.count, 1)
        XCTAssertTrue(FileManager.default.fileExists(atPath: source.path))
    }
    func testSymlinkFolderAndUnsupportedTypeRejected() throws {
        let root = try temporaryFolder()
        let source = root.appendingPathComponent("part.stl")
        try binarySTL().write(to: source)
        let link = root.appendingPathComponent("shortcut.stl")
        try FileManager.default.createSymbolicLink(at: link, withDestinationURL: source)
        let folder = root.appendingPathComponent("folder.stl", isDirectory: true)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        let unsupported = root.appendingPathComponent("job.gcode")
        try binarySTL().write(to: unsupported)
        let library = CADLibrary(directory: root.appendingPathComponent("library"))
        XCTAssertThrowsError(try library.importFile(link))
        XCTAssertThrowsError(try library.importFile(folder))
        XCTAssertThrowsError(try library.importFile(unsupported))
        XCTAssertTrue(library.items.isEmpty)
    }
    func testUnlistedFileCannotBeDeleted() throws {
        let root = try temporaryFolder()
        let source = root.appendingPathComponent("part.stl")
        try binarySTL().write(to: source)
        let library = CADLibrary(directory: root.appendingPathComponent("library"))
        library.remove(CADItem(url: source, name: "part.stl", bytes: 134))
        XCTAssertTrue(FileManager.default.fileExists(atPath: source.path))
    }
    func testOversizedFileRejectedWithoutLoadingIt() throws {
        let root = try temporaryFolder()
        let source = root.appendingPathComponent("large.stl")
        FileManager.default.createFile(atPath: source.path, contents: binarySTL())
        let file = try FileHandle(forWritingTo: source)
        try file.truncate(atOffset: UInt64(CADPolicy.maxFileBytes + 1))
        try file.close()
        let library = CADLibrary(directory: root.appendingPathComponent("library"))
        XCTAssertThrowsError(try library.importFile(source))
        XCTAssertTrue(library.items.isEmpty)
    }
    func testMaximumFileCountEnforcedWithoutOverwriting() throws {
        let root = try temporaryFolder()
        let store = root.appendingPathComponent("library")
        let library = CADLibrary(directory: store)
        let data = binarySTL()
        for number in 0..<CADPolicy.maxFiles {
            try data.write(to: store.appendingPathComponent("part_\(number).stl"))
        }
        let source = root.appendingPathComponent("next.stl")
        try data.write(to: source)
        XCTAssertThrowsError(try library.importFile(source))
        XCTAssertEqual(library.items.count, CADPolicy.maxFiles)
        XCTAssertEqual(try Data(contentsOf: store.appendingPathComponent("part_0.stl")), data)
    }
}
