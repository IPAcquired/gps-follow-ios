import XCTest
@testable import GPSFollow

final class RelayConnectionTests: XCTestCase {
    private let key = Data((0...31).map { UInt8($0) }) // Public test key; never a live pairing key.
    private func clock() -> Int64 { Int64(Date().timeIntervalSince1970 * 1000) }
    private func pair(_ socket: PrinterSocket, nonce: String) async throws -> String {
        try await socket.open()
        let hello: [String: Any] = ["v": 2, "kind": "hello", "client_nonce": nonce, "sent_ms": clock()]
        try await socket.send(try XCTUnwrap(AuthenticatedJSON.encode(hello, key: key)))
        let reply = try await socket.datagram()
        let challenge = try XCTUnwrap(AuthenticatedJSON.decode(reply, key: key))
        XCTAssertEqual(challenge["kind"] as? String, "challenge")
        XCTAssertEqual(challenge["client_nonce"] as? String, nonce)
        return try XCTUnwrap(challenge["relay_nonce"] as? String)
    }
    private func target(nonce: String, relay: String, sequence: Int, old: Bool = false) -> [String: Any] {
        ["v": 2, "kind": "position", "client_nonce": nonce, "relay_nonce": relay, "sent_ms": clock(), "sequence": sequence,
         "lat": 41.1234567, "lon": -87.7654321, "accuracy_m": 2.0, "speed_mps": 0.0, "fix_ms": clock() - (old ? 5000 : 0)]
    }
    func testNativeEncryptedUDPHandshakeTargetAndStopAgainstPythonSession() async throws {
        let socket = PrinterSocket(host: "127.0.0.1", port: 35678, udp: true); defer { socket.close() }
        let nonce = UUID().uuidString.replacingOccurrences(of: "-", with: "").lowercased()
        let relay = try await pair(socket, nonce: nonce)
        try await socket.send(try XCTUnwrap(AuthenticatedJSON.encode(target(nonce: nonce, relay: relay, sequence: 1), key: key)))
        let ackData = try await socket.datagram()
        let ack = try XCTUnwrap(AuthenticatedJSON.decode(ackData, key: key))
        XCTAssertEqual(ack["status"] as? String, "accepted"); XCTAssertEqual(ack["serial_ready"] as? Bool, false)
        let stop: [String: Any] = ["v": 2, "kind": "stop", "client_nonce": nonce, "relay_nonce": relay, "sequence": 2, "sent_ms": clock()]
        try await socket.send(try XCTUnwrap(AuthenticatedJSON.encode(stop, key: key)))
        let stopped = try await socket.datagram()
        XCTAssertEqual(AuthenticatedJSON.decode(stopped, key: key)?["status"] as? String, "stopped")
    }
    func testNativeStaleFixRejectedAndFreshSequenceRecovers() async throws {
        let socket = PrinterSocket(host: "127.0.0.1", port: 35678, udp: true); defer { socket.close() }
        let nonce = UUID().uuidString.replacingOccurrences(of: "-", with: "").lowercased(), relay = try await pair(socket, nonce: nonce)
        try await socket.send(try XCTUnwrap(AuthenticatedJSON.encode(target(nonce: nonce, relay: relay, sequence: 1, old: true), key: key)))
        let rejected = try await socket.datagram()
        XCTAssertEqual(AuthenticatedJSON.decode(rejected, key: key)?["status"] as? String, "rejected")
        try await socket.send(try XCTUnwrap(AuthenticatedJSON.encode(target(nonce: nonce, relay: relay, sequence: 2), key: key)))
        let accepted = try await socket.datagram()
        XCTAssertEqual(AuthenticatedJSON.decode(accepted, key: key)?["status"] as? String, "accepted")
    }
    func testNativeWrongKeyHasNoAuthenticatedResponse() async throws {
        let socket = PrinterSocket(host: "127.0.0.1", port: 35678, udp: true); defer { socket.close() }; try await socket.open()
        let hello: [String: Any] = ["v": 2, "kind": "hello", "client_nonce": String(repeating: "a", count: 32), "sent_ms": clock()]
        try await socket.send(try XCTUnwrap(AuthenticatedJSON.encode(hello, key: Data(repeating: 255, count: 32))))
        do { _ = try await socket.datagram(); XCTFail("Wrong key received a response") }
        catch { XCTAssertEqual(error.localizedDescription, PrinterError.timeout.localizedDescription) }
    }
    func testNativeReplayedSequenceDroppedThenNewSequenceAccepted() async throws {
        let socket = PrinterSocket(host: "127.0.0.1", port: 35678, udp: true); defer { socket.close() }
        let nonce = UUID().uuidString.replacingOccurrences(of: "-", with: "").lowercased(), relay = try await pair(socket, nonce: nonce)
        let packet = try XCTUnwrap(AuthenticatedJSON.encode(target(nonce: nonce, relay: relay, sequence: 1), key: key))
        try await socket.send(packet); _ = try await socket.datagram(); try await socket.send(packet)
        do { _ = try await socket.datagram(); XCTFail("Replayed target accepted") }
        catch { XCTAssertEqual(error.localizedDescription, PrinterError.timeout.localizedDescription) }
        // A timed-out outstanding receive is closed before reconnecting; do not revive it.
        socket.close()
        let recovered = PrinterSocket(host: "127.0.0.1", port: 35678, udp: true); defer { recovered.close() }
        let freshNonce = UUID().uuidString.replacingOccurrences(of: "-", with: "").lowercased(), freshRelay = try await pair(recovered, nonce: freshNonce)
        try await recovered.send(try XCTUnwrap(AuthenticatedJSON.encode(target(nonce: freshNonce, relay: freshRelay, sequence: 1), key: key)))
        let recoveredData = try await recovered.datagram()
        XCTAssertEqual(AuthenticatedJSON.decode(recoveredData, key: key)?["status"] as? String, "accepted")
    }
}
