import XCTest
@testable import GPSFollow

final class AppProfileTests: XCTestCase {
    func testNateDefaultAndTX15HardwareGate() throws {
        XCTAssertEqual(AppProfileRules.builtins.first?.id, "nate-micoair-h743v2-relay")
        XCTAssertTrue(AppProfileRules.builtins.first?.recommended == true)
        let tx15 = try XCTUnwrap(AppProfileRules.builtins.last)
        XCTAssertTrue(tx15.requirements.contains("Physical compatible Bluetooth module"))
        XCTAssertTrue(tx15.limitations.contains("Firmware alone cannot add"))
    }
    func testImportedProfileCannotClaimRecommended() throws {
        var item = AppConnectionProfile.nateMicoAir
        item.id = "custom"; item.name = "Custom"; item.recommended = true
        let imported = try AppProfileRules.imported(JSONEncoder().encode(item))
        XCTAssertFalse(imported.recommended); XCTAssertTrue(imported.editable)
    }
    func testBackgroundChoicesRemainLocalPresentationOnly() {
        XCTAssertEqual(AppBackgroundPreset.allCases.count, 4)
        XCTAssertTrue(AppBackgroundPreset.nwMatrix.showsMatrix)
        XCTAssertFalse(AppBackgroundPreset.solidBlack.showsMatrix)
    }
    func testIPhoneProfilesIncludeNatesPhoneAndAutomaticFallback() {
        XCTAssertTrue(IPhoneDeviceProfile.allCases.contains(.automatic))
        XCTAssertTrue(IPhoneDeviceProfile.allCases.contains(.iPhone16))
        XCTAssertFalse(IPhoneDeviceProfile.iPhone16.layoutHint.isEmpty)
        XCTAssertFalse(IPhoneDeviceProfile.iPhoneSE3.layoutHint.isEmpty)
    }
    func testFlightStackProtocolsAndFollowGuard() throws {
        XCTAssertEqual(FlightStackProfile.ardupilot.protocolName, "MAVLink v2")
        XCTAssertEqual(FlightStackProfile.px4.protocolName, "MAVLink v2")
        XCTAssertEqual(FlightStackProfile.inav.protocolName, "MSP v2")
        XCTAssertEqual(FlightStackProfile.betaflight.protocolName, "MSP v1 / v2")
        XCTAssertNoThrow(try FlightStackProfile.validate(id: "ArduPilot", protocolName: "MAVLink v2", wantsFollow: true))
        for profile in [FlightStackProfile.px4, .inav, .betaflight] {
            XCTAssertThrowsError(try FlightStackProfile.validate(id: profile.rawValue, protocolName: profile.protocolName, wantsFollow: true))
        }
        XCTAssertThrowsError(try FlightStackProfile.validate(id: "iNav", protocolName: "MAVLink v2", wantsFollow: false))
    }
}
