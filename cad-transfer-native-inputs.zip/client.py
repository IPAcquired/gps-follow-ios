"""Reference client for bounded local loopback tests; no automatic connection."""
from __future__ import annotations
import hashlib
import http.client
import secrets
import time
if __package__:
    from .protocol import *
else:
    from protocol import *

class CADClient:
    def __init__(self,key:bytes,pc_ip:str,port:int=8766,*,loopback_test=False):
        self.key=key;self.ip=address(pc_ip,test=loopback_test);self.port=integer(port,1024,65535)
        derive(key,'bootstrap');self.sid=None;self.seq=2;self.deadline=0;self.receive=None;self.send=None
    def post(self,path,wire):
        if path not in ('/cad/v1/challenge','/cad/v1/auth','/cad/v1/message') or len(wire)>MAX_WIRE:raise Rejected('Request')
        c=http.client.HTTPConnection(self.ip,self.port,timeout=3)
        try:
            c.request('POST',path,body=wire,headers={'Content-Type':'application/json','Connection':'close'})
            r=c.getresponse();length=r.getheader('Content-Length')
            if r.status!=200 or r.getheader('Content-Type')!='application/json' or length is None or not length.isascii() or not length.isdigit() or not 1<=int(length)<=MAX_WIRE or r.getheader('Transfer-Encoding') is not None:raise Rejected('Server rejected request or response framing')
            out=r.read(MAX_WIRE+1)
            if len(out)!=int(length):raise Rejected('Response size')
            return out
        finally:c.close()
    def connect(self):
        self.close();client=secrets.token_hex(32);started=time.monotonic()
        wire=self.post('/cad/v1/challenge',pack({'v':1,'client':client},256));env=parse(wire,MAX_WIRE);sid=token(env.get('sid'))
        q=fields(open_message(wire,derive(self.key,'bootstrap'),'challenge',sid,0),{'v','op','boot','client','challenge','ttl_ms'})
        if type(q['v']) is not int or q['v']!=1 or q['op']!='challenge' or q['client']!=client or type(q['ttl_ms']) is not int or q['ttl_ms']!=CHALLENGE_SECONDS*1000 or time.monotonic()-started>=CHALLENGE_SECONDS:raise Rejected('Challenge mismatch or expired')
        send,receive=session_keys(self.key,q['boot'],sid,q['challenge'],client)
        auth={'v':1,'op':'authenticate','boot':q['boot'],'client':client,'challenge':q['challenge']}
        wire=self.post('/cad/v1/auth',seal(auth,send,'phone-to-pc',sid,1))
        result=fields(open_message(wire,receive,'pc-to-phone',sid,1),{'v','op','ok','ttl_ms'})
        if result!={'v':1,'op':'authenticated','ok':True,'ttl_ms':SESSION_SECONDS*1000} or type(result['v']) is not int or type(result['ok']) is not bool or type(result['ttl_ms']) is not int:raise Rejected('Authentication response')
        self.sid=sid;self.send=send;self.receive=receive;self.seq=2;self.deadline=started+SESSION_SECONDS
    def close(self):
        self.sid=None;self.send=None;self.receive=None;self.deadline=0
    def request(self,op,**values):
        if not self.sid or time.monotonic()>=self.deadline or self.seq>MAX_REQUESTS:self.close();raise Rejected('No live session')
        seq=self.seq
        try:
            wire=self.post('/cad/v1/message',seal({'v':1,'op':op,**values},self.send,'phone-to-pc',self.sid,seq))
            q=open_message(wire,self.receive,'pc-to-phone',self.sid,seq)
            if type(q.get('v')) is not int or q.get('v')!=1 or q.get('op')!=op or q.get('ok') is not True:raise Rejected('Response mismatch')
            self.seq+=1;return q
        except Exception:
            self.close();raise
    def list(self):
        q=fields(self.request('list'),{'v','op','ok','items'})
        if not isinstance(q['items'],list) or len(q['items'])>MAX_FILES:raise Rejected('List size')
        return [self.item(x) for x in q['items']]
    @staticmethod
    def item(x):
        fields(x,{'id','sha256','name','bytes'});token(x['id']);token(x['sha256'],32);safe_name(x['name']);integer(x['bytes'],1,MAX_FILE)
        return x
    def upload(self,name,data:bytes):
        name=safe_name(name);validate_cad(data,name);digest=hashlib.sha256(data).hexdigest()
        q=fields(self.request('begin-upload',name=name,bytes=len(data),sha256=digest),{'v','op','ok','transfer','chunk_bytes'});transfer=token(q['transfer'])
        if type(q['chunk_bytes']) is not int or q['chunk_bytes']!=CHUNK:raise Rejected('Chunk size')
        for offset in range(0,len(data),CHUNK):
            chunk=data[offset:offset+CHUNK]
            q=fields(self.request('upload-chunk',transfer=transfer,offset=offset,data=b64(chunk),sha256=hashlib.sha256(chunk).hexdigest()),{'v','op','ok','received'})
            if type(q['received']) is not int or q['received']!=offset+len(chunk):raise Rejected('Acknowledgement')
        q=fields(self.request('commit',transfer=transfer),{'v','op','ok','item'});item=self.item(q['item'])
        if (item['name'],item['sha256'],item['bytes'])!=(name,digest,len(data)):raise Rejected('Commit mismatch')
        return item
    def download(self,oid):
        q=fields(self.request('begin-download',id=token(oid)),{'v','op','ok','transfer','item','chunk_bytes'});transfer=token(q['transfer']);item=self.item(q['item'])
        if item['id']!=oid or type(q['chunk_bytes']) is not int or q['chunk_bytes']!=CHUNK:raise Rejected('Download metadata')
        data=bytearray()
        while len(data)<item['bytes']:
            offset=len(data);q=fields(self.request('download-chunk',transfer=transfer,offset=offset),{'v','op','ok','offset','data','sha256','done'})
            chunk=unb64(q['data'],CHUNK)
            if type(q['offset']) is not int or q['offset']!=offset or len(chunk)!=min(CHUNK,item['bytes']-offset) or hashlib.sha256(chunk).hexdigest()!=token(q['sha256'],32) or type(q['done']) is not bool or q['done']!=(offset+len(chunk)==item['bytes']):raise Rejected('Download chunk')
            data.extend(chunk)
        if hashlib.sha256(data).hexdigest()!=item['sha256']:raise Rejected('Download hash')
        validate_cad(bytes(data),item['name']);return item,bytes(data)
