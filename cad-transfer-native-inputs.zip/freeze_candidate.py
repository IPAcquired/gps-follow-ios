"""Freeze review inputs, excluding process caches and temporary test storage."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import zipfile

root=Path(__file__).resolve().parent
names=['__init__.py','protocol.py','storage.py','server.py','client.py','CADTransferClient.swift','Package.swift','test_candidate.py','generate_fixtures.py','loopback_fixture_server.py','run_native_fixture.py','freeze_candidate.py','README.md','PROTOCOL.md','cad-fixtures.json','SwiftTests/CADTransferCandidateTests.swift','SwiftTests/cad-fixtures.json','test-results.json','deadline-tests.json']
tests=json.loads((root/'test-results.json').read_text())
assert tests['success'] and tests['tests_run']==44 and not tests['skipped']
files={name:{'sha256':hashlib.sha256((root/name).read_bytes()).hexdigest(),'bytes':(root/name).stat().st_size} for name in names}
manifest={'candidate':'personal-secure-cad-transfer-v1-r2-20261003','created_utc':datetime.now(timezone.utc).isoformat(),'status':'isolated_review_candidate','revision':'Absolute accepted-socket watchdog and event/deadline-aware read/write streams; Stop closes active request before shutdown; R1 frozen source preserved','installed':False,'integrated':False,'production_listener_started':False,'private_pairing_key_read':False,'files':files,'validation':{'python':tests,'package_import_smoke':'Windows R2 relative package import inert; real loopback upload/download passed','targeted_deadline_tests':json.loads((root/'deadline-tests.json').read_text()),'native_swift':'not run in Windows authoring environment; run_native_fixture.py required before integration','independent_review':'pending'},'limits':{'file_bytes':20*1024*1024,'completed_plus_reserved_bytes':128*1024*1024,'chunk_bytes':256*1024,'wire_bytes':512*1024,'active_sessions':1,'pending_challenges':4,'challenge_seconds':10,'session_seconds':180,'absolute_accepted_socket_seconds':3,'stream_poll_seconds':.1,'max_requests':1024,'max_root_entries':128},'production_api':'Vendor as a separate cad_transfer package; CADServer(), start(existing_32_byte_key, selected_private_pc_ip, selected_private_phone_ip, port=8766), running, stop(); existing apps untouched','native_api':'Standalone Swift package; python run_native_fixture.py starts synthetic 127.0.0.1 fixture and runs swift test with CAD_LOOPBACK_PORT; no device/private key'}
(root/'candidate-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
out=root.parents[1]/'outputs/secure-cad-transfer-candidate-r2-20261003';out.mkdir(parents=True,exist_ok=True)
archive=out/'cad-transfer-native-inputs.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for name in names+['candidate-manifest.json']:z.write(root/name,arcname=name)
digest=hashlib.sha256(archive.read_bytes()).hexdigest()
(out/'archive-pin.json').write_text(json.dumps({'file':str(archive),'bytes':archive.stat().st_size,'sha256':digest,'manifest_sha256':hashlib.sha256((root/'candidate-manifest.json').read_bytes()).hexdigest(),'status':'native/unintegrated review input only'},indent=2)+'\n')
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':digest,'manifest_sha256':hashlib.sha256((root/'candidate-manifest.json').read_bytes()).hexdigest()}))
