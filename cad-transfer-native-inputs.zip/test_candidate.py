import hashlib
import http.client
import json
import os
from pathlib import Path
import secrets
import socket
import tempfile
import time
import threading
import unittest
from unittest.mock import patch
from protocol import *
from storage import Storage
from server import Core,CADServer
import server as server_module
from client import CADClient

ROOT=Path(__file__).resolve().parent
KEY=bytes(range(32))  # Public synthetic fixture, never an existing pairing key.
STL=b'solid test\nendsolid test\n'

class TestProtocol(unittest.TestCase):
    def test_domain_separation(self):
        keys=[derive(KEY,p) for p in ('bootstrap','phone-to-pc','pc-to-phone')]
        self.assertEqual(len(set(keys+[KEY])),4)
    def test_addresses(self):
        for value in ('8.8.8.8','localhost','0.0.0.0','127.0.0.1','::1','192.168.1.255','192.168.1.0','192.168.001.2'):
            with self.subTest(value=value),self.assertRaises(Rejected):address(value)
        self.assertEqual(address('192.168.1.2'),'192.168.1.2')
    def test_traversal_and_extensions(self):
        for name in ('../part.stl','..\\part.stl','C:\\part.stl','/part.stl','part.stl:stream','part.exe','part.bin','part.uf2','part.STL.exe','a\x00.stl','CON.stl','a/b.3mf','part.stl\n','\u212a.stl','a.'+'stl '*100):
            with self.subTest(name=name),self.assertRaises(Rejected):safe_name(name)
        self.assertEqual(safe_name('part.STL'),'part.stl')
    def test_nonfinite_bool_and_overflow(self):
        for wire in (b'{"x":NaN}',b'{"x":Infinity}',b'{"x":1e999}',b'{"x":1.5}'):
            with self.subTest(wire=wire),self.assertRaises(Rejected):parse(wire)
        for value in (True,1.0,-1,MAX_FILE+1):
            with self.assertRaises(Rejected):integer(value,1,MAX_FILE)
    def test_duplicate_and_depth(self):
        for wire in (b'{"v":1,"v":1}',b'{"v":1,"\\u0076":1}',b'{"x":'+b'['*10+b'0'+b']'*10+b'}'):
            with self.assertRaises(Rejected):parse(wire)
    def test_wire_bounds(self):
        with self.assertRaises(Rejected):parse(b'x'*(MAX_WIRE+1),MAX_WIRE)
        with self.assertRaises(Rejected):unb64(b64(b'x'*(CHUNK+1)),CHUNK)
        with self.assertRaises(Rejected):unb64('eA==\n',1)
    def test_crypto_mutation_and_direction(self):
        sid='11'*16;k=derive(KEY,'bootstrap');wire=seal({'v':1,'op':'list'},k,'phone-to-pc',sid,2)
        self.assertEqual(open_message(wire,k,'phone-to-pc',sid,2)['op'],'list')
        for key,direction,session,seq in [(bytes(32),'phone-to-pc',sid,2),(k,'pc-to-phone',sid,2),(k,'phone-to-pc','22'*16,2),(k,'phone-to-pc',sid,3)]:
            with self.assertRaises(Rejected):open_message(wire,key,direction,session,seq)
        env=parse(wire,MAX_WIRE);body=bytearray(unb64(env['body'],MAX_PLAIN+16));body[0]^=1;env['body']=b64(bytes(body))
        with self.assertRaises(Rejected):open_message(pack(env,MAX_WIRE),k,'phone-to-pc',sid,2)
    def test_cad_types_and_sizes(self):
        validate_cad(STL,'part.stl');validate_cad(b'PK\x03\x04opaque','part.3mf')
        for data,name in [(b'MZexe','part.stl'),(STL,'firmware.bin'),(b'PK','part.3mf'),(b'','part.stl'),(b'x'*(MAX_FILE+1),'part.stl')]:
            with self.assertRaises(Rejected):validate_cad(data,name)

class TestCore(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='unit-',dir=ROOT);self.storage=Storage(Path(self.temp.name)/'CAD',test=True);self.now=100.
        self.core=Core(KEY,self.storage,clock=lambda:self.now)
    def tearDown(self):self.storage.close();self.temp.cleanup()
    def hello(self):
        client=secrets.token_hex(32);wire=self.core.challenge(pack({'v':1,'client':client}));sid=parse(wire,MAX_WIRE)['sid']
        q=open_message(wire,derive(KEY,'bootstrap'),'challenge',sid,0);out,inside=session_keys(KEY,q['boot'],sid,q['challenge'],client)
        auth=seal({'v':1,'op':'authenticate','boot':q['boot'],'client':client,'challenge':q['challenge']},out,'phone-to-pc',sid,1)
        return sid,out,inside,auth
    def auth(self):
        sid,out,inside,auth=self.hello();self.core.authenticate(auth);return sid,out,inside
    def call(self,sid,key,op,seq=2,**args):return self.core.message(seal({'v':1,'op':op,**args},key,'phone-to-pc',sid,seq))
    def test_challenge_single_use(self):
        _,_,_,wire=self.hello();self.core.authenticate(wire)
        with self.assertRaises(Rejected):self.core.authenticate(wire)
    def test_bad_auth_consumes_challenge(self):
        sid,out,inside,auth=self.hello();env=parse(auth,MAX_WIRE);env['body']=b64(b'0'*32)
        with self.assertRaises(Rejected):self.core.authenticate(pack(env,MAX_WIRE))
        with self.assertRaises(Rejected):self.core.authenticate(auth)
    def test_challenge_expiry(self):
        *_,auth=self.hello();self.now+=CHALLENGE_SECONDS
        with self.assertRaises(Rejected):self.core.authenticate(auth)
    def test_session_deadline(self):
        sid,key,_=self.auth();self.now+=SESSION_SECONDS
        with self.assertRaises(Rejected):self.call(sid,key,'list')
        self.assertFalse(self.core.sessions)
    def test_restart_rejects_old_session(self):
        sid,key,_=self.auth();old=seal({'v':1,'op':'list'},key,'phone-to-pc',sid,2);self.core=Core(KEY,self.storage)
        with self.assertRaises(Rejected):self.core.message(old)
    def test_replay_ends_session(self):
        sid,key,_=self.auth();wire=seal({'v':1,'op':'list'},key,'phone-to-pc',sid,2);self.core.message(wire)
        with self.assertRaises(Rejected):self.core.message(wire)
        self.assertNotIn(sid,self.core.sessions)
    def test_sequence_gap_ends_session(self):
        sid,key,_=self.auth()
        with self.assertRaises(Rejected):self.call(sid,key,'list',seq=3)
        self.assertNotIn(sid,self.core.sessions)
    def test_unknown_operation(self):
        for op in ('firmware','install','execute','gps','rc','bluetooth','print','delete','get-file'):
            sid,key,_=self.auth()
            with self.subTest(op=op),self.assertRaises(Rejected):self.call(sid,key,op)
    def test_unexpected_path_field(self):
        sid,key,_=self.auth()
        with self.assertRaises(Rejected):self.call(sid,key,'list',path='C:/')
    def test_challenge_and_session_limit(self):
        for _ in range(MAX_CHALLENGES):self.hello()
        with self.assertRaises(Rejected):self.hello()
        self.now+=CHALLENGE_SECONDS;self.core.expire()
        old,oldkey,_=self.auth();new,newkey,_=self.auth()
        self.assertEqual(len(self.core.sessions),MAX_SESSIONS)
        with self.assertRaises(Rejected):self.call(old,oldkey,'list')
        self.call(new,newkey,'list')
    def test_upload_hash_and_incomplete(self):
        for which in ('hash','offset','short','commit'):
            sid,key,inside=self.auth()
            q=open_message(self.call(sid,key,'begin-upload',name='part.stl',bytes=len(STL),sha256=hashlib.sha256(STL).hexdigest()),inside,'pc-to-phone',sid,2)
            with self.subTest(which=which),self.assertRaises(Rejected):
                if which=='commit':self.call(sid,key,'commit',seq=3,transfer=q['transfer'])
                else:self.call(sid,key,'upload-chunk',seq=3,transfer=q['transfer'],offset=1 if which=='offset' else 0,data=b64(STL[:-1] if which=='short' else STL),sha256='00'*32 if which=='hash' else hashlib.sha256(STL).hexdigest())
            self.assertEqual(self.storage.scan()[1],[])
    def test_abort_releases_reservation(self):
        sid,key,_=self.auth();self.call(sid,key,'begin-upload',name='part.stl',bytes=MAX_FILE,sha256='00'*32)
        self.assertEqual(self.core.reserved(),MAX_FILE);self.call(sid,key,'abort',seq=3);self.assertEqual(self.core.reserved(),0)
    def test_whole_file_hash_failure(self):
        sid,key,inside=self.auth();q=open_message(self.call(sid,key,'begin-upload',name='part.stl',bytes=len(STL),sha256='00'*32),inside,'pc-to-phone',sid,2)
        self.call(sid,key,'upload-chunk',seq=3,transfer=q['transfer'],offset=0,data=b64(STL),sha256=hashlib.sha256(STL).hexdigest())
        with self.assertRaises(Rejected):self.call(sid,key,'commit',seq=4,transfer=q['transfer'])
        self.assertEqual(self.storage.scan()[1],[])
    def test_session_expiry_releases_reservation(self):
        sid,key,_=self.auth();self.call(sid,key,'begin-upload',name='part.stl',bytes=MAX_FILE,sha256='00'*32);self.now+=SESSION_SECONDS;self.core.expire();self.assertEqual(self.core.reserved(),0)
    def test_quota_includes_reservations(self):
        sid,key,_=self.auth()
        with patch.object(self.storage,'scan',return_value=(MAX_TOTAL-MAX_FILE//2,[])):
            with self.assertRaises(Rejected):self.call(sid,key,'begin-upload',name='part.stl',bytes=MAX_FILE,sha256='00'*32)
    def test_invalid_id_and_negative_bytes(self):
        for op,args in [('begin-download',{'id':'../part.stl'}),('begin-upload',{'name':'part.stl','bytes':-1,'sha256':'00'*32}),('begin-upload',{'name':'part.stl','bytes':True,'sha256':'00'*32}),('begin-upload',{'name':'part.exe','bytes':1,'sha256':'00'*32})]:
            sid,key,_=self.auth()
            with self.assertRaises(Rejected):self.call(sid,key,op,**args)
    def test_hardlink_rejected(self):
        src=Path(self.temp.name)/'outside.stl';src.write_bytes(STL);os.link(src,self.storage.root/'hardlink.stl')
        with self.assertRaises(Rejected):self.storage.scan()
    def test_symlink_rejected(self):
        src=Path(self.temp.name)/'outside.stl';src.write_bytes(STL)
        try:os.symlink(src,self.storage.root/'symlink.stl')
        except OSError as e:self.skipTest('Native symlink creation unavailable: '+str(e.winerror if hasattr(e,'winerror') else e.errno))
        with self.assertRaises(Rejected):self.storage.scan()
    def test_incomplete_or_mutated_file_not_listed(self):
        name=f"{'11'*16}_{'00'*32}_part.stl";(self.storage.root/name).write_bytes(STL)
        self.assertEqual(self.storage.scan()[1],[]);self.assertEqual(self.storage.scan()[0],len(STL))
    def test_read_detects_mutation(self):
        item=self.storage.save(STL,'part.stl',hashlib.sha256(STL).hexdigest());path=next(self.storage.root.iterdir());path.write_bytes(b'broken')
        with self.assertRaises(Rejected):self.storage.read(item['id'])

class TestLoopback(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='tcp-',dir=ROOT);self.server=CADServer();self.server.start_loopback_test(KEY,Path(self.temp.name)/'CAD');self.port=self.server.listener.server_port
    def tearDown(self):self.server.stop();self.temp.cleanup()
    def client(self,key=KEY):return CADClient(key,'127.0.0.1',self.port,loopback_test=True)
    def test_real_chunked_roundtrip_and_listing(self):
        c=self.client();c.connect();self.assertEqual(c.list(),[])
        data=b'solid large\n'+b' '* (CHUNK*2+37)+b'\nendsolid large\n'
        item=c.upload('large.STL',data);self.assertEqual(c.list(),[item]);found,received=c.download(item['id']);self.assertEqual(found,item);self.assertEqual(received,data)
        c.request('abort');c.close()
    def test_real_3mf_roundtrip(self):
        c=self.client();c.connect();data=b'PK\x03\x04'+secrets.token_bytes(4096);item=c.upload('part.3mf',data);self.assertEqual(c.download(item['id'])[1],data)
    def test_idle_expiry_releases_buffer_without_next_request(self):
        c=self.client();c.connect();c.request('begin-upload',name='part.stl',bytes=MAX_FILE,sha256='00'*32)
        self.server.listener.core.sessions[c.sid].deadline=time.monotonic()-.1
        time.sleep(.15)
        self.assertEqual(self.server.listener.core.reserved(),0);self.assertFalse(self.server.listener.core.sessions)
    def test_real_maximum_file_roundtrip(self):
        c=self.client();c.connect();data=b'solid maximum\n'+b' '*(MAX_FILE-len(b'solid maximum\n')-len(b'\nendsolid maximum\n'))+b'\nendsolid maximum\n'
        self.assertEqual(len(data),MAX_FILE);item=c.upload('maximum.stl',data);self.assertEqual(c.download(item['id'])[1],data)
    def test_real_wrong_key_and_replay(self):
        with self.assertRaises(Rejected):self.client(bytes(32)).connect()
        c=self.client();c.connect();wire=seal({'v':1,'op':'list'},c.send,'phone-to-pc',c.sid,2);c.post('/cad/v1/message',wire)
        with self.assertRaises(Rejected):c.post('/cad/v1/message',wire)
    def test_http_route_and_length_bounds(self):
        for path,body,headers in [('/firmware',b'{}',{}),('/cad/v1/challenge',b'x'*257,{}),('/cad/v1/message',b'{}',{'Content-Length':str(MAX_WIRE+1)}),('/cad/v1/challenge',b'{}',{'Transfer-Encoding':'chunked'})]:
            h=http.client.HTTPConnection('127.0.0.1',self.port,timeout=3)
            try:
                h.request('POST',path,body=body,headers={'Content-Type':'application/json',**headers});r=h.getresponse();self.assertEqual(r.status,400);r.read(512)
            finally:h.close()
    def drip_until_closed(self,initial,fragment):
        s=socket.create_connection(('127.0.0.1',self.port),timeout=1);s.settimeout(.08);started=time.monotonic()
        try:
            s.sendall(initial)
            while time.monotonic()-started<4.2:
                time.sleep(.04)
                try:s.sendall(fragment)
                except OSError:return time.monotonic()-started
                try:
                    data=s.recv(1)
                    if data==b'':return time.monotonic()-started
                except socket.timeout:pass
                except OSError:return time.monotonic()-started
            self.fail('Drip-fed accepted request remained open after absolute deadline')
        finally:s.close()
    def test_absolute_deadline_fragmented_headers(self):
        elapsed=self.drip_until_closed(b'POST /cad/v1/challenge HTTP/1.0\r\nX-Slow: ',b'a')
        self.assertGreater(elapsed,2.5);self.assertLess(elapsed,3.8)
    def test_absolute_deadline_fragmented_body(self):
        header=b'POST /cad/v1/challenge HTTP/1.0\r\nContent-Type: application/json\r\nContent-Length: 200\r\n\r\n'
        elapsed=self.drip_until_closed(header,b' ')
        self.assertGreater(elapsed,2.5);self.assertLess(elapsed,3.8)
    def test_stop_wakes_fragmented_body_read(self):
        s=socket.create_connection(('127.0.0.1',self.port),timeout=1);s.settimeout(1)
        try:
            s.sendall(b'POST /cad/v1/challenge HTTP/1.0\r\nContent-Type: application/json\r\nContent-Length: 200\r\n\r\n ')
            time.sleep(.08);started=time.monotonic();self.server.stop()
            self.assertLess(time.monotonic()-started,1);self.assertFalse(self.server.running)
            try:self.assertEqual(s.recv(1),b'')
            except OSError:pass
        finally:s.close()
    def test_stop_wakes_fragmented_header_read(self):
        s=socket.create_connection(('127.0.0.1',self.port),timeout=1);s.settimeout(1)
        try:
            s.sendall(b'POST /cad/v1/challenge HTTP/1.0\r\nX-Slow: ')
            time.sleep(.08);started=time.monotonic();self.server.stop()
            self.assertLess(time.monotonic()-started,1);self.assertFalse(self.server.running)
        finally:s.close()
    def test_concurrent_stop_is_idempotent_under_slow_read(self):
        s=socket.create_connection(('127.0.0.1',self.port),timeout=1);barrier=threading.Barrier(3);errors=[]
        def stop():
            barrier.wait()
            try:self.server.stop()
            except Exception as e:errors.append(str(e))
        try:
            s.sendall(b'POST /cad/v1/challenge HTTP/1.0\r\nX-Slow: ');time.sleep(.08)
            threads=[threading.Thread(target=stop) for _ in range(2)]
            for t in threads:t.start()
            start=time.monotonic();barrier.wait()
            for t in threads:t.join(timeout=1)
            self.assertTrue(all(not t.is_alive() for t in threads));self.assertFalse(errors);self.assertLess(time.monotonic()-start,1);self.assertFalse(self.server.running)
            self.server.stop()
        finally:s.close()
    def test_thread_start_failure_releases_listener_and_stop_is_safe(self):
        fresh=CADServer();owned=[];real_listener=server_module.Listener
        def create(*args,**kwargs):
            listener=real_listener(*args,**kwargs);owned.append(listener);return listener
        with patch.object(server_module,'Listener',side_effect=create),patch.object(threading.Thread,'start',side_effect=RuntimeError('Synthetic start failure')):
            with self.assertRaises(RuntimeError):fresh.start_loopback_test(KEY,Path(self.temp.name)/'failed-start')
        self.assertFalse(fresh.running);self.assertIsNone(fresh.thread);self.assertIsNone(fresh.storage);self.assertEqual(owned[0].socket.fileno(),-1)
        self.assertFalse(owned[0].core.storage._directory_handles)
        began=time.monotonic();fresh.stop();self.assertLess(time.monotonic()-began,.2)
        try:
            fresh.start_loopback_test(KEY,Path(self.temp.name)/'failed-start')
            c=CADClient(KEY,'127.0.0.1',fresh.listener.server_port,loopback_test=True);c.connect();self.assertEqual(c.list(),[])
        finally:fresh.stop()
    def test_old_deadline_does_not_close_new_socket(self):
        old=socket.create_connection(('127.0.0.1',self.port),timeout=1)
        old.sendall(b'POST /bad HTTP/1.0\r\nContent-Type: application/json\r\nContent-Length: 2\r\n\r\n{}')
        old.recv(4096);old.close();time.sleep(.2)
        fresh=socket.create_connection(('127.0.0.1',self.port),timeout=1);fresh.settimeout(1)
        try:
            fresh.sendall(b'POST /cad/v1/challenge HTTP/1.0\r\n')
            time.sleep(2.85)  # Past the old socket's deadline but before this one.
            body=pack({'v':1,'client':'55'*32})
            fresh.sendall(b'Content-Type: application/json\r\nContent-Length: '+str(len(body)).encode()+b'\r\n\r\n'+body)
            response=fresh.recv(4096);self.assertIn(b' 200 ',response)
        finally:fresh.close()
    def test_peer_pin_rejects(self):
        self.server.listener.allowed_phone='192.168.1.2'
        with self.assertRaises((OSError,Rejected)):self.client().connect()
    def test_stop_clears_listener_and_sessions(self):
        c=self.client();c.connect();self.server.stop();self.assertFalse(self.server.running)
        with self.assertRaises((OSError,Rejected)):c.list()
    def test_public_start_refuses_loopback_and_wildcard(self):
        s=CADServer();self.assertFalse(s.running)
        for bind in ('127.0.0.1','0.0.0.0','8.8.8.8'):
            with self.assertRaises(Rejected):s.start(KEY,bind,'192.168.1.2')

if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromModule(__import__(__name__))
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    report={'tests_run':result.testsRun,'failures':[t.id() for t,_ in result.failures],'errors':[t.id() for t,_ in result.errors],'skipped':[{'test':t.id(),'reason':why} for t,why in result.skipped],'success':result.wasSuccessful(),'scope':'Windows loopback and isolated temporary storage; public synthetic key; no production service or actual pairing key'}
    (ROOT/'test-results.json').write_text(json.dumps(report,indent=2)+'\n')
    raise SystemExit(0 if result.wasSuccessful() else 1)
