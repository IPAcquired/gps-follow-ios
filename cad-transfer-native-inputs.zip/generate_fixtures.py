"""Public synthetic vectors only; reads no device key or configuration."""
import json
from pathlib import Path
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from protocol import *

root=Path(__file__).resolve().parent
key=bytes(range(32));boot='11'*32;sid='33'*16;challenge='44'*32;client='22'*32
send,receive=session_keys(key,boot,sid,challenge,client)
payload={'v':1,'op':'list','ok':True,'items':[]};nonce=bytes(range(12))
wire=pack({'v':1,'sid':sid,'seq':2,'nonce':b64(nonce),'body':b64(AESGCM(receive).encrypt(nonce,pack(payload),aad('pc-to-phone',sid,2)))},MAX_WIRE)
out={'synthetic_public_fixture':True,'pairing_key_hex':key.hex(),'boot':boot,'sid':sid,'challenge':challenge,'client':client,'bootstrap_key_hex':derive(key,'bootstrap').hex(),'phone_to_pc_key_hex':send.hex(),'pc_to_phone_key_hex':receive.hex(),'response_wire_base64':b64(wire),'response_payload':payload}
for target in (root/'cad-fixtures.json',root/'SwiftTests/cad-fixtures.json'):
    target.parent.mkdir(exist_ok=True);target.write_text(json.dumps(out,indent=2)+'\n')
print('Generated public CAD interop vectors')
