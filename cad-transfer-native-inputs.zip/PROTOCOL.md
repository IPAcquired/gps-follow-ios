# Personal CAD transfer candidate, version 1

This is an isolated proposal for the owner’s paired phone and PC. It is not integrated, installed, approved, or started in a production app. Import and construction are inert. The host UI must offer an explicit Start/Stop control; production Start requires one numeric RFC1918 PC address and the selected phone’s numeric RFC1918 address. It binds only the specified PC address, pins accepted TCP peers to the selected phone address, and performs no discovery, public binding, DNS lookup, UPnP, firewall changes, or background startup. The default port is 8766 and is separate from GPS relay UDP.

The existing pairing secret is supplied as exactly 32 bytes by the host. The module does not load profiles, read a live secret store, save a new key, print the key, or use aircraft MAVLink signing keys. The public test key is the byte sequence 00 through 1f and is unsuitable for deployment.

## Cryptography and freshness

HKDF-SHA256 yields 32-byte AES-256-GCM keys. Domain prefix is the exact UTF-8 bytes `GPSFollow/CADTransfer/v1/`. Bootstrap salt equals those domain bytes; HKDF info is the domain followed by `bootstrap`. Session salt is the raw concatenation of the 32-byte server boot nonce, 16-byte session ID, 32-byte challenge, and 32-byte client nonce. Separate info values end in `phone-to-pc` and `pc-to-phone`. CAD keys therefore differ from the original pairing key and from each other.

Each AES-GCM message uses a generated random 12-byte nonce and a 16-byte tag. Envelope JSON has exactly `v`, `sid`, `seq`, `nonce`, and `body`. `v` is integer 1; `sid` is 32 lowercase hexadecimal characters; `seq` is an integer. Nonce and body use canonical padded base64; body is ciphertext followed by tag. AAD is the domain followed by `<direction>/<sid>/<decimal seq>`, with direction `challenge`, `phone-to-pc`, or `pc-to-phone`.

1. Phone POSTs `{ "v":1, "client":"<fresh 64 lowercase hex>" }` to `/cad/v1/challenge`. This one request is plaintext and contains no filename, key, CAD contents, GPS, or other private data.
2. PC creates a fresh random session ID and challenge and encrypts its response under the bootstrap key, direction `challenge`, sequence 0. Payload fields are exactly `v, op, boot, client, challenge, ttl_ms`, with op `challenge` and TTL 10000. The echoed client nonce prevents accepting a replayed bootstrap response. The boot nonce changes every explicit server Start.
3. Phone derives the two session keys and POSTs an encrypted authentication payload to `/cad/v1/auth`, direction `phone-to-pc`, sequence 1. Fields are `v, op, boot, client, challenge`, op `authenticate`. PC consumes the challenge on the first authentication attempt, including a bad attempt. The challenge is valid for less than ten server monotonic seconds. A maximum of four pending challenges is retained.
4. PC returns an encrypted `v, op, ok, ttl_ms` response, op `authenticated`, ok boolean true, TTL 180000, direction `pc-to-phone`, sequence 1. Successful fresh authentication replaces the selected phone’s previous session and releases its uncommitted transfer. This permits a fresh Start after cancellation without waiting three minutes.
5. Messages go to `/cad/v1/message`, with sequence exactly 2, 3, 4, and so on. Requests and responses use the same sequence but separate direction keys. A stale/reordered/replayed/wrong-key/invalid request closes the referenced session. Sessions have an absolute 180-second monotonic deadline and at most 1024 requests. Deadlines do not slide on activity. A newly started PC has no previous sessions or challenges.

One active session and one temporary upload or download exist for the selected phone. Stop closes the listener, clears sessions/challenges, and releases in-memory transfers. There is no resume of a partial file. On phone cancellation, the current network request is cancelled and local session state is cleared; no additional command is sent. The PC releases that uncommitted memory on expiration, next successful Start, or PC Stop. If a commit completed but its acknowledgement was lost, the immutable completed copy remains; the next List reveals it.

## Bounded HTTP and payloads

Requests are POST only on the three routes above. Production endpoint addresses are numeric RFC1918 IPv4; wildcard, public, DNS, multicast, IPv6, and loopback addresses are rejected. Dedicated named loopback test entry points accept only 127.0.0.1 and isolated test storage; they must never be exposed by the app UI.

Each request has one valid decimal Content-Length, Content-Type `application/json`, and no Transfer-Encoding or Expect. Request bodies are at most 512 KiB, decrypted JSON at most 384 KiB, bootstrap requests at most 256 bytes, nesting at most eight containers. Duplicate keys, noncanonical base64, noninteger/nonfinite JSON numbers, bool-as-integer metadata, and unexpected fields are rejected. The listener processes one connection at a time, with a backlog of four. Every accepted socket has an absolute three-second watchdog covering headers, body, and response; received fragments cannot renew it. Expiry shuts down that exact still-owned socket. Normal cleanup cancels its timer, and stale timers cannot close a newer request. Stop closes active sockets before waiting for the listener loop, so it wakes a blocked header/body read immediately. A per-read socket timeout is also applied as a fallback. Python’s standard HTTP parser applies its finite request-line/header limits. The reference client uses a three-second socket timeout. Swift has a three-second request timeout, five-second resource timeout, bounded streaming response accumulation, no redirects, no cookies/cache/proxies, and no cellular/expensive/constrained network access. HTTPS is not required because all CAD payloads and private metadata use authenticated encryption; IP addresses, byte counts, timing, and the public bootstrap client nonce remain visible on the local network.

## CAD operations

Every encrypted request includes integer `v:1` and an `op`. Successful responses repeat v/op and include boolean `ok:true`. The table lists the additional exact fields; unknown commands and extra fields fail closed.

| Operation | Additional request fields | Additional response fields |
|---|---|---|
| list | none | items |
| begin-upload | name, bytes, sha256 | transfer, chunk_bytes |
| upload-chunk | transfer, offset, data, sha256 | received |
| commit | transfer | item |
| abort | none | none |
| begin-download | id | transfer, item, chunk_bytes |
| download-chunk | transfer, offset | offset, data, sha256, done |

An item is exactly `id, name, bytes, sha256`. IDs and transfer tokens are server-generated 16-byte values encoded as lowercase hex. Hashes are 64 lowercase hex characters, SHA-256 of the raw bytes. The original basename contains only 1–80 ASCII letters/digits/underscore/hyphen plus `.stl` or `.3mf`; extension is normalized to lowercase. Reserved Windows device names, separators, traversal, alternate streams, absolute paths, control characters and arbitrary extensions are rejected.

Files are 1–20 MiB. Completed files plus reserved uploads cannot exceed 128 MiB; at most 128 root entries exist, including unrecognized or interrupted files. Chunks are exactly 256 KiB except the final chunk. Offsets must equal the next expected byte position. Every chunk is hash checked, and commit/download additionally verify whole-file size and hash. Uploads are held in bounded memory until commit; no disk temp sessions exist. Download uses a bounded snapshot, preventing later mutation from changing the bytes mid-transfer. Basic binary/ASCII STL or ZIP/3MF headers are checked. This is a transfer-format check, not a geometry repair or deep 3MF validation. Archives are never extracted or executed.

## PC storage and local trust boundary

Production storage is exactly `%LOCALAPPDATA%/GPSFollow/CAD Transfer`. Network clients cannot supply a directory or pathname. Completed filenames are generated as `<id>_<sha256>_<safe basename>`. Files are immutable: there is no network overwrite, rename, delete, executable installation, or arbitrary-file API. New writes use CREATE_NEW. Invalid/interrupted files still count against quota and are not listed unless contents match the hash in the generated filename.

Every checked ancestor is a directory without a symlink/reparse point. Windows ancestor handles omit FILE_SHARE_DELETE while the listener owns storage, preventing ancestor replacement/rename. File opens use FILE_FLAG_OPEN_REPARSE_POINT, verify final handle path, file attributes and single-link count, and omit file write/delete sharing. Files that are symlinks, junction/reparse objects, hard links, nonregular objects or unexpected alternate paths are rejected. List/download recheck hashes. Native Windows tests exercise actual symlinks and hard links. The local Windows account and its trusted processes remain a trust boundary: this does not protect against an administrator or a process already able to steal the existing pairing key or modify the app. Python cannot guarantee erasure of all past immutable key copies from process memory.

No firmware/EXE update, automatic installation, GPS, flight command, RC, Bluetooth, serial port, or printer operation is implemented. A ZIP signature alone does not prove that an opaque 3MF archive contains only CAD members; the receiver never extracts or executes it.
