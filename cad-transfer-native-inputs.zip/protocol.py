"""Isolated CAD-only protocol. Import does not read keys, files, or open sockets."""
from __future__ import annotations
import base64
import ipaddress
import json
import re
import secrets
from typing import Any
from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

VERSION = 1
MAX_FILE = 20 * 1024 * 1024
MAX_TOTAL = 128 * 1024 * 1024
CHUNK = 256 * 1024
MAX_PLAIN = 384 * 1024
MAX_WIRE = 512 * 1024
MAX_FILES = 128
MAX_SESSIONS = 1
MAX_CHALLENGES = 4
CHALLENGE_SECONDS = 10
SESSION_SECONDS = 180
MAX_REQUESTS = 1024
DOMAIN = b'GPSFollow/CADTransfer/v1/'
PRIVATE = tuple(ipaddress.ip_network(n) for n in ('10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16'))

class Rejected(ValueError):
    pass

def address(value: str, *, test=False) -> str:
    try:
        a = ipaddress.IPv4Address(value)
    except (ValueError, TypeError) as e:
        raise Rejected('Numeric private IPv4 required') from e
    if test and str(a) == '127.0.0.1':
        return str(a)
    if not any(a in n for n in PRIVATE) or int(a) & 255 in (0, 255):
        raise Rejected('Numeric private unicast IPv4 required')
    return str(a)

def integer(value: Any, low: int, high: int) -> int:
    if type(value) is not int or not low <= value <= high:
        raise Rejected('Invalid integer')
    return value

def token(value: Any, size=16) -> str:
    if not isinstance(value, str) or re.fullmatch('[0-9a-f]{' + str(size*2) + '}', value) is None:
        raise Rejected('Invalid token')
    return value

def safe_name(value: Any) -> str:
    if not isinstance(value, str) or re.fullmatch(r'[A-Za-z0-9_-]{1,80}\.(?:stl|3mf)', value, re.I | re.ASCII) is None:
        raise Rejected('Only a simple STL or 3MF basename is allowed')
    stem, ext = value.rsplit('.', 1)
    if re.fullmatch(r'(?:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])', stem, re.I):
        raise Rejected('Reserved filename')
    return stem + '.' + ext.lower()

def fields(value: Any, expected: set[str]) -> dict:
    if not isinstance(value, dict) or set(value) != expected:
        raise Rejected('Unexpected fields')
    return value

def b64(data: bytes) -> str:
    return base64.b64encode(data).decode('ascii')

def unb64(value: Any, limit: int) -> bytes:
    if not isinstance(value, str) or len(value) > ((limit + 2)//3)*4:
        raise Rejected('Invalid encoding size')
    try:
        data = base64.b64decode(value, validate=True)
    except (ValueError, TypeError) as e:
        raise Rejected('Invalid encoding') from e
    if len(data) > limit or b64(data) != value:
        raise Rejected('Noncanonical encoding')
    return data

def _unique(pairs):
    out = {}
    for k,v in pairs:
        if k in out:
            raise Rejected('Duplicate field')
        out[k] = v
    return out

def parse(data: bytes, limit=MAX_PLAIN) -> dict:
    if type(data) is not bytes or not data or len(data) > limit:
        raise Rejected('Invalid message size')
    depth = 0; quoted = escaped = False
    for c in data:
        if quoted:
            if escaped: escaped = False
            elif c == 92: escaped = True
            elif c == 34: quoted = False
        elif c == 34: quoted = True
        elif c in (91,123):
            depth += 1
            if depth > 8: raise Rejected('Excessive nesting')
        elif c in (93,125):
            depth -= 1
            if depth < 0: raise Rejected('Malformed JSON')
    try:
        value = json.loads(data, object_pairs_hook=_unique, parse_float=lambda _: (_ for _ in ()).throw(Rejected('Only integer numbers allowed')), parse_constant=lambda _: (_ for _ in ()).throw(Rejected('Nonfinite value')))
    except (ValueError, RecursionError, UnicodeDecodeError) as e:
        raise Rejected('Malformed JSON') from e
    if not isinstance(value, dict): raise Rejected('Object required')
    return value

def pack(value: dict, limit=MAX_PLAIN) -> bytes:
    try: out = json.dumps(value, separators=(',', ':'), sort_keys=True, allow_nan=False).encode('utf-8')
    except (ValueError, TypeError, OverflowError) as e: raise Rejected('Invalid JSON value') from e
    parse(out, limit)
    return out

def derive(pairing_key: bytes, purpose: str, salt: bytes = DOMAIN) -> bytes:
    if type(pairing_key) is not bytes or len(pairing_key) != 32 or purpose not in ('bootstrap', 'phone-to-pc', 'pc-to-phone'):
        raise Rejected('A supplied 32-byte pairing key is required')
    return HKDF(algorithm=hashes.SHA256(), length=32, salt=salt, info=DOMAIN + purpose.encode('ascii')).derive(pairing_key)

def session_keys(pairing_key: bytes, boot: str, sid: str, challenge: str, client: str):
    salt = bytes.fromhex(token(boot,32) + token(sid) + token(challenge,32) + token(client,32))
    return derive(pairing_key,'phone-to-pc',salt), derive(pairing_key,'pc-to-phone',salt)

def aad(direction: str, sid: str, seq: int) -> bytes:
    if direction not in ('challenge','phone-to-pc','pc-to-phone'): raise Rejected('Invalid direction')
    return DOMAIN + direction.encode() + b'/' + token(sid).encode() + b'/' + str(integer(seq,0,MAX_REQUESTS)).encode()

def seal(payload: dict, key: bytes, direction: str, sid: str, seq: int) -> bytes:
    nonce = secrets.token_bytes(12)
    if len(nonce) != 12 or len(key) != 32: raise Rejected('Invalid crypto size')
    encrypted = AESGCM(key).encrypt(nonce, pack(payload), aad(direction,sid,seq))
    return pack({'v':1,'sid':sid,'seq':seq,'nonce':b64(nonce),'body':b64(encrypted)}, MAX_WIRE)

def open_message(wire: bytes, key: bytes, direction: str, sid: str, seq: int) -> dict:
    env = fields(parse(wire, MAX_WIRE), {'v','sid','seq','nonce','body'})
    if type(env['v']) is not int or env['v'] != 1 or env['sid'] != sid or type(env['seq']) is not int or env['seq'] != seq:
        raise Rejected('Wrong session or sequence')
    nonce = unb64(env['nonce'],12); body = unb64(env['body'],MAX_PLAIN+16)
    if len(nonce) != 12 or len(body) < 17: raise Rejected('Invalid envelope')
    try: return parse(AESGCM(key).decrypt(nonce,body,aad(direction,sid,seq)))
    except InvalidTag as e: raise Rejected('Authentication failed') from e

def validate_cad(data: bytes, name: str):
    safe_name(name)
    if not 1 <= len(data) <= MAX_FILE: raise Rejected('Invalid CAD size')
    if name.lower().endswith('.3mf'):
        if not data.startswith(b'PK\x03\x04'): raise Rejected('Invalid 3MF header')
        return  # Opaque archive: never extracted or executed.
    if len(data) >= 84:
        triangles = int.from_bytes(data[80:84], 'little')
        if triangles and 84 + 50 * triangles == len(data): return
    if not data[:1024].lstrip().startswith(b'solid') or b'endsolid' not in data[-1024:]:
        raise Rejected('Invalid STL header')
