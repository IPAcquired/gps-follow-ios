"""Bounded immutable CAD storage; no caller-supplied production directory."""
from __future__ import annotations
import ctypes
import hashlib
import os
from pathlib import Path
import re
import secrets
import stat
if __package__:
    from .protocol import MAX_FILE, MAX_TOTAL, MAX_FILES, Rejected, safe_name, validate_cad
else:
    from protocol import MAX_FILE, MAX_TOTAL, MAX_FILES, Rejected, safe_name, validate_cad

OBJECT = re.compile(r'([0-9a-f]{32})_([0-9a-f]{64})_([A-Za-z0-9_-]{1,80}\.(?:stl|3mf))\Z')

def _reject_link(path: Path, directory=False):
    st = path.lstat()
    if stat.S_ISLNK(st.st_mode) or getattr(st, 'st_file_attributes', 0) & 0x400:
        raise Rejected('Links and reparse points are forbidden')
    if directory and not stat.S_ISDIR(st.st_mode): raise Rejected('Directory required')
    if not directory and (not stat.S_ISREG(st.st_mode) or st.st_nlink != 1): raise Rejected('Plain single-link file required')
    return st

class Storage:
    def __init__(self, root: Path, *, test=False):
        if not test:
            if os.name != 'nt': raise Rejected('Production storage requires Windows')
            base = Path(os.environ.get('LOCALAPPDATA', ''))
            if not base.is_absolute() or str(base).startswith('\\\\'): raise Rejected('Local AppData required')
            if root != base / 'GPSFollow' / 'CAD Transfer': raise Rejected('Fixed AppData CAD root required')
        self.root = root.absolute(); self._directory_handles = []
        # Keep directory handles without FILE_SHARE_DELETE on Windows so checked
        # ancestors cannot be swapped/renamed while the server owns the root.
        chain = list(reversed(self.root.parents)) + [self.root]
        try:
            for p in chain:
                if not p.exists(): p.mkdir()
                _reject_link(p, True)
                if os.name == 'nt': self._directory_handles.append(self._windows_handle(p, True))
        except Exception:
            self.close();raise

    @staticmethod
    def production():
        base = Path(os.environ.get('LOCALAPPDATA', ''))
        return Storage(base / 'GPSFollow' / 'CAD Transfer')

    def close(self):
        if os.name == 'nt':
            for h in reversed(self._directory_handles): ctypes.windll.kernel32.CloseHandle(ctypes.c_void_p(h))
        self._directory_handles.clear()

    def _windows_handle(self, path: Path, directory=False, create=False):
        import ctypes.wintypes as w
        k = ctypes.WinDLL('kernel32', use_last_error=True)
        k.CreateFileW.argtypes = [w.LPCWSTR,w.DWORD,w.DWORD,ctypes.c_void_p,w.DWORD,w.DWORD,w.HANDLE]
        k.CreateFileW.restype = w.HANDLE
        access = 0x80 if directory else (0x40000000 if create else 0x80000000)
        flags = 0x200000 | (0x2000000 if directory else 0)
        h = k.CreateFileW(str(path),access,3 if directory else 1,None,1 if create else 3,flags,None)
        if h == ctypes.c_void_p(-1).value: raise Rejected('Cannot safely open CAD storage')
        class Info(ctypes.Structure):
            _fields_=[('attributes',w.DWORD),('creation',w.FILETIME),('access',w.FILETIME),('write',w.FILETIME),('volume',w.DWORD),('high',w.DWORD),('low',w.DWORD),('links',w.DWORD),('indexHigh',w.DWORD),('indexLow',w.DWORD)]
        info=Info(); k.GetFileInformationByHandle.argtypes=[w.HANDLE,ctypes.POINTER(Info)]; k.GetFileInformationByHandle.restype=w.BOOL
        k.GetFinalPathNameByHandleW.argtypes=[w.HANDLE,w.LPWSTR,w.DWORD,w.DWORD]; k.GetFinalPathNameByHandleW.restype=w.DWORD
        buf=ctypes.create_unicode_buffer(32768)
        n=k.GetFinalPathNameByHandleW(h,buf,len(buf),0)
        final=buf.value
        if final.startswith('\\\\?\\'): final=final[4:]
        expected=os.path.normcase(os.path.normpath(str(path.absolute())))
        good=k.GetFileInformationByHandle(h,ctypes.byref(info)) and 0<n<len(buf) and os.path.normcase(os.path.normpath(final))==expected and not info.attributes & 0x400
        if directory: good=good and bool(info.attributes & 0x10)
        else: good=good and not info.attributes & 0x10 and info.links==1
        if not good:
            k.CloseHandle.argtypes=[w.HANDLE]; k.CloseHandle(h)
            raise Rejected('Link, alternate path or nonregular object')
        return h

    def _file(self, path: Path, create=False):
        if path.parent != self.root: raise Rejected('Outside CAD root')
        if os.name == 'nt':
            import msvcrt
            h=self._windows_handle(path,create=create)
            fd=msvcrt.open_osfhandle(h,os.O_BINARY | (os.O_WRONLY if create else os.O_RDONLY))
            return os.fdopen(fd,'wb' if create else 'rb')
        # Tests on POSIX also reject hard links and final symlinks; production is Windows.
        fd=os.open(path, (os.O_WRONLY|os.O_CREAT|os.O_EXCL if create else os.O_RDONLY) | getattr(os,'O_NOFOLLOW',0),0o600)
        st=os.fstat(fd)
        if not stat.S_ISREG(st.st_mode) or st.st_nlink != 1:
            os.close(fd); raise Rejected('Plain file required')
        return os.fdopen(fd,'wb' if create else 'rb')

    def scan(self):
        _reject_link(self.root,True)
        entries=list(self.root.iterdir())
        if len(entries)>MAX_FILES: raise Rejected('CAD object count limit')
        total=0; items=[]
        for p in entries:
            st=_reject_link(p); total+=st.st_size
            if total>MAX_TOTAL: raise Rejected('CAD storage quota')
            match=OBJECT.fullmatch(p.name)
            if match and 1<=st.st_size<=MAX_FILE:
                oid,digest,name=match.groups()
                # Only a matching content hash is published, so interrupted writes
                # cannot expose a partial file after restart. Invalid files still count.
                with self._file(p) as f:
                    data=f.read(MAX_FILE+1)
                if len(data)==st.st_size and hashlib.sha256(data).hexdigest()==digest:
                    validate_cad(data,name)
                    items.append({'id':oid,'sha256':digest,'name':name,'bytes':len(data)})
        return total,items

    def save(self, data: bytes, name: str, digest: str):
        name=safe_name(name);validate_cad(data,name)
        if hashlib.sha256(data).hexdigest()!=digest: raise Rejected('Whole-file hash mismatch')
        total,items=self.scan()
        if total+len(data)>MAX_TOTAL or len(list(self.root.iterdir()))>=MAX_FILES: raise Rejected('CAD storage quota')
        oid=secrets.token_hex(16);p=self.root/f'{oid}_{digest}_{name}'
        with self._file(p,True) as f:
            f.write(data);f.flush();os.fsync(f.fileno())
        return {'id':oid,'sha256':digest,'name':name,'bytes':len(data)}

    def read(self, oid: str):
        _,items=self.scan()
        item=next((i for i in items if i['id']==oid),None)
        if item is None: raise Rejected('Unknown CAD object')
        p=self.root/f"{oid}_{item['sha256']}_{item['name']}"
        with self._file(p) as f: data=f.read(MAX_FILE+1)
        if len(data)!=item['bytes'] or hashlib.sha256(data).hexdigest()!=item['sha256']: raise Rejected('CAD object changed')
        return item,data
