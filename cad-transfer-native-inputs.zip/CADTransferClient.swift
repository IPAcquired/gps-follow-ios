import Foundation
import CryptoKit
import CoreFoundation

public enum CADTransferError: LocalizedError, Equatable {
    case invalidSetup, offOrUnreachable, notStarted, busy, expired, rejected, invalidFile, tooLarge, integrity, cancelled
    public var errorDescription: String? {
        switch self {
        case .invalidSetup: return "Choose your paired PC’s private Wi-Fi address and CAD transfer port."
        case .offOrUnreachable: return "PC CAD transfer is off or unreachable. Start it on the PC and connect both devices to the same private Wi-Fi."
        case .notStarted: return "Tap Start to open a fresh CAD transfer session."
        case .busy: return "Wait for the current transfer or tap Cancel."
        case .expired: return "This CAD session expired. Tap Start again; the incomplete transfer was not added to the PC library."
        case .rejected: return "The PC rejected this transfer. Check the matching private pairing key, file size, and available CAD library space, then tap Start again."
        case .invalidFile: return "Choose an STL or 3MF with a simple filename. Only CAD files can be transferred."
        case .tooLarge: return "CAD transfer accepts files up to 20 MiB."
        case .integrity: return "The transferred file did not pass its integrity check. It was not accepted."
        case .cancelled: return "Transfer cancelled. A committed copy on the PC is kept; incomplete transfers expire."
        }
    }
}

public struct CADRemoteItem: Sendable, Equatable {
    public let id: String
    public let name: String
    public let bytes: Int
    public let sha256: String
}

enum CADTransferWire {
    static let domain = Data("GPSFollow/CADTransfer/v1/".utf8)
    static let maxFile = 20 * 1024 * 1024
    static let maxWire = 512 * 1024
    static let maxPlain = 384 * 1024
    static let chunk = 256 * 1024
    static func integer(_ value: Any?, _ lo: Int, _ hi: Int) throws -> Int {
        guard let n = value as? NSNumber, CFGetTypeID(n) != CFBooleanGetTypeID(),
              n.doubleValue.isFinite, n.doubleValue == Double(n.int64Value),
              n.int64Value >= Int64(lo), n.int64Value <= Int64(hi) else { throw CADTransferError.rejected }
        return Int(n.int64Value)
    }
    static func boolean(_ value: Any?) throws -> Bool {
        guard let n = value as? NSNumber, CFGetTypeID(n) == CFBooleanGetTypeID() else { throw CADTransferError.rejected }
        return n.boolValue
    }
    static func fields(_ value: [String: Any], _ names: Set<String>) throws {
        guard Set(value.keys) == names else { throw CADTransferError.rejected }
    }
    static func token(_ value: Any?, bytes: Int = 16) throws -> String {
        guard let s = value as? String, s.utf8.count == bytes * 2,
              s.utf8.allSatisfy({ (48...57).contains($0) || (97...102).contains($0) }) else { throw CADTransferError.rejected }
        return s
    }
    static func hex(_ value: String) throws -> Data {
        guard value.count % 2 == 0 else { throw CADTransferError.rejected }
        var out = Data(); var i = value.startIndex
        while i < value.endIndex {
            let e = value.index(i, offsetBy: 2)
            guard let b = UInt8(value[i..<e], radix: 16) else { throw CADTransferError.rejected }
            out.append(b); i = e
        }
        return out
    }
    static func random(_ count: Int) -> String {
        SymmetricKey(size: .bits256).withUnsafeBytes { raw in
            raw.prefix(count).map { String(format: "%02x", $0) }.joined()
        }
    }
    static func derive(_ key: Data, purpose: String, salt: Data? = nil) throws -> SymmetricKey {
        guard key.count == 32, ["bootstrap", "phone-to-pc", "pc-to-phone"].contains(purpose) else { throw CADTransferError.invalidSetup }
        return HKDF<SHA256>.deriveKey(inputKeyMaterial: SymmetricKey(data: key), salt: salt ?? domain,
                                     info: domain + Data(purpose.utf8), outputByteCount: 32)
    }
    static func keys(_ key: Data, boot: String, sid: String, challenge: String, client: String) throws -> (SymmetricKey, SymmetricKey) {
        let salt = try hex(token(boot, bytes: 32) + token(sid) + token(challenge, bytes: 32) + token(client, bytes: 32))
        return (try derive(key, purpose: "phone-to-pc", salt: salt), try derive(key, purpose: "pc-to-phone", salt: salt))
    }
    static func aad(_ direction: String, _ sid: String, _ seq: Int) throws -> Data {
        guard ["challenge", "phone-to-pc", "pc-to-phone"].contains(direction), (0...1024).contains(seq) else { throw CADTransferError.rejected }
        return domain + Data("\(direction)/\(try token(sid))/\(seq)".utf8)
    }
    static func b64(_ value: Any?, limit: Int) throws -> Data {
        guard let s = value as? String, s.utf8.count <= ((limit + 2) / 3) * 4,
              let d = Data(base64Encoded: s), d.count <= limit, d.base64EncodedString() == s else { throw CADTransferError.rejected }
        return d
    }
    static func pack(_ value: [String: Any], limit: Int = maxPlain) throws -> Data {
        guard JSONSerialization.isValidJSONObject(value) else { throw CADTransferError.rejected }
        let data = try JSONSerialization.data(withJSONObject: value, options: [.sortedKeys])
        _ = try parse(data, limit: limit)
        return data
    }
    static func parse(_ data: Data, limit: Int = maxPlain) throws -> [String: Any] {
        guard !data.isEmpty, data.count <= limit else { throw CADTransferError.rejected }
        var scan = StrictJSON(bytes: Array(data)); try scan.scan()
        guard let value = try JSONSerialization.jsonObject(with: data) as? [String: Any] else { throw CADTransferError.rejected }
        return value
    }
    static func seal(_ value: [String: Any], key: SymmetricKey, direction: String, sid: String, seq: Int) throws -> Data {
        let box = try AES.GCM.seal(pack(value), using: key, nonce: AES.GCM.Nonce(), authenticating: aad(direction, sid, seq))
        return try pack(["v": 1, "sid": sid, "seq": seq, "nonce": Data(box.nonce).base64EncodedString(),
                         "body": (box.ciphertext + box.tag).base64EncodedString()], limit: maxWire)
    }
    static func open(_ wire: Data, key: SymmetricKey, direction: String, sid: String, seq: Int) throws -> [String: Any] {
        let env = try parse(wire, limit: maxWire)
        try fields(env, ["v", "sid", "seq", "nonce", "body"])
        guard try integer(env["v"], 1, 1) == 1, try token(env["sid"]) == sid,
              try integer(env["seq"], 0, 1024) == seq else { throw CADTransferError.rejected }
        let nonce = try b64(env["nonce"], limit: 12), body = try b64(env["body"], limit: maxPlain + 16)
        guard nonce.count == 12, body.count > 16 else { throw CADTransferError.rejected }
        let box = try AES.GCM.SealedBox(nonce: AES.GCM.Nonce(data: nonce), ciphertext: body.dropLast(16), tag: body.suffix(16))
        do { return try parse(AES.GCM.open(box, using: key, authenticating: aad(direction, sid, seq))) }
        catch { throw CADTransferError.integrity }
    }
    static func name(_ value: Any?) throws -> String {
        guard let s = value as? String, s.utf8.allSatisfy({ (48...57).contains($0) || (65...90).contains($0) || (97...122).contains($0) || [45,46,95].contains($0) }),
              s.range(of: #"^[A-Za-z0-9_-]{1,80}\.(?:stl|3mf)$"#, options: [.regularExpression, .caseInsensitive]) == (s.startIndex..<s.endIndex) else { throw CADTransferError.invalidFile }
        let pieces = s.split(separator: ".")
        guard pieces.count == 2, String(pieces[0]).range(of: #"^(?:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])$"#, options: [.regularExpression, .caseInsensitive]) == nil else { throw CADTransferError.invalidFile }
        return String(pieces[0]) + "." + pieces[1].lowercased()
    }
    static func validate(_ data: Data, name: String) throws {
        _ = try self.name(name)
        guard !data.isEmpty, data.count <= maxFile else { throw CADTransferError.tooLarge }
        if name.lowercased().hasSuffix(".3mf") {
            guard Array(data.prefix(4)) == [0x50, 0x4b, 0x03, 0x04] else { throw CADTransferError.invalidFile }
            return // Opaque: no decompression or execution.
        }
        let head = Array(data.prefix(84))
        if head.count == 84 {
            let count = UInt64(head[80]) | UInt64(head[81]) << 8 | UInt64(head[82]) << 16 | UInt64(head[83]) << 24
            if count > 0, 84 + 50 * count == UInt64(data.count) { return }
        }
        let start = String(decoding: data.prefix(1024), as: UTF8.self).trimmingCharacters(in: .whitespacesAndNewlines)
        guard start.hasPrefix("solid"), String(decoding: data.suffix(1024), as: UTF8.self).contains("endsolid") else { throw CADTransferError.invalidFile }
    }
    static func digest(_ data: Data) -> String { SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined() }
    static func item(_ value: Any?) throws -> CADRemoteItem {
        guard let q = value as? [String: Any] else { throw CADTransferError.rejected }
        try fields(q, ["id", "name", "bytes", "sha256"])
        return CADRemoteItem(id: try token(q["id"]), name: try name(q["name"]), bytes: try integer(q["bytes"], 1, maxFile), sha256: try token(q["sha256"], bytes: 32))
    }
}

// Reject duplicate object keys, noninteger numbers and nesting before Foundation
// parsing. Escaped keys are decoded before duplicate comparison.
private struct StrictJSON {
    let bytes: [UInt8]; var i = 0
    mutating func ws() { while i < bytes.count && [9, 10, 13, 32].contains(bytes[i]) { i += 1 } }
    mutating func take(_ c: UInt8) throws { ws(); guard i < bytes.count, bytes[i] == c else { throw CADTransferError.rejected }; i += 1 }
    mutating func string() throws -> String {
        ws(); let start = i; try take(34); var escaped = false
        while i < bytes.count {
            let b = bytes[i]; i += 1
            if escaped { escaped = false }
            else if b == 92 { escaped = true }
            else if b == 34 {
                guard let s = try JSONSerialization.jsonObject(with: Data(bytes[start..<i]), options: [.fragmentsAllowed]) as? String else { throw CADTransferError.rejected }
                return s
            } else if b < 32 { throw CADTransferError.rejected }
        }
        throw CADTransferError.rejected
    }
    mutating func value(_ depth: Int) throws {
        ws(); guard depth <= 8, i < bytes.count else { throw CADTransferError.rejected }
        switch bytes[i] {
        case 123:
            i += 1; ws(); var keys = Set<String>()
            if i < bytes.count, bytes[i] == 125 { i += 1; return }
            while true {
                let key = try string(); guard keys.insert(key).inserted else { throw CADTransferError.rejected }
                try take(58); try value(depth + 1); ws()
                guard i < bytes.count else { throw CADTransferError.rejected }
                if bytes[i] == 125 { i += 1; break }; try take(44)
            }
        case 91:
            i += 1; ws(); if i < bytes.count, bytes[i] == 93 { i += 1; return }
            while true { try value(depth + 1); ws(); guard i < bytes.count else { throw CADTransferError.rejected }; if bytes[i] == 93 { i += 1; break }; try take(44) }
        case 34: _ = try string()
        case 116, 102, 110:
            let literal = bytes[i] == 116 ? Array("true".utf8) : (bytes[i] == 102 ? Array("false".utf8) : Array("null".utf8))
            guard i + literal.count <= bytes.count, Array(bytes[i..<(i + literal.count)]) == literal else { throw CADTransferError.rejected }; i += literal.count
        default:
            let start = i
            if bytes[i] == 45 { i += 1 }
            guard i < bytes.count, (48...57).contains(bytes[i]) else { throw CADTransferError.rejected }
            if bytes[i] == 48 { i += 1 } else { while i < bytes.count, (48...57).contains(bytes[i]) { i += 1 } }
            guard let s = String(bytes: bytes[start..<i], encoding: .utf8), let number = Int64(s), (-9007199254740991...9007199254740991).contains(number) else { throw CADTransferError.rejected }
        }
    }
    mutating func scan() throws { try value(1); ws(); guard i == bytes.count else { throw CADTransferError.rejected } }
}

private final class CADBoundedRequest: NSObject, URLSessionDataDelegate, @unchecked Sendable {
    private let lock = NSLock()
    private var continuation: CheckedContinuation<Data, Error>?
    private var session: URLSession?
    private var task: URLSessionDataTask?
    private var body = Data(); private var expected = 0; private var finished = false; private var cancelled = false
    private var requested: URL?
    func run(_ request: URLRequest) async throws -> Data {
        try await withTaskCancellationHandler(operation: {
            try await withCheckedThrowingContinuation { (c: CheckedContinuation<Data, Error>) in
                lock.lock()
                if cancelled { lock.unlock(); c.resume(throwing: CADTransferError.cancelled); return }
                continuation = c; requested = request.url
                let config = URLSessionConfiguration.ephemeral
                config.urlCache = nil; config.httpShouldSetCookies = false; config.httpCookieStorage = nil
                config.connectionProxyDictionary = ["HTTPEnable": 0, "HTTPSEnable": 0, "SOCKSEnable": 0]
                config.allowsCellularAccess = false; config.allowsExpensiveNetworkAccess = false; config.allowsConstrainedNetworkAccess = false
                config.waitsForConnectivity = false; config.timeoutIntervalForRequest = 3; config.timeoutIntervalForResource = 5
                let s = URLSession(configuration: config, delegate: self, delegateQueue: nil); session = s
                let t = s.dataTask(with: request); task = t; lock.unlock(); t.resume()
            }
        }, onCancel: { self.cancel() })
    }
    func cancel() { lock.lock(); cancelled = true; lock.unlock(); complete(.failure(CADTransferError.cancelled)) }
    private func complete(_ result: Result<Data, Error>) {
        lock.lock()
        guard !finished else { lock.unlock(); return }; finished = true
        let c = continuation; continuation = nil; let s = session; session = nil; task = nil; body.removeAll()
        lock.unlock(); s?.invalidateAndCancel(); c?.resume(with: result)
    }
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
        completionHandler(nil); complete(.failure(CADTransferError.rejected))
    }
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive response: URLResponse, completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {
        guard let r = response as? HTTPURLResponse, r.url == requested, r.statusCode == 200,
              r.mimeType == "application/json", r.expectedContentLength > 0, r.expectedContentLength <= Int64(CADTransferWire.maxWire),
              r.value(forHTTPHeaderField: "Transfer-Encoding") == nil, r.value(forHTTPHeaderField: "Content-Encoding") == nil else {
            completionHandler(.cancel); complete(.failure(CADTransferError.rejected)); return
        }
        lock.lock(); expected = Int(r.expectedContentLength); lock.unlock(); completionHandler(.allow)
    }
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        lock.lock()
        let valid = !finished && body.count + data.count <= expected && body.count + data.count <= CADTransferWire.maxWire
        if valid { body.append(data) }; lock.unlock()
        if !valid { complete(.failure(CADTransferError.rejected)) }
    }
    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        lock.lock(); let data = body; let valid = body.count == expected && expected > 0; lock.unlock()
        if error != nil { complete(.failure(CADTransferError.offOrUnreachable)) }
        else if valid { complete(.success(data)) }
        else { complete(.failure(CADTransferError.rejected)) }
    }
}

public actor CADTransferClient {
    private let pairingKey: Data; private let endpoint: String
    private var sid: String?; private var send: SymmetricKey?; private var receive: SymmetricKey?
    private var seq = 2; private var deadline: TimeInterval = 0; private var busy = false
    private var generation = 0
    private var activeRequest: CADBoundedRequest?
    public init(pairingKey: Data, pcIPv4: String, port: Int = 8766) throws {
        try self.init(pairingKey: pairingKey, pcIPv4: pcIPv4, port: port, loopbackTest: false)
    }
    init(pairingKey: Data, pcIPv4: String, port: Int, loopbackTest: Bool) throws {
        let octets = pcIPv4.split(separator: ".", omittingEmptySubsequences: false).compactMap { Int($0) }
        guard pairingKey.count == 32, (1024...65535).contains(port), octets.count == 4,
              octets.allSatisfy({ (0...255).contains($0) }), octets.map({ String($0) }).joined(separator: ".") == pcIPv4,
              ((octets[0] == 10 || octets[0] == 172 && (16...31).contains(octets[1]) || octets[0] == 192 && octets[1] == 168) && octets[3] != 0 && octets[3] != 255 || loopbackTest && pcIPv4 == "127.0.0.1") else { throw CADTransferError.invalidSetup }
        self.pairingKey = pairingKey; self.endpoint = "http://\(pcIPv4):\(port)"
    }
    public func stop() { generation += 1; activeRequest?.cancel(); activeRequest = nil; sid = nil; send = nil; receive = nil; deadline = 0 }
    private func post(_ path: String, _ body: Data) async throws -> Data {
        try Task.checkCancellation()
        guard body.count <= CADTransferWire.maxWire, let url = URL(string: endpoint + path) else { throw CADTransferError.invalidSetup }
        var req = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 3)
        req.httpMethod = "POST"; req.httpBody = body; req.setValue("application/json", forHTTPHeaderField: "Content-Type"); req.setValue("close", forHTTPHeaderField: "Connection")
        let request = CADBoundedRequest(); activeRequest = request
        defer { if activeRequest === request { activeRequest = nil } }
        return try await request.run(req)
    }
    public func start() async throws {
        guard !busy else { throw CADTransferError.busy }; busy = true; defer { busy = false }; stop()
        let attempt = generation
        let began = ProcessInfo.processInfo.systemUptime, client = CADTransferWire.random(32)
        do {
            let wire = try await post("/cad/v1/challenge", CADTransferWire.pack(["v":1,"client":client], limit:256))
            guard generation == attempt, !Task.isCancelled else { throw CADTransferError.cancelled }
            let env = try CADTransferWire.parse(wire, limit:CADTransferWire.maxWire), id = try CADTransferWire.token(env["sid"])
            let q = try CADTransferWire.open(wire, key:CADTransferWire.derive(pairingKey,purpose:"bootstrap"), direction:"challenge",sid:id,seq:0)
            try CADTransferWire.fields(q,["v","op","boot","client","challenge","ttl_ms"])
            guard try CADTransferWire.integer(q["v"],1,1)==1, q["op"] as? String == "challenge", q["client"] as? String == client,
                  try CADTransferWire.integer(q["ttl_ms"],10000,10000)==10000, ProcessInfo.processInfo.systemUptime-began < 10 else { throw CADTransferError.expired }
            let boot=try CADTransferWire.token(q["boot"],bytes:32), challenge=try CADTransferWire.token(q["challenge"],bytes:32)
            let (outKey,inKey)=try CADTransferWire.keys(pairingKey,boot:boot,sid:id,challenge:challenge,client:client)
            let auth=try CADTransferWire.seal(["v":1,"op":"authenticate","boot":boot,"challenge":challenge,"client":client],key:outKey,direction:"phone-to-pc",sid:id,seq:1)
            let reply=try CADTransferWire.open(await post("/cad/v1/auth",auth),key:inKey,direction:"pc-to-phone",sid:id,seq:1)
            guard generation == attempt, !Task.isCancelled else { throw CADTransferError.cancelled }
            try CADTransferWire.fields(reply,["v","op","ok","ttl_ms"])
            guard try CADTransferWire.integer(reply["v"],1,1)==1, reply["op"] as? String == "authenticated", try CADTransferWire.boolean(reply["ok"]) == true,
                  try CADTransferWire.integer(reply["ttl_ms"],180000,180000)==180000, !Task.isCancelled else { throw CADTransferError.rejected }
            sid=id;send=outKey;receive=inKey;seq=2;deadline=began+180
        } catch { stop(); throw error }
    }
    private func exchange(_ op: String, _ values: [String:Any] = [:]) async throws -> [String:Any] {
        guard let id=sid,let outKey=send,let inKey=receive else { throw CADTransferError.notStarted }
        guard ProcessInfo.processInfo.systemUptime<deadline,seq<=1024 else { stop();throw CADTransferError.expired }
        var payload=values;payload["v"]=1;payload["op"]=op;let n=seq
        do {
            let wire=try await post("/cad/v1/message",CADTransferWire.seal(payload,key:outKey,direction:"phone-to-pc",sid:id,seq:n))
            guard sid==id,!Task.isCancelled else { throw CADTransferError.cancelled }
            let q=try CADTransferWire.open(wire,key:inKey,direction:"pc-to-phone",sid:id,seq:n)
            guard try CADTransferWire.integer(q["v"],1,1)==1,q["op"] as? String==op,try CADTransferWire.boolean(q["ok"])==true else { throw CADTransferError.rejected }
            seq+=1;return q
        } catch { stop();throw error }
    }
    public func list() async throws -> [CADRemoteItem] {
        guard !busy else { throw CADTransferError.busy };busy=true;defer{busy=false}
        do { let q=try await exchange("list");try CADTransferWire.fields(q,["v","op","ok","items"])
            guard let items=q["items"] as? [Any],items.count<=128 else { throw CADTransferError.rejected };return try items.map(CADTransferWire.item)
        } catch {stop();throw error}
    }
    public func upload(name: String, data: Data) async throws -> CADRemoteItem {
        guard !busy else { throw CADTransferError.busy };busy=true;defer{busy=false}
        do {
            let safe=try CADTransferWire.name(name);try CADTransferWire.validate(data,name:safe);let hash=CADTransferWire.digest(data)
            let q=try await exchange("begin-upload",["name":safe,"bytes":data.count,"sha256":hash]);try CADTransferWire.fields(q,["v","op","ok","transfer","chunk_bytes"])
            let transfer=try CADTransferWire.token(q["transfer"]);guard try CADTransferWire.integer(q["chunk_bytes"],CADTransferWire.chunk,CADTransferWire.chunk)==CADTransferWire.chunk else {throw CADTransferError.rejected}
            var offset=0
            while offset<data.count {
                try Task.checkCancellation();let count=min(CADTransferWire.chunk,data.count-offset),chunk=Data(data.dropFirst(offset).prefix(count))
                let ack=try await exchange("upload-chunk",["transfer":transfer,"offset":offset,"data":chunk.base64EncodedString(),"sha256":CADTransferWire.digest(chunk)])
                try CADTransferWire.fields(ack,["v","op","ok","received"]);guard try CADTransferWire.integer(ack["received"],1,CADTransferWire.maxFile)==offset+count else{throw CADTransferError.integrity};offset+=count
            }
            let done=try await exchange("commit",["transfer":transfer]);try CADTransferWire.fields(done,["v","op","ok","item"]);let item=try CADTransferWire.item(done["item"])
            guard item.name==safe,item.bytes==data.count,item.sha256==hash else{throw CADTransferError.integrity};return item
        } catch {stop();throw error}
    }
    public func download(id: String) async throws -> (CADRemoteItem, Data) {
        guard !busy else {throw CADTransferError.busy};busy=true;defer{busy=false}
        do {
            let token=try CADTransferWire.token(id),q=try await exchange("begin-download",["id":token]);try CADTransferWire.fields(q,["v","op","ok","transfer","item","chunk_bytes"])
            let transfer=try CADTransferWire.token(q["transfer"]),item=try CADTransferWire.item(q["item"])
            guard item.id==token,try CADTransferWire.integer(q["chunk_bytes"],CADTransferWire.chunk,CADTransferWire.chunk)==CADTransferWire.chunk else{throw CADTransferError.rejected}
            var data=Data();data.reserveCapacity(item.bytes)
            while data.count<item.bytes {
                try Task.checkCancellation();let offset=data.count,c=try await exchange("download-chunk",["transfer":transfer,"offset":offset]);try CADTransferWire.fields(c,["v","op","ok","offset","data","sha256","done"])
                let chunk=try CADTransferWire.b64(c["data"],limit:CADTransferWire.chunk)
                guard try CADTransferWire.integer(c["offset"],0,CADTransferWire.maxFile)==offset,chunk.count==min(CADTransferWire.chunk,item.bytes-offset),
                      try CADTransferWire.token(c["sha256"],bytes:32)==CADTransferWire.digest(chunk),try CADTransferWire.boolean(c["done"])==(offset+chunk.count==item.bytes) else{throw CADTransferError.integrity}
                data.append(chunk)
            }
            guard CADTransferWire.digest(data)==item.sha256 else{throw CADTransferError.integrity};try CADTransferWire.validate(data,name:item.name);return(item,data)
        } catch {stop();throw error}
    }
}
