"""Explicitly started private-PC CAD listener; isolated from aircraft/printer control."""
from __future__ import annotations
from dataclasses import dataclass, field
import hashlib
import io
import socket
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
import secrets
import threading
import time
if __package__:
    from .protocol import *
    from .storage import Storage
else:
    from protocol import *
    from storage import Storage

@dataclass
class Pending:
    client: str
    challenge: str
    deadline: float
    receive_key: bytes
    send_key: bytes

@dataclass
class Session:
    deadline: float
    receive_key: bytes
    send_key: bytes
    next_seq: int = 2
    transfer: dict | None = None

class Core:
    def __init__(self, key: bytes, storage: Storage, clock=time.monotonic):
        self.key=key;self.bootstrap=derive(key,'bootstrap');self.storage=storage;self.clock=clock
        self.boot=secrets.token_hex(32);self.pending={};self.sessions={}

    def expire(self):
        now=self.clock()
        self.pending={k:v for k,v in self.pending.items() if now<v.deadline}
        self.sessions={k:v for k,v in self.sessions.items() if now<v.deadline}

    def challenge(self, wire: bytes):
        self.expire();q=fields(parse(wire,256),{'v','client'})
        if type(q['v']) is not int or q['v']!=1: raise Rejected('Version')
        client=token(q['client'],32)
        if len(self.pending)>=MAX_CHALLENGES: raise Rejected('Busy')
        sid=secrets.token_hex(16);challenge=secrets.token_hex(32)
        receive,send=session_keys(self.key,self.boot,sid,challenge,client)
        self.pending[sid]=Pending(client,challenge,self.clock()+CHALLENGE_SECONDS,receive,send)
        return seal({'v':1,'op':'challenge','boot':self.boot,'client':client,'challenge':challenge,'ttl_ms':CHALLENGE_SECONDS*1000},self.bootstrap,'challenge',sid,0)

    def authenticate(self, wire: bytes):
        self.expire();env=fields(parse(wire,MAX_WIRE),{'v','sid','seq','nonce','body'});sid=token(env['sid'])
        pending=self.pending.pop(sid,None)  # Single-use even if authentication fails.
        if pending is None: raise Rejected('No fresh challenge')
        q=fields(open_message(wire,pending.receive_key,'phone-to-pc',sid,1),{'v','op','boot','client','challenge'})
        if q!={'v':1,'op':'authenticate','boot':self.boot,'client':pending.client,'challenge':pending.challenge} or type(q['v']) is not int:
            raise Rejected('Wrong challenge')
        # One selected phone owns one active CAD session. A newly authenticated
        # Start cancels prior temporary transfers instead of blocking reconnects.
        self.sessions.clear()
        self.sessions[sid]=Session(self.clock()+SESSION_SECONDS,pending.receive_key,pending.send_key)
        return seal({'v':1,'op':'authenticated','ok':True,'ttl_ms':SESSION_SECONDS*1000},pending.send_key,'pc-to-phone',sid,1)

    def reserved(self):
        return sum(s.transfer['bytes'] for s in self.sessions.values() if s.transfer and s.transfer['kind']=='upload')

    def message(self, wire: bytes):
        self.expire();env=fields(parse(wire,MAX_WIRE),{'v','sid','seq','nonce','body'});sid=token(env['sid'])
        s=self.sessions.get(sid)
        if s is None: raise Rejected('No live session')
        seq=s.next_seq
        try:
            if seq>MAX_REQUESTS: raise Rejected('Session request limit')
            q=open_message(wire,s.receive_key,'phone-to-pc',sid,seq)
            if type(q.get('v')) is not int or q.get('v')!=1 or not isinstance(q.get('op'),str): raise Rejected('Request')
            s.next_seq+=1
            result=self.dispatch(s,q)
            return seal({'v':1,'op':q['op'],'ok':True,**result},s.send_key,'pc-to-phone',sid,seq)
        except (Rejected, OSError):
            self.sessions.pop(sid,None)
            raise Rejected('CAD request rejected')

    def dispatch(self, s: Session, q: dict):
        op=q['op']
        if op=='list':
            fields(q,{'v','op'});_,items=self.storage.scan()
            return {'items':items}
        if op=='abort':
            fields(q,{'v','op'});s.transfer=None
            return {}
        if op=='begin-upload':
            fields(q,{'v','op','name','bytes','sha256'})
            if s.transfer: raise Rejected('One transfer per session')
            name=safe_name(q['name']);size=integer(q['bytes'],1,MAX_FILE);digest=token(q['sha256'],32)
            total,items=self.storage.scan()
            if total+self.reserved()+size>MAX_TOTAL or len(items)>=MAX_FILES: raise Rejected('Quota')
            transfer=secrets.token_hex(16)
            s.transfer={'kind':'upload','id':transfer,'name':name,'bytes':size,'sha256':digest,'data':bytearray()}
            return {'transfer':transfer,'chunk_bytes':CHUNK}
        if op=='upload-chunk':
            fields(q,{'v','op','transfer','offset','data','sha256'});t=s.transfer
            if not t or t['kind']!='upload' or token(q['transfer'])!=t['id']: raise Rejected('Transfer')
            offset=integer(q['offset'],0,MAX_FILE)
            data=unb64(q['data'],CHUNK);digest=token(q['sha256'],32)
            if offset!=len(t['data']) or not data or len(data)>t['bytes']-offset or hashlib.sha256(data).hexdigest()!=digest: raise Rejected('Chunk')
            # Every non-final chunk is exactly 256 KiB, making offsets and retries unambiguous.
            if len(data)!=min(CHUNK,t['bytes']-offset): raise Rejected('Chunk length')
            t['data'].extend(data)
            return {'received':len(t['data'])}
        if op=='commit':
            fields(q,{'v','op','transfer'});t=s.transfer
            if not t or t['kind']!='upload' or token(q['transfer'])!=t['id'] or len(t['data'])!=t['bytes']: raise Rejected('Transfer incomplete')
            item=self.storage.save(bytes(t['data']),t['name'],t['sha256']);s.transfer=None
            return {'item':item}
        if op=='begin-download':
            fields(q,{'v','op','id'})
            if s.transfer: raise Rejected('One transfer per session')
            item,data=self.storage.read(token(q['id']));transfer=secrets.token_hex(16)
            s.transfer={'kind':'download','id':transfer,'bytes':len(data),'data':data,'offset':0}
            return {'transfer':transfer,'item':item,'chunk_bytes':CHUNK}
        if op=='download-chunk':
            fields(q,{'v','op','transfer','offset'});t=s.transfer
            if not t or t['kind']!='download' or token(q['transfer'])!=t['id']: raise Rejected('Transfer')
            offset=integer(q['offset'],0,MAX_FILE)
            if offset!=t['offset'] or offset>=t['bytes']: raise Rejected('Chunk order')
            data=t['data'][offset:offset+CHUNK];t['offset']+=len(data)
            if t['offset']==t['bytes']: s.transfer=None
            return {'offset':offset,'data':b64(data),'sha256':hashlib.sha256(data).hexdigest(),'done':s.transfer is None}
        raise Rejected('CAD operation not allowed')

@dataclass
class RequestLease:
    deadline: float
    ended: threading.Event = field(default_factory=threading.Event)
    timer: threading.Timer | None = None
    def check(self):
        if self.ended.is_set() or time.monotonic()>=self.deadline:raise OSError('CAD request ended')

class DeadlineReader(io.RawIOBase):
    def __init__(self,sock,lease):self.sock=sock;self.lease=lease
    def readable(self):return True
    def readinto(self,buffer):
        while True:
            self.lease.check()
            try:return self.sock.recv_into(buffer)
            except socket.timeout:continue

class DeadlineWriter(io.BufferedIOBase):
    def __init__(self,sock,lease):self.sock=sock;self.lease=lease
    def writable(self):return True
    def write(self,data):
        view=memoryview(data);sent=0
        while sent<len(view):
            self.lease.check()
            try:n=self.sock.send(view[sent:])
            except socket.timeout:continue
            if not n:raise OSError('CAD connection closed')
            sent+=n
        return sent

class Listener(HTTPServer):
    request_queue_size=4
    allow_reuse_address=False
    request_seconds=3
    def __init__(self,*args,**kwargs):
        self._request_lock=threading.Lock()
        self._active_requests={}
        self._stopping=False
        super().__init__(*args,**kwargs)
    @staticmethod
    def _close_socket(sock):
        try:sock.shutdown(socket.SHUT_RDWR)
        except OSError:pass
        try:sock.close()
        except OSError:pass
    def _expire_request(self,sock):
        # An old watchdog can act only on the exact still-owned socket object.
        # Descriptor reuse or a later request never transfers this ownership.
        with self._request_lock:
            lease=self._active_requests.pop(sock,None)
        if lease is not None:
            lease.ended.set();self._close_socket(sock)
    def close_active_requests(self):
        with self._request_lock:
            self._stopping=True
            active=list(self._active_requests.items())
            self._active_requests.clear()
        for sock,lease in active:
            lease.ended.set();lease.timer.cancel();self._close_socket(sock)
    def request_lease(self,sock):
        with self._request_lock:lease=self._active_requests.get(sock)
        if lease is None:
            lease=RequestLease(0);lease.ended.set()
        return lease
    def service_actions(self):
        self.core.expire()
    def get_request(self):
        sock,peer=super().get_request();sock.settimeout(.1)
        lease=RequestLease(time.monotonic()+self.request_seconds)
        timer=threading.Timer(max(0,lease.deadline-time.monotonic()),self._expire_request,args=(sock,));timer.daemon=True;lease.timer=timer
        with self._request_lock:
            if self._stopping:
                self._close_socket(sock);raise OSError('CAD listener stopped')
            self._active_requests[sock]=lease
            timer.start()
        return sock,peer
    def shutdown_request(self,request):
        with self._request_lock:
            lease=self._active_requests.pop(request,None)
        if lease is not None:
            lease.ended.set();lease.timer.cancel()
        super().shutdown_request(request)
    def verify_request(self,request,client_address):
        return client_address[0]==self.allowed_phone

class Handler(BaseHTTPRequestHandler):
    protocol_version='HTTP/1.0'
    server_version='CADTransfer/1'
    sys_version=''
    def setup(self):
        super().setup()
        self.rfile.close();self.wfile.close()
        lease=self.server.request_lease(self.connection)
        self.rfile=io.BufferedReader(DeadlineReader(self.connection,lease),buffer_size=65536)
        self.wfile=DeadlineWriter(self.connection,lease)
    def log_message(self,*args): pass  # No plaintext names, payloads or secrets in logs.
    def handle(self):
        try:super().handle()
        except OSError:pass  # Expected peer disconnect, watchdog deadline or Stop.
    def do_POST(self):
        try:
            if self.path not in ('/cad/v1/challenge','/cad/v1/auth','/cad/v1/message'): raise Rejected('Route')
            length=self.headers.get_all('Content-Length',[])
            if len(length)!=1 or not length[0].isascii() or not length[0].isdigit(): raise Rejected('Length')
            n=integer(int(length[0]),1,MAX_WIRE)
            if self.headers.get('Transfer-Encoding') is not None or self.headers.get('Content-Type')!='application/json' or self.headers.get('Expect') is not None: raise Rejected('Framing')
            if self.path=='/cad/v1/challenge' and n>256: raise Rejected('Challenge size')
            wire=self.rfile.read(n)
            if len(wire)!=n: raise Rejected('Truncated request')
            fn={'/cad/v1/challenge':self.server.core.challenge,'/cad/v1/auth':self.server.core.authenticate,'/cad/v1/message':self.server.core.message}[self.path]
            response=fn(wire);status=200
        except (Rejected,OSError,ValueError):
            response=b'{"error":"rejected"}';status=400
        self.send_response(status);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(response)));self.send_header('Cache-Control','no-store');self.send_header('Connection','close');self.end_headers()
        try:self.wfile.write(response)
        except OSError:pass

class CADServer:
    def __init__(self):
        self._lifecycle_lock=threading.RLock()
        self.listener=None;self.thread=None;self.storage=None
    @property
    def running(self):return self.listener is not None
    def start(self, pairing_key: bytes, pc_ip: str, phone_ip: str, port: int=8766):
        self._start(pairing_key,address(pc_ip),address(phone_ip),integer(port,1024,65535),None)
    def start_loopback_test(self, pairing_key: bytes, temporary_root: Path):
        # Deliberate test-only entry point; root and loopback never enter production start().
        self._start(pairing_key,'127.0.0.1','127.0.0.1',0,temporary_root)
    def _start(self,key,pc,phone,port,test_root):
        with self._lifecycle_lock:
            if self.running:raise Rejected('Already started')
            derive(key,'bootstrap')
            store=Storage(test_root,test=True) if test_root is not None else Storage.production()
            try:
                listener=Listener((pc,port),Handler);listener.allowed_phone=phone;listener.core=Core(key,store)
            except Exception:
                store.close();raise
            self.storage=store;self.listener=listener
            try:
                self.thread=threading.Thread(target=listener.serve_forever,kwargs={'poll_interval':.05},name='CADTransfer',daemon=True)
                self.thread.start()
            except Exception:
                # shutdown() must never wait for a serve_forever loop that did not
                # start. Release the bound listener/storage directly on failure.
                listener.close_active_requests();listener.server_close()
                listener.core.key=b'';listener.core.bootstrap=b'';store.close()
                self.thread=None;self.listener=None;self.storage=None
                raise
    def stop(self):
        with self._lifecycle_lock:
            if self.listener:
                # Wake a header/body read before shutdown waits for serve_forever.
                self.listener.close_active_requests()
                self.listener.shutdown();self.listener.server_close();self.thread.join(timeout=4)
                self.listener.core.pending.clear();self.listener.core.sessions.clear();self.listener.core.key=b'';self.listener.core.bootstrap=b''
                self.listener=None;self.thread=None;self.storage.close();self.storage=None
