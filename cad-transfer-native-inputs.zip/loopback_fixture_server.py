"""Native CI fixture: synthetic key, 127.0.0.1 only, isolated temporary CAD root."""
import json
from pathlib import Path
import signal
import tempfile
import threading
from server import CADServer

root=Path(__file__).resolve().parent
done=threading.Event()
for name in ('SIGINT','SIGTERM'):
    if hasattr(signal,name):signal.signal(getattr(signal,name),lambda *_:done.set())
with tempfile.TemporaryDirectory(prefix='native-fixture-',dir=root) as d:
    server=CADServer()
    try:
        server.start_loopback_test(bytes(range(32)),Path(d)/'CAD')
        print(json.dumps({'port':server.listener.server_port,'synthetic_public_key':True,'scope':'127.0.0.1 only'}),flush=True)
        done.wait(300)
    finally:server.stop()
