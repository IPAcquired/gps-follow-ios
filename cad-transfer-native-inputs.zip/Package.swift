// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "CADTransferCandidate",
    platforms: [.macOS(.v13), .iOS(.v15)],
    products: [.library(name: "CADTransferCandidate", targets: ["CADTransferCandidate"])],
    targets: [
        .target(name: "CADTransferCandidate", path: ".",
                exclude: ["SwiftTests", "__init__.py", "protocol.py", "storage.py", "server.py", "client.py", "test_candidate.py", "generate_fixtures.py", "loopback_fixture_server.py", "run_native_fixture.py", "freeze_candidate.py", "README.md", "PROTOCOL.md", "candidate-manifest.json", "test-results.json", "deadline-tests.json", "cad-fixtures.json", "__pycache__"],
                sources: ["CADTransferClient.swift"]),
        .testTarget(name: "CADTransferCandidateTests", dependencies: ["CADTransferCandidate"],
                    path: "SwiftTests", resources: [.copy("cad-fixtures.json")])
    ]
)
