import XCTest
import CryptoKit
@testable import CADTransferCandidate

final class CADTransferCandidateTests: XCTestCase {
    func fixture() throws -> [String: Any] {
        let url = try XCTUnwrap(Bundle.module.url(forResource: "cad-fixtures", withExtension: "json"))
        return try XCTUnwrap(JSONSerialization.jsonObject(with: Data(contentsOf: url)) as? [String: Any])
    }
    func keyHex(_ key: SymmetricKey) -> String { key.withUnsafeBytes { $0.map { String(format:"%02x",$0) }.joined() } }
    func testPythonHKDFAndEncryptedResponse() throws {
        let f=try fixture(),key=try CADTransferWire.hex(XCTUnwrap(f["pairing_key_hex"] as? String))
        XCTAssertEqual(try keyHex(CADTransferWire.derive(key,purpose:"bootstrap")),f["bootstrap_key_hex"] as? String)
        let sid=try XCTUnwrap(f["sid"] as? String)
        let (send,receive)=try CADTransferWire.keys(key,boot:XCTUnwrap(f["boot"] as? String),sid:sid,challenge:XCTUnwrap(f["challenge"] as? String),client:XCTUnwrap(f["client"] as? String))
        XCTAssertEqual(keyHex(send),f["phone_to_pc_key_hex"] as? String);XCTAssertEqual(keyHex(receive),f["pc_to_phone_key_hex"] as? String)
        let wire=try CADTransferWire.b64(f["response_wire_base64"],limit:CADTransferWire.maxWire)
        let q=try CADTransferWire.open(wire,key:receive,direction:"pc-to-phone",sid:sid,seq:2)
        XCTAssertEqual(q["op"] as? String,"list");XCTAssertTrue(try CADTransferWire.boolean(q["ok"]))
        XCTAssertThrowsError(try CADTransferWire.open(wire,key:receive,direction:"phone-to-pc",sid:sid,seq:2))
        XCTAssertThrowsError(try CADTransferWire.open(wire,key:receive,direction:"pc-to-phone",sid:sid,seq:3))
    }
    func testStrictParsingAndMetadata() throws {
        for text in [#"{"v":1,"v":1}"#,#"{"v":1,"\u0076":1}"#,#"{"x":NaN}"#,#"{"x":1e999}"#,#"{"x":1.5}"#] { XCTAssertThrowsError(try CADTransferWire.parse(Data(text.utf8))) }
        XCTAssertThrowsError(try CADTransferWire.integer(true,0,5));XCTAssertThrowsError(try CADTransferWire.boolean(1))
        for name in ["../part.stl","C:\\part.stl","part.stl:stream","firmware.bin","update.exe","CON.stl","part.stl\n","\u{212a}.stl"] { XCTAssertThrowsError(try CADTransferWire.name(name)) }
        XCTAssertEqual(try CADTransferWire.name("part.STL"),"part.stl")
        XCTAssertThrowsError(try CADTransferClient(pairingKey:Data(repeating:0,count:32),pcIPv4:"8.8.8.8"))
        XCTAssertThrowsError(try CADTransferClient(pairingKey:Data(repeating:0,count:32),pcIPv4:"127.0.0.1"))
    }
    func testBinarySTLAndBounds() throws {
        var binary=Data(repeating:0,count:134);binary[80]=1
        XCTAssertNoThrow(try CADTransferWire.validate(binary,name:"part.stl"))
        XCTAssertThrowsError(try CADTransferWire.validate(Data("MZexe".utf8),name:"part.stl"))
        XCTAssertThrowsError(try CADTransferWire.validate(Data(repeating:0,count:CADTransferWire.maxFile+1),name:"part.stl"))
    }
    func loopback() throws -> CADTransferClient {
        guard let value=ProcessInfo.processInfo.environment["CAD_LOOPBACK_PORT"],let port=Int(value) else {throw XCTSkip("Start the isolated public-key Python loopback fixture to run live cross-language tests")}
        return try CADTransferClient(pairingKey:Data((0..<32).map{UInt8($0)}),pcIPv4:"127.0.0.1",port:port,loopbackTest:true)
    }
    func testLiveSwiftPythonSTLRoundtrip() async throws {
        let client=try loopback();try await client.start()
        var data=Data("solid native\n".utf8);data.append(Data(repeating:32,count:CADTransferWire.chunk*2+37));data.append(Data("\nendsolid native\n".utf8))
        let item=try await client.upload(name:"native_part.stl",data:data)
        let items=try await client.list();XCTAssertTrue(items.contains(item))
        let (found,received)=try await client.download(id:item.id);XCTAssertEqual(found,item);XCTAssertEqual(received,data)
        await client.stop()
        do {_ = try await client.list();XCTFail("Stopped client reused a session")} catch {}
    }
    func testLiveSwiftPython3MFRoundtrip() async throws {
        let client=try loopback();try await client.start()
        let data=Data([0x50,0x4b,0x03,0x04])+Data(repeating:7,count:4096)
        let item=try await client.upload(name:"native_part.3mf",data:data)
        let (_,received)=try await client.download(id:item.id);XCTAssertEqual(received,data);await client.stop()
    }
    func testLiveWrongPairingKey() async throws {
        guard let value=ProcessInfo.processInfo.environment["CAD_LOOPBACK_PORT"],let port=Int(value) else {throw XCTSkip("Loopback fixture not started")}
        let client=try CADTransferClient(pairingKey:Data(repeating:0,count:32),pcIPv4:"127.0.0.1",port:port,loopbackTest:true)
        do {try await client.start();XCTFail("Wrong pairing key accepted")} catch {}
        await client.stop()
    }
    func testCancellationBeforeNetwork() async throws {
        let client=try loopback()
        let task=Task {try await client.start()};task.cancel()
        do {try await task.value;XCTFail("Cancelled start succeeded")} catch {}
        await client.stop()
    }
}
