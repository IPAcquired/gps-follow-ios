"""Mac CI entry point: own the loopback fixture for the duration of swift test."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from server import CADServer

root=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory(prefix='native-ci-',dir=root) as d:
    server=CADServer()
    try:
        server.start_loopback_test(bytes(range(32)),Path(d)/'CAD')
        env=dict(os.environ,CAD_LOOPBACK_PORT=str(server.listener.server_port))
        result=subprocess.run(['swift','test','--parallel','--num-workers','1'],cwd=root,env=env,timeout=180,capture_output=True,text=True)
        report={'native_swift_exit':result.returncode,'live_loopback_fixture':True,'synthetic_public_key':True,'stdout':result.stdout,'stderr':result.stderr}
        (root/'native-swift-results.json').write_text(json.dumps(report,indent=2)+'\n');print(result.stdout);print(result.stderr,file=sys.stderr)
    finally:server.stop()
raise SystemExit(result.returncode)
