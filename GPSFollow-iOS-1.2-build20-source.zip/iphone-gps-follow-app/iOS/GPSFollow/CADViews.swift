import SwiftUI
import UniformTypeIdentifiers
import CoreFoundation

@MainActor struct CADLibraryView: View {
    @ObservedObject var gps: GPSModel
    @ObservedObject var library: CADLibrary
    @State private var importing = false
    @State private var pendingRemoval: CADItem?

    var body: some View {
        NavigationStack {
            List {
                Section("PC file transfer") {
                    NavigationLink("Send / receive CAD over Wi-Fi") { CADTransferView(gps: gps, library: library) }
                }
                Section {
                    Button { importing = true } label: { Label("Add STL or 3MF", systemImage: "plus.circle.fill") }
                    Text("Save a copy from Files, AirDrop or your PC. Original files and dimensions stay unchanged. Saved locally on this iPhone and excluded from automatic backup; use Share / Save to Files to keep another copy.")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
                if library.items.isEmpty {
                    ContentUnavailableView("Your drone parts", systemImage: "cube.transparent", description: Text("Add a landing leg, battery tray or another drone design."))
                } else {
                    Section("Saved designs · \(library.items.count)") {
                        ForEach(library.items) { item in
                            VStack(alignment: .leading, spacing: 6) {
                                Text(item.name).font(.headline)
                                Text("\(item.url.pathExtension.uppercased()) · \(item.sizeText)").font(.caption).foregroundStyle(.secondary)
                                ShareLink(item: item.url) { Label("Send to PC / Save to Files / Share", systemImage: "square.and.arrow.up") }
                            }
                            .padding(.vertical, 4)
                            .swipeActions { Button("Remove", role: .destructive) { pendingRemoval = item } }
                        }
                    }
                }
                Section("Before printing") {
                    Text("Files are stored and shared unchanged. Import checks only file type, basic header and size; it does not verify mesh strength, watertightness, dimensions, supports or printer instructions.")
                    Text("Use the Printer tab for the slicing and printing steps. An STL is a model, not a ready-to-run printer job.")
                }.font(.footnote)
                if let error = library.error { Section { Text(error).foregroundStyle(.red) } }
            }
            .modifier(DroneMatrixSurface())
            .navigationTitle("Drone CAD")
            .onAppear { library.refresh() }
            .fileImporter(isPresented: $importing, allowedContentTypes: [.data], allowsMultipleSelection: false) { result in
                switch result {
                case .success(let urls):
                    guard let source = urls.first else { return }
                    do { _ = try library.importFile(source); library.error = nil }
                    catch { library.error = error.localizedDescription }
                case .failure(let error): library.error = error.localizedDescription
                }
            }
            .confirmationDialog("Remove this copy from your iPhone?", isPresented: Binding(get: { pendingRemoval != nil }, set: { if !$0 { pendingRemoval = nil } }), titleVisibility: .visible) {
                Button("Remove local copy", role: .destructive) {
                    if let item = pendingRemoval { library.remove(item) }
                    pendingRemoval = nil
                }
                Button("Cancel", role: .cancel) { pendingRemoval = nil }
            }
            .safeAreaInset(edge: .bottom) { AppBrandFooter() }
        }
    }
}

@MainActor struct PrinterView: View {
    @ObservedObject var library: CADLibrary
    @StateObject private var printer = PrinterModel()
    @State private var now = Date()
    @FocusState private var editing: Bool
    @Environment(\.scenePhase) private var scenePhase
    @State private var confirmProfileRemoval = false
    var body: some View {
        NavigationStack {
            Form {
                Section("Your Elegoo printer profiles") {
                    if !printer.profiles.isEmpty {
                        Picker("Saved printer", selection: Binding(get: { printer.profileID }, set: { printer.selectProfile($0) })) {
                            ForEach(printer.profiles) { profile in Text(profile.name).tag(profile.id) }
                        }
                    }
                    TextField("Printer name", text: $printer.profileName).focused($editing)
                    Picker("Elegoo model", selection: $printer.family) { ForEach(ElegooFamily.allCases) { Text($0.rawValue).tag($0) } }
                        .onChange(of: printer.family) { _, _ in printer.addressChanged() }
                    Button("Save profile") { editing = false; printer.saveProfile() }
                    Button("Add another Elegoo printer") { printer.addProfile() }
                    Button("Remove this profile", role: .destructive) { confirmProfileRemoval = true }
                    if !printer.family.supported { Text("Profile storage is available for this model. Its direct connection adapter is not enabled here; Carbon 2 commands will never be sent to it.").font(.footnote).foregroundStyle(.secondary) }
                }
                Section {
                    TextField("Printer Wi-Fi IP", text: $printer.ip).keyboardType(.decimalPad).focused($editing)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                        .onChange(of: printer.ip) { _, _ in printer.addressChanged() }
                    SecureField("Printer LAN access code", text: $printer.code).focused($editing)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                    Button("Find printer at this address") { editing = false; printer.discover() }.disabled(printer.busy || !printer.family.supported)
                    if let selected = printer.selected {
                        LabeledContent("Selected printer", value: selected.name)
                        LabeledContent("Model", value: selected.model)
                        LabeledContent("Serial number", value: selected.serial)
                        Button("Connect to this printer / Refresh status") { editing = false; printer.connect() }.disabled(printer.busy || !printer.family.supported)
                    }
                    if printer.busy { ProgressView("Checking direct LAN connection…") }
                    Button("Disconnect", role: .destructive) { printer.disconnect() }
                    if let error = printer.error { Text(error).foregroundStyle(.red) }
                } header: {
                    Text("Direct iPhone → Carbon 2 · same Wi-Fi")
                } footer: {
                    Text("Enter the address shown on the printer. Finding uses one selected address, not a network scan. Verify its serial before connecting. The vendor’s LAN connection uses an access code but plain HTTP/MQTT, so use a trusted private Wi-Fi; this printer link is not encrypted. No automatic print, heater or movement commands are sent.")
                }
                if let status = printer.snapshot {
                    Section("Direct printer status") {
                        LabeledContent("State at last check", value: status.state)
                        LabeledContent("Checked", value: "\(Int(max(0, now.timeIntervalSince(status.checked)))) seconds ago")
                        LabeledContent("Printer firmware", value: status.version)
                        if let progress = status.progress { LabeledContent("Progress", value: String(format: "%.0f%%", progress)) }
                        if let nozzle = status.nozzle { LabeledContent("Nozzle", value: String(format: "%.1f °C", nozzle)) }
                        if let bed = status.bed { LabeledContent("Bed", value: String(format: "%.1f °C", bed)) }
                        Text("A bounded status check finishes and closes its network session. Refresh to get a new full reading; old or partial events are not shown as live status.")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                }
                Section("Remote / Cellular · official account") {
                    Link("Open Elegoo Matrix / account setup", destination: URL(string: "https://apps.apple.com/app/id6745138636")!)
                    Text("Open Matrix, sign in there, bind this printer to your account and keep the printer connected to the Internet. Use Matrix’s remote controls when the iPhone is away from your printer’s Wi-Fi, including cellular where supported.")
                    Text("Your Elegoo account stays in Matrix. This app does not collect its password, copy vendor tokens or claim to be logged into that account.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                Section("Print your drone parts") {
                    Label("Elegoo printer workflow", systemImage: "printer.fill").font(.headline)
                    LabeledContent("Your confirmed printer", value: "Elegoo Centauri Carbon 2")
                    LabeledContent("Your installed nozzle", value: "0.6 mm")
                    Text("The old saved PC profile was for the original Centauri Carbon. Use the verified Carbon 2 profile on the PC after it has been prepared; this phone does not change slicer settings.")
                        .foregroundStyle(.orange)
                    Text("Use your verified, saved printer profile in Elegoo Slicer on the PC. Choose the exact printer generation and installed nozzle there before slicing.")
                    Text("The iPhone stores designs and shares files. It does not slice, send printer commands or start a print.")
                        .foregroundStyle(.secondary)
                }
                Section("Three simple steps") {
                    Text("1. Add your STL or 3MF in Drone CAD, then Share it to the PC or save it to Files.")
                    Text("2. Open it in Elegoo Slicer using the saved printer profile. Check dimensions, orientation, supports and sliced preview.")
                    Text("3. Send the checked job using Elegoo’s supported printer workflow. Elegoo Matrix supports printer controls; 3D GO is a separate design and slicing app, not a verified Carbon 2 controller.")
                    Link("Elegoo Matrix on the App Store", destination: URL(string: "https://apps.apple.com/app/id6745138636")!)
                }
                Section {
                    if library.items.isEmpty { Text("Add a design in Drone CAD first.").foregroundStyle(.secondary) }
                    ForEach(library.items) { item in
                        ShareLink(item: item.url) { Label(item.name, systemImage: "square.and.arrow.up") }
                    }
                } header: {
                    Text("Send a saved design")
                } footer: {
                    Text("The Share menu shows compatible installed apps. An app appearing there does not guarantee that it can slice or print this model.")
                }
                Section("Printer connection") {
                    LabeledContent("Direct LAN capability", value: "Discovery, access-code check and full status")
                    Text("G-code upload and print-start controls are not enabled here. Use the checked slicer / Matrix workflow to print. 3D GO does not provide a verified public Carbon 2 control interface.")
                    Text("Your printer’s network and your drone’s telemetry are separate. Never use a printer connection or printer job as a drone command.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
            .modifier(DroneMatrixSurface())
            .navigationTitle("Printer")
            .alert("Remove this saved printer profile?", isPresented: $confirmProfileRemoval) {
                Button("Remove", role: .destructive) { printer.removeProfile() }
                Button("Cancel", role: .cancel) { }
            } message: { Text("This removes its saved address and private access code from this app. It does not reset the printer or change your Elegoo account.") }
            .onAppear { library.refresh() }
            .onDisappear { printer.disconnect() }
            .onChange(of: scenePhase) { _, phase in if phase == .background { printer.disconnect() } }
            .onReceive(Timer.publish(every: 1, on: .main, in: .common).autoconnect()) { now = $0 }
            .scrollDismissesKeyboard(.interactively)
            .toolbar { ToolbarItemGroup(placement: .keyboard) { Spacer(); Button("Done") { editing = false } } }
            .safeAreaInset(edge: .bottom) { AppBrandFooter() }
        }
    }
}

struct AppBrandFooter: View {
    var body: some View {
        Text("Made by Nate Wrench 2026").font(.footnote).foregroundStyle(.secondary)
            .frame(maxWidth: .infinity).padding(.vertical, 8).background(.bar)
    }
}

struct FlightLogOverview: Sendable, Equatable {
    let name: String
    let bytes: Int
    let counts: [String: Int]
    let unparsedBytes: Int
    var reviewText: String {
        let types = counts.sorted { $0.key < $1.key }.map { "\($0.key): \($0.value) records" }.joined(separator: "\n")
        return "Flight log: \(name)\nSize: \(bytes) bytes\n\(types)\nUnparsed/truncated bytes: \(unparsedBytes)\n\nThis is a file overview, not a flight diagnosis. Record counts do not prove sensor health or justify PID changes. Use the PC Flight Logs review for evidence and proposed changes. No settings were changed."
    }
}

enum FlightLogReader {
    static let maximumBytes = 32 * 1024 * 1024
    static func inspect(_ data: Data, name: String) throws -> FlightLogOverview {
        guard name.lowercased().hasSuffix(".bin"), !data.isEmpty, data.count <= maximumBytes else {
            throw CocoaError(.fileReadCorruptFile)
        }
        let bytes = [UInt8](data)
        var formats: [UInt8: (Int, String)] = [:]
        var counts: [String: Int] = [:]
        var cursor = 0, unparsed = 0
        while cursor < bytes.count {
            if cursor % 4096 == 0 { try Task.checkCancellation() }
            guard cursor + 3 <= bytes.count, bytes[cursor] == 0xA3, bytes[cursor + 1] == 0x95 else {
                cursor += 1; unparsed += 1; continue
            }
            let type = bytes[cursor + 2]
            if type == 0x80, cursor + 89 <= bytes.count {
                let length = Int(bytes[cursor + 4])
                let nameBytes = bytes[(cursor + 5)..<(cursor + 9)].prefix { $0 != 0 }
                guard length >= 3, !nameBytes.isEmpty, nameBytes.allSatisfy({ (32...126).contains($0) }) else {
                    cursor += 1; unparsed += 1; continue
                }
                let recordName = String(decoding: nameBytes, as: UTF8.self)
                formats[bytes[cursor + 3]] = (length, recordName)
                counts["FMT", default: 0] += 1
                cursor += 89
            } else if let (length, name) = formats[type], cursor + length <= bytes.count {
                counts[name, default: 0] += 1; cursor += length
            } else { cursor += 1; unparsed += 1 }
        }
        guard counts["FMT", default: 0] > 0 else { throw CocoaError(.fileReadCorruptFile) }
        return FlightLogOverview(name: name, bytes: data.count, counts: counts, unparsedBytes: unparsed)
    }
    static func read(_ url: URL) throws -> FlightLogOverview {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        let values = try url.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey])
        guard values.isRegularFile == true, values.isSymbolicLink != true else { throw CocoaError(.fileReadNoPermission) }
        let handle = try FileHandle(forReadingFrom: url)
        defer { try? handle.close() }
        let data = try handle.read(upToCount: maximumBytes + 1) ?? Data()
        try Task.checkCancellation()
        return try inspect(data, name: url.lastPathComponent)
    }
}

struct FlightReviewDocument: Sendable, Equatable {
    let text: String
    static let maximumBytes = 256 * 1024
    static func parse(_ data: Data) throws -> FlightReviewDocument {
        guard data.count <= maximumBytes,
              let object = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              object["report_type"] as? String == "gpsfollow.flight-review",
              let version = object["schema_version"] as? NSNumber, CFGetTypeID(version) != CFBooleanGetTypeID(), version.stringValue == "1",
              let log = object["log"] as? [String: Any], let name = log["name"] as? String,
              let analysis = object["analysis"] as? [String: Any], let status = analysis["status"] as? String,
              ["complete", "partial", "unavailable"].contains(status),
              let findings = object["findings"] as? [[String: Any]], findings.count <= 128,
              let suggestions = object["suggestions"] as? [String: Any],
              let automatic = suggestions["automatic_apply"] as? NSNumber, CFGetTypeID(automatic) == CFBooleanGetTypeID(), automatic.boolValue == false,
              suggestions["parameter_patch"] == nil || suggestions["parameter_patch"] is NSNull else {
            throw CocoaError(.fileReadCorruptFile)
        }
        func plain(_ value: Any?) -> String {
            if let value = value as? String { return String(value.prefix(4096)) }
            if let value = value as? NSNumber { return value.stringValue }
            return "Not available"
        }
        var parts = ["PC flight diagnostics · \(String(name.prefix(160)))", "Analysis: \(status)"]
        for finding in findings {
            parts.append("\n\(plain(finding["severity"]).uppercased()): \(plain(finding["summary"]))")
            if let evidence = finding["evidence"] as? [[String: Any]], evidence.count <= 128 {
                for item in evidence {
                    parts.append("• \(plain(item["metric"])): \(plain(item["value"])) \(plain(item["unit"])) · \(plain(item["source"]))")
                }
            }
            parts.append("Suggested next step: \(plain(finding["recommendation"]))")
        }
        for field in ["warnings", "unknowns", "limits"] {
            if let items = analysis[field] as? [String], items.count <= 128 {
                parts.append("\n\(field.capitalized):\n" + items.map { String($0.prefix(4096)) }.joined(separator: "\n"))
            }
        }
        if let ai = object["ai_explanation"] as? [String: Any], ai["available"] as? Bool == true {
            parts.append("\nOptional AI explanation (advisory, not independently verified):\n" + plain(ai["text"]))
        }
        parts.append("\nThis is a saved review, not live telemetry or flight clearance. No suggested settings are applied by this app.")
        return FlightReviewDocument(text: parts.joined(separator: "\n"))
    }
    static func read(_ url: URL) throws -> FlightReviewDocument {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        let values = try url.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey])
        guard url.pathExtension.lowercased() == "json", values.isRegularFile == true,
              values.isSymbolicLink != true else { throw CocoaError(.fileReadNoPermission) }
        let handle = try FileHandle(forReadingFrom: url); defer { try? handle.close() }
        let data = try handle.read(upToCount: maximumBytes + 1) ?? Data()
        try Task.checkCancellation()
        return try parse(data)
    }
}

enum FlightLogSelection: Sendable {
    case overview(FlightLogOverview)
    case review(FlightReviewDocument)
}

@MainActor struct FlightLogsView: View {
    @Environment(\.scenePhase) private var scenePhase
    @State private var importing = false
    @State private var overview: FlightLogOverview?
    @State private var review: FlightReviewDocument?
    @State private var message: String?
    @State private var worker: Task<FlightLogSelection, Error>?
    @State private var generation = UUID()
    var body: some View {
        NavigationStack {
            List {
                Section("Check a flight log") {
                    Button("Open .BIN or PC review (.json)") { importing = true }.disabled(worker != nil)
                    if worker != nil { ProgressView("Reading the selected log…") }
                    Text("Use an iPhone-compatible SD reader, or save a copy from the PC to Files. The app cannot browse the controller’s SD card over its classic Bluetooth link. Files over 32 MB can be reviewed on the PC.")
                    if let message { Text(message).foregroundStyle(.red) }
                }
                if let overview {
                    Section("Selected file") {
                        Text(overview.name).font(.headline)
                        Text(overview.reviewText).font(.system(.caption, design: .monospaced)).textSelection(.enabled)
                        ShareLink(item: overview.reviewText) { Label("Share file overview", systemImage: "square.and.arrow.up") }
                    }
                }
                if let review {
                    Section("Flight diagnostics from your PC") {
                        Text(review.text).font(.subheadline).textSelection(.enabled)
                        ShareLink(item: review.text) { Label("Share diagnostics", systemImage: "square.and.arrow.up") }
                    }
                }
                Section("What the SD files mean") {
                    Text("LOGS / numbered .BIN: flight and bench records. The highest number may be a bench session; file dates can be wrong until GPS time is available.")
                    Text("scripts / .lua: executable controller scripts. This app never runs them.")
                    Text("STRG_BAK: storage backups for recovery. Never restore one just because it is newer.")
                    Text("TERRAIN: cached terrain tiles for supported navigation features. These are not flight logs.")
                }
                Section("Suggested changes") {
                    Text("On the PC, choose Flight Logs → Review → Export review. Save that JSON to iPhone Files, then open it here to see the same findings, evidence and suggested checks. Optional local AI explanations stay labelled as advisory. Neither app installs recommendations automatically.")
                }
            }
            .navigationTitle("Flight Logs").modifier(DroneMatrixSurface())
            .safeAreaInset(edge: .bottom) { AppBrandFooter() }
            .fileImporter(isPresented: $importing, allowedContentTypes: [UTType(filenameExtension: "bin") ?? .data, .json]) { result in
                guard case .success(let url) = result else { return }
                worker?.cancel(); overview = nil; review = nil; message = nil
                let token = UUID(); generation = token
                let next = Task.detached(priority: .utility) { () throws -> FlightLogSelection in
                    if url.pathExtension.lowercased() == "json" { return .review(try FlightReviewDocument.read(url)) }
                    return .overview(try FlightLogReader.read(url))
                }; worker = next
                Task { @MainActor in
                    do {
                        let value = try await next.value
                        guard generation == token else { return }
                        switch value { case .overview(let value): overview = value; case .review(let value): review = value }
                    } catch {
                        guard generation == token else { return }
                        message = "Could not read this file. Choose an ArduPilot .BIN under 32 MB or an exported PC flight-review JSON under 256 KB."
                    }
                    if generation == token { worker = nil }
                }
            }
            .onDisappear { stopRead() }
            .onChange(of: scenePhase) { _, phase in if phase == .background { stopRead() } }
        }
    }
    private func stopRead() { generation = UUID(); worker?.cancel(); worker = nil }
}
