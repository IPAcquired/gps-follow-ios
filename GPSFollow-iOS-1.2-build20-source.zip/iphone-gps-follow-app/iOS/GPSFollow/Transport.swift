import Foundation
import CoreFoundation
import Network
import CryptoKit
import Security

enum TransportMode: String, CaseIterable, Identifiable {
    case direct = "Direct Wi-Fi telemetry"
    case relay = "Optional Windows relay"
    var id: String { rawValue }
}

enum SecretStore {
    static let service = "GPSFollow.Pairing"
    static func load(_ name: String) -> String {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service, kSecAttrAccount as String: name,
            kSecReturnData as String: true, kSecMatchLimit as String: kSecMatchLimitOne]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return "" }
        return String(data: data, encoding: .utf8) ?? ""
    }
    @discardableResult static func save(_ value: String, name: String) -> Bool {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service, kSecAttrAccount as String: name]
        if value.isEmpty {
            let status = SecItemDelete(query as CFDictionary)
            return status == errSecSuccess || status == errSecItemNotFound
        }
        let attributes: [String: Any] = [kSecValueData as String: Data(value.utf8),
            kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlockedThisDeviceOnly]
        let status = SecItemUpdate(query as CFDictionary, attributes as CFDictionary)
        if status == errSecItemNotFound {
            var insert = query
            attributes.forEach { insert[$0.key] = $0.value }
            return SecItemAdd(insert as CFDictionary, nil) == errSecSuccess
        }
        return status == errSecSuccess
    }
}

enum AuthenticatedJSON {
    static let version = 2
    static let aad = Data("GPSFollow/phone-pc/v2/aes-256-gcm".utf8)
    private static let maximumBytes = 4096

    private static func isVersion(_ value: Any?) -> Bool {
        guard let number = value as? NSNumber,
              CFGetTypeID(number) != CFBooleanGetTypeID(),
              !["d", "f"].contains(String(cString: number.objCType)) else { return false }
        return number.doubleValue == Double(version)
    }

    private static func boundedJSON(_ data: Data) -> [String: Any]? {
        guard !data.isEmpty, data.count <= maximumBytes else { return nil }
        var depth = 0
        var quoted = false
        var escaped = false
        for byte in data {
            if quoted {
                if escaped { escaped = false }
                else if byte == 92 { escaped = true }
                else if byte == 34 { quoted = false }
            } else if byte == 34 { quoted = true }
            else if byte == 91 || byte == 123 {
                depth += 1
                if depth > 16 { return nil }
            } else if byte == 93 || byte == 125 {
                depth -= 1
                if depth < 0 { return nil }
            }
        }
        return try? JSONSerialization.jsonObject(with: data) as? [String: Any]
    }

    private static func base64(_ value: Any?) -> Data? {
        guard let text = value as? String, let decoded = Data(base64Encoded: text),
              decoded.base64EncodedString() == text else { return nil }
        return decoded
    }

    static func encode(_ payload: [String: Any], key: Data) -> Data? {
        guard key.count == 32, isVersion(payload["v"]),
              let body = try? JSONSerialization.data(withJSONObject: payload, options: [.sortedKeys]),
              boundedJSON(body) != nil,
              let sealed = try? AES.GCM.seal(body, using: SymmetricKey(data: key),
                                            nonce: AES.GCM.Nonce(), authenticating: aad),
              let wire = try? JSONSerialization.data(withJSONObject: [
                "v": version,
                "nonce": Data(sealed.nonce).base64EncodedString(),
                "ciphertext": sealed.ciphertext.base64EncodedString(),
                "tag": sealed.tag.base64EncodedString()], options: [.sortedKeys]),
              wire.count <= maximumBytes else { return nil }
        return wire
    }

    static func decode(_ data: Data, key: Data) -> [String: Any]? {
        guard key.count == 32, let envelope = boundedJSON(data),
              Set(envelope.keys) == Set(["v", "nonce", "ciphertext", "tag"]), isVersion(envelope["v"]),
              let iv = base64(envelope["nonce"]), iv.count == 12,
              let ciphertext = base64(envelope["ciphertext"]), !ciphertext.isEmpty,
              let tag = base64(envelope["tag"]), tag.count == 16,
              let nonce = try? AES.GCM.Nonce(data: iv),
              let sealed = try? AES.GCM.SealedBox(nonce: nonce, ciphertext: ciphertext, tag: tag),
              let body = try? AES.GCM.open(sealed, using: SymmetricKey(data: key), authenticating: aad),
              let payload = boundedJSON(body), isVersion(payload["v"]) else { return nil }
        return payload
    }
}

final class UDPLink {
    private var connection: NWConnection?
    var received: ((Data) -> Void)?
    var stateChanged: ((String) -> Void)?
    var ready = false

    func open(ip: String, port: UInt16) {
        close()
        guard let endpointPort = NWEndpoint.Port(rawValue: port) else { return }
        let next = NWConnection(host: NWEndpoint.Host(ip), port: endpointPort, using: .udp)
        connection = next
        next.stateUpdateHandler = { [weak self, weak next] state in
            DispatchQueue.main.async {
                guard let self, let next, self.connection === next else { return }
                switch state {
                case .ready: self.ready = true; self.stateChanged?("Network ready; verifying peer")
                case .waiting: self.ready = false; self.stateChanged?("Waiting for local network access")
                case .failed: self.ready = false; self.stateChanged?("Connection failed. Tap Stop, check Wi-Fi, then Start to retry.")
                case .cancelled: self.ready = false
                default: break
                }
            }
        }
        next.start(queue: .main)
        receive(next)
    }
    private func receive(_ active: NWConnection) {
        active.receiveMessage { [weak self, weak active] data, _, _, error in
            DispatchQueue.main.async {
                guard let self, let active, self.connection === active else { return }
                if let data, data.count <= 4096 { self.received?(data) }
                if error == nil { self.receive(active) }
                else { self.ready = false; self.stateChanged?("Network receive failed. Tap Stop, check Wi-Fi, then Start to retry.") }
            }
        }
    }
    func send(_ data: Data) {
        guard ready, let active = connection else { return }
        active.send(content: data, completion: .contentProcessed { [weak self, weak active] error in
            if let error { DispatchQueue.main.async {
                guard let self, let active, self.connection === active else { return }
                self.ready = false
                self.stateChanged?("Send failed. Tap Stop, check Wi-Fi, then Start to retry.")
            } }
        })
    }
    func close() { connection?.cancel(); connection = nil; ready = false }
}

final class DirectTarget {
    let link = UDPLink()
    let signer: MAVSigner
    let radius: Double
    let height: Double
    var statusChanged: ((String) -> Void)?
    private var fcSystem: UInt8?
    private var fcComponent: UInt8?
    private var versionVerified = false
    private var parameters: [String: (value: Double, time: TimeInterval)] = [:]
    private var heartbeatAt: TimeInterval = 0
    private var refreshAt: TimeInterval = -100
    private var ownHeartbeatAt: TimeInterval = -100
    private var blocked = false
    private let started = ProcessInfo.processInfo.systemUptime
    static let names = ["FOLL_ENABLE", "FOLL_SYSID", "FOLL_ALT_TYPE", "FOLL_OFS_TYPE", "FOLL_OFS_X", "FOLL_OFS_Y",
                        "FOLL_OFS_Z", "FOLL_DIST_MAX", "FOLL_TIMEOUT", "FOLL_YAW_BEHAVE"]

    init(key: Data, radius: Double, height: Double) {
        signer = MAVSigner(key: key)
        self.radius = radius
        self.height = height
        link.received = { [weak self] in self?.receive($0) }
        link.stateChanged = { [weak self] in self?.statusChanged?($0) }
    }

    private func receive(_ data: Data) {
        let now = ProcessInfo.processInfo.systemUptime
        for message in signer.decode(data) {
            // MAVSigner already excludes byte-for-byte echoes of our own transmitted frames.
            if message.system == 42 {
                blocked = true; statusChanged?("Target address 42 is already in use"); return
            }
            if message.id == 0, message.component == 1, message.payload.count >= 9,
               message.payload[5] == 3, message.system != 42 {
                if let system = fcSystem, system != message.system {
                    blocked = true; statusChanged?("Multiple controllers on this link"); return
                }
                fcSystem = message.system; fcComponent = message.component; heartbeatAt = now
            }
            guard message.system == fcSystem, message.component == fcComponent else { continue }
            if message.id == 148, message.payload.count >= 78 {
                // The signed MAVLink key is the private controller identity for
                // a public build.  Do not compile an owner's unique board UID
                // into distributable source.  A valid signed version response
                // still proves that the selected peer owns that key.
                versionVerified = true
            } else if message.id == 22, message.payload.count >= 25 {
                let field = message.payload[8..<24].prefix { $0 != 0 }
                let name = String(bytes: field, encoding: .ascii) ?? ""
                if Self.names.contains(name) {
                    let value = Double(Float(bitPattern: MAVLink.u32(message.payload, 0)))
                    parameters[name] = (value, now)
                }
            }
        }
    }

    func tick() {
        guard link.ready, !blocked else { return }
        let now = ProcessInfo.processInfo.systemUptime
        if now - ownHeartbeatAt >= 1 {
            link.send(signer.packet(id: 0, payload: MAVLink.heartbeat()))
            ownHeartbeatAt = now
        }
        guard let system = fcSystem, let component = fcComponent else {
            statusChanged?("Waiting for signed controller heartbeat"); return
        }
        if now - refreshAt >= 4 {
            refreshAt = now
            link.send(signer.packet(id: 76, payload: MAVLink.requestVersion(system: system, component: component)))
            for name in Self.names {
                link.send(signer.packet(id: 20, payload: MAVLink.requestParameter(name, system: system, component: component)))
            }
        }
        if let reason = gateReason { statusChanged?(reason) }
        else { statusChanged?("Controller verified; GPS target link ready") }
    }

    var gateReason: String? {
        let now = ProcessInfo.processInfo.systemUptime
        if blocked { return "Controller verification failed; stop and check setup" }
        if !link.ready { return "Waiting for network" }
        if now - heartbeatAt > 3 { return "Controller heartbeat lost" }
        if !versionVerified { return "Verifying signed controller identity" }
        let required: [String: Double] = ["FOLL_ENABLE": 1, "FOLL_SYSID": 42, "FOLL_ALT_TYPE": 1,
                                        "FOLL_OFS_TYPE": 0, "FOLL_OFS_X": 0, "FOLL_OFS_Y": 0, "FOLL_OFS_Z": -height]
        for name in Self.names {
            guard let param = parameters[name], now - param.time <= 10, param.value.isFinite else {
                return "Waiting for Follow setup readback: \(name)"
            }
            if let expected = required[name], abs(param.value - expected) > 0.01 {
                return "Follow setup needed: \(name) = \(expected)"
            }
        }
        guard let distance = parameters["FOLL_DIST_MAX"]?.value, distance >= 5, distance <= radius else {
            return "Follow maximum distance must fit the operating radius"
        }
        guard let timeout = parameters["FOLL_TIMEOUT"]?.value, timeout >= 0.5, timeout <= 3 else {
            return "Follow target timeout must be 0.5–3 seconds"
        }
        guard let yaw = parameters["FOLL_YAW_BEHAVE"]?.value, yaw == 0 || yaw == 1 else {
            return "Follow yaw must be None or Face Target"
        }
        return nil
    }

    func publish(lat: Double, lon: Double) -> Bool {
        guard gateReason == nil else { return false }
        let milliseconds = UInt32(truncatingIfNeeded: UInt64((ProcessInfo.processInfo.systemUptime - started) * 1000))
        link.send(signer.packet(id: 33, payload: MAVLink.position(lat: lat, lon: lon, uptimeMS: milliseconds)))
        return true
    }
    func close() { link.close() }
}
