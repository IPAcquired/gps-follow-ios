import Foundation
import Combine

@MainActor final class CADTransferModel: ObservableObject {
    @Published private(set) var busy = false
    @Published private(set) var connected = false
    @Published private(set) var remoteItems: [CADRemoteItem] = []
    @Published private(set) var status = "Stopped"
    @Published private(set) var error: String?
    private var client: CADTransferClient?
    private var task: Task<Void, Never>?
    private var generation = 0

    func stop() {
        generation += 1
        task?.cancel(); task = nil
        let closing = client; client = nil
        busy = false; connected = false; remoteItems = []
        status = "Stopped"; error = nil
        // Only the captured old session is closed; a fresh session remains independent.
        if let closing { Task { await closing.stop() } }
    }

    func start(ip: String, secret: String, port: String) {
        guard !busy else { return }
        stop()
        guard let key = MAVLink.key(secret), let number = Int(port),
              String(number) == port else {
            error = "Use the paired PC setup from Connect / GPS and its CAD port."; return
        }
        do {
            let session = try CADTransferClient(pairingKey: key, pcIPv4: ip, port: number)
            client = session
            execute(session, label: "Connecting…") { [weak self] session, attempt in
                try await session.start()
                let items = try await session.list()
                guard let self, self.generation == attempt else { throw CADTransferError.cancelled }
                self.remoteItems = items; self.connected = true
                return "PC CAD session ready · select a file to transfer"
            }
        } catch { self.error = error.localizedDescription }
    }

    func refresh() {
        guard let client, connected, !busy else { return }
        execute(client, label: "Reading PC library…") { [weak self] session, attempt in
            let items = try await session.list()
            guard let self, self.generation == attempt else { throw CADTransferError.cancelled }
            self.remoteItems = items
            return "PC library refreshed"
        }
    }

    func upload(_ item: CADItem, library: CADLibrary) {
        guard let client, connected, !busy else { return }
        execute(client, label: "Sending \(item.name)…") { [weak self] session, attempt in
            let data = try library.transferData(item)
            _ = try await session.upload(name: item.name, data: data)
            guard let self, self.generation == attempt else { throw CADTransferError.cancelled }
            let items = try await session.list()
            guard self.generation == attempt else { throw CADTransferError.cancelled }
            self.remoteItems = items
            return "Saved and verified on PC · \(item.name)"
        }
    }

    func download(_ item: CADRemoteItem, library: CADLibrary) {
        guard let client, connected, !busy else { return }
        execute(client, label: "Receiving \(item.name)…") { [weak self] session, attempt in
            let (verified, data) = try await session.download(id: item.id)
            guard let self, self.generation == attempt, !Task.isCancelled else { throw CADTransferError.cancelled }
            _ = try library.importTransfer(name: verified.name, data: data)
            return "Saved and verified on iPhone · \(verified.name)"
        }
    }

    private func execute(_ session: CADTransferClient, label: String,
                         work: @escaping @MainActor (CADTransferClient, Int) async throws -> String) {
        let attempt = generation
        busy = true; status = label; error = nil
        task = Task { [weak self] in
            do {
                let message = try await work(session, attempt)
                guard let self, self.generation == attempt, !Task.isCancelled else { return }
                self.status = message; self.busy = false; self.task = nil
            } catch {
                guard let self, self.generation == attempt else { return }
                await session.stop()
                guard self.generation == attempt else { return }
                self.client = nil
                self.connected = false; self.busy = false; self.remoteItems = []
                self.error = error.localizedDescription; self.status = "Start again to reconnect"
                self.task = nil
            }
        }
    }
}
