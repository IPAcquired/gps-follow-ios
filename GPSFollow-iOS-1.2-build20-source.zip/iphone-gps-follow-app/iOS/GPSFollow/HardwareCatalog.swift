import CryptoKit
import Foundation

struct BatteryCatalogProfile: Codable, Equatable {
    let id: String, label: String
    let minCells, maxCells, defaultCells: Int
    let fullVPerCell, lowVPerCell, criticalVPerCell, emptyVPerCell: Double
    let percentageMethod: String
    enum CodingKeys: String, CodingKey {
        case id, label, minCells = "min_cells", maxCells = "max_cells", defaultCells = "default_cells"
        case fullVPerCell = "full_v_per_cell", lowVPerCell = "low_v_per_cell"
        case criticalVPerCell = "critical_v_per_cell", emptyVPerCell = "empty_v_per_cell"
        case percentageMethod = "percentage_method"
    }
}

struct BoardCatalogEntry: Codable, Equatable, Identifiable {
    let id: String, label: String, firmwareTarget: String
    enum CodingKeys: String, CodingKey { case id, label, firmwareTarget = "firmware_target" }
}
struct HardwareCatalogPayload: Codable, Equatable {
    let batteryProfiles: [BatteryCatalogProfile], boards: [BoardCatalogEntry]
    enum CodingKeys: String, CodingKey { case batteryProfiles = "battery_profiles", boards }
}
struct CatalogSignature: Codable, Equatable { let algorithm: String; let keyID, value: String?; enum CodingKeys: String, CodingKey { case algorithm, keyID = "key_id", value } }
struct HardwareCatalog: Codable, Equatable {
    let schemaVersion: Int, catalogVersion: String, generatedAt: String
    let payload: HardwareCatalogPayload, payloadSHA256: String, signature: CatalogSignature
    enum CodingKeys: String, CodingKey {
        case schemaVersion = "schema_version", catalogVersion = "catalog_version", generatedAt = "generated_at"
        case payload, payloadSHA256 = "payload_sha256", signature
    }
}
struct BatteryDisplay: Equatable {
    let cells: Int, measuredPackVoltage: Double?, estimatedPercent: Double?
    let full, low, critical: Double
}

enum HardwareCatalogRules {
    static let remoteURL = URL(string: "https://raw.githubusercontent.com/IPAcquired/gps-follow-companion/main/catalog/hardware-catalog.json")!
    static let maxBytes = 65_536
    static let boardTargets = ["micoair-h743-v1":"MicoAir743", "micoair-h743-v2":"MicoAir743v2", "micoair-h405-v1":"MicoAir405", "micoair-h405-v2":"MicoAir405v2"]
    static let embeddedFallbackJSON = #"{"schema_version":1,"catalog_version":"2026.10.03.1","generated_at":"2026-10-03T00:00:00Z","payload":{"battery_profiles":[{"id":"lipo-1s-12s","label":"LiPo 1S-12S","min_cells":1,"max_cells":12,"default_cells":6,"full_v_per_cell":4.2,"low_v_per_cell":3.5,"critical_v_per_cell":3.3,"empty_v_per_cell":3.3,"percentage_method":"linear-voltage-estimate"}],"boards":[{"id":"micoair-h743-v1","label":"MicoAir H743 v1","firmware_target":"MicoAir743"},{"id":"micoair-h743-v2","label":"MicoAir H743 v2","firmware_target":"MicoAir743v2"},{"id":"micoair-h405-v1","label":"MicoAir H405 v1","firmware_target":"MicoAir405"},{"id":"micoair-h405-v2","label":"MicoAir H405 v2","firmware_target":"MicoAir405v2"}]},"payload_sha256":"1bd385cbf81418890eb02df354a06569d28a73e9565efa94890277c9cddbe10d","signature":{"algorithm":"none","key_id":null,"value":null}}"#

    static func validate(_ data: Data) throws -> HardwareCatalog {
        guard data.count <= maxBytes else { throw ProfileValidationError("Hardware catalog is too large.") }
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              Set(root.keys) == Set(["schema_version", "catalog_version", "generated_at", "payload", "payload_sha256", "signature"]),
              let payloadObject = root["payload"] as? [String: Any], Set(payloadObject.keys) == Set(["battery_profiles", "boards"]),
              let batteryObjects = payloadObject["battery_profiles"] as? [[String: Any]], batteryObjects.count == 1,
              Set(batteryObjects[0].keys) == Set(["id", "label", "min_cells", "max_cells", "default_cells", "full_v_per_cell", "low_v_per_cell", "critical_v_per_cell", "empty_v_per_cell", "percentage_method"]),
              let boardObjects = payloadObject["boards"] as? [[String: Any]], boardObjects.allSatisfy({ Set($0.keys) == Set(["id", "label", "firmware_target"]) }),
              let signatureObject = root["signature"] as? [String: Any], Set(signatureObject.keys) == Set(["algorithm", "key_id", "value"]) else {
            throw ProfileValidationError("Hardware catalog fields are invalid.")
        }
        let catalog = try JSONDecoder().decode(HardwareCatalog.self, from: data)
        guard catalog.schemaVersion == 1, (1...40).contains(catalog.catalogVersion.count), catalog.generatedAt.count <= 40 else { throw ProfileValidationError("Hardware catalog schema is invalid.") }
        guard catalog.signature == CatalogSignature(algorithm: "none", keyID: nil, value: nil) else { throw ProfileValidationError("This catalog signature cannot be verified.") }
        let canonical = try JSONSerialization.data(withJSONObject: payloadObject, options: [.sortedKeys])
        let digest = SHA256.hash(data: canonical).map { String(format: "%02x", $0) }.joined()
        guard digest == catalog.payloadSHA256 else { throw ProfileValidationError("Hardware catalog hash does not match.") }
        guard catalog.payload.batteryProfiles.count == 1, let battery = catalog.payload.batteryProfiles.first,
              battery.id == "lipo-1s-12s", battery.minCells == 1, battery.maxCells == 12, battery.defaultCells == 6,
              battery.percentageMethod == "linear-voltage-estimate",
              2.5 <= battery.emptyVPerCell, battery.emptyVPerCell <= battery.criticalVPerCell,
              battery.criticalVPerCell <= battery.lowVPerCell, battery.lowVPerCell < battery.fullVPerCell, battery.fullVPerCell <= 5 else { throw ProfileValidationError("Battery catalog bounds are invalid.") }
        var targets: [String: String] = [:]
        for board in catalog.payload.boards {
            guard targets[board.id] == nil, (1...80).contains(board.label.count), (1...80).contains(board.firmwareTarget.count) else { throw ProfileValidationError("Board catalog metadata is invalid.") }
            targets[board.id] = board.firmwareTarget
        }
        guard catalog.payload.boards.count == 4, targets == boardTargets else { throw ProfileValidationError("Board catalog targets are invalid.") }
        return catalog
    }
    static func fallback(bundle: Bundle = .main) -> HardwareCatalog {
        if let url = bundle.url(forResource: "hardware-catalog", withExtension: "json"), let data = try? Data(contentsOf: url), let value = try? validate(data) { return value }
        if let value = try? validate(Data(embeddedFallbackJSON.utf8)) { return value }
        let battery = BatteryCatalogProfile(id: "lipo-1s-12s", label: "LiPo 1S-12S", minCells: 1, maxCells: 12, defaultCells: 6,
            fullVPerCell: 4.2, lowVPerCell: 3.5, criticalVPerCell: 3.3, emptyVPerCell: 3.3, percentageMethod: "linear-voltage-estimate")
        let boards = [BoardCatalogEntry(id: "micoair-h743-v1", label: "MicoAir H743 v1", firmwareTarget: "MicoAir743"),
                      BoardCatalogEntry(id: "micoair-h743-v2", label: "MicoAir H743 v2", firmwareTarget: "MicoAir743v2"),
                      BoardCatalogEntry(id: "micoair-h405-v1", label: "MicoAir H405 v1", firmwareTarget: "MicoAir405"),
                      BoardCatalogEntry(id: "micoair-h405-v2", label: "MicoAir H405 v2", firmwareTarget: "MicoAir405v2")]
        return HardwareCatalog(schemaVersion: 1, catalogVersion: "2026.10.03.1", generatedAt: "2026-10-03T00:00:00Z",
            payload: HardwareCatalogPayload(batteryProfiles: [battery], boards: boards), payloadSHA256: "embedded-safe-fallback",
            signature: CatalogSignature(algorithm: "none", keyID: nil, value: nil))
    }
    static func batteryDisplay(measuredPackVoltage: Double?, cells: Int, catalog: HardwareCatalog) throws -> BatteryDisplay {
        let battery = catalog.payload.batteryProfiles[0]
        guard (battery.minCells...battery.maxCells).contains(cells) else { throw ProfileValidationError("Battery cell count must be 1 through 12.") }
        guard let measuredPackVoltage else { return BatteryDisplay(cells: cells, measuredPackVoltage: nil, estimatedPercent: nil, full: battery.fullVPerCell*Double(cells), low: battery.lowVPerCell*Double(cells), critical: battery.criticalVPerCell*Double(cells)) }
        guard measuredPackVoltage.isFinite, measuredPackVoltage > 0, measuredPackVoltage <= 100 else { throw ProfileValidationError("Measured pack voltage is invalid.") }
        let perCell = measuredPackVoltage / Double(cells)
        let estimate = min(100, max(0, (perCell-battery.emptyVPerCell)/(battery.fullVPerCell-battery.emptyVPerCell)*100))
        return BatteryDisplay(cells: cells, measuredPackVoltage: measuredPackVoltage, estimatedPercent: estimate, full: battery.fullVPerCell*Double(cells), low: battery.lowVPerCell*Double(cells), critical: battery.criticalVPerCell*Double(cells))
    }
    static func requireBoardFirmware(boardID: String, target: String, catalog: HardwareCatalog) throws {
        guard catalog.payload.boards.first(where: { $0.id == boardID })?.firmwareTarget == target else { throw ProfileValidationError("Firmware target does not exactly match the selected board.") }
    }
    static func refresh(from url: URL = remoteURL) async throws -> HardwareCatalog {
        guard url == remoteURL else { throw ProfileValidationError("Hardware catalog URL is not trusted.") }
        var request = URLRequest(url: url); request.setValue("application/json", forHTTPHeaderField: "Accept"); request.setValue("GPSFollow-catalog/1", forHTTPHeaderField: "User-Agent")
        let configuration = URLSessionConfiguration.ephemeral; configuration.timeoutIntervalForRequest = 8; configuration.timeoutIntervalForResource = 12
        configuration.httpCookieStorage = nil; configuration.urlCredentialStorage = nil
        let session = URLSession(configuration: configuration); defer { session.invalidateAndCancel() }
        let (bytes, response) = try await session.bytes(for: request)
        guard let http = response as? HTTPURLResponse, http.statusCode == 200, http.url == remoteURL else { throw ProfileValidationError("Hardware catalog download failed.") }
        var data = Data(); data.reserveCapacity(8_192)
        for try await byte in bytes { guard data.count < maxBytes else { throw ProfileValidationError("Hardware catalog is too large.") }; data.append(byte) }
        return try validate(data)
    }
}

@MainActor final class HardwareCatalogStore: ObservableObject {
    @Published var catalog = HardwareCatalogRules.fallback()
    @Published var status = "Bundled offline catalog 2026.10.03.1"
    @Published var refreshing = false
    func refresh() {
        guard !refreshing else { return }; refreshing = true; status = "Refreshing the fixed GitHub catalog…"
        Task {
            do { catalog = try await HardwareCatalogRules.refresh(); status = "Validated remote catalog \(catalog.catalogVersion) · HTTPS + hash checked · unsigned" }
            catch { status = "Refresh rejected or unavailable · using bundled \(catalog.catalogVersion)" }
            refreshing = false
        }
    }
}
