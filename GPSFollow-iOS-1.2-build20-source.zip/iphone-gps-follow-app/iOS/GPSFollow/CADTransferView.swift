import SwiftUI

@MainActor struct CADTransferView: View {
    @ObservedObject var gps: GPSModel
    @ObservedObject var library: CADLibrary
    @StateObject private var transfer = CADTransferModel()
    @State private var port = "8766"
    @FocusState private var editing: Bool
    @Environment(\.scenePhase) private var scenePhase

    var body: some View {
        Form {
            Section("Your paired PC") {
                LabeledContent("PC Wi-Fi address", value: gps.mode == .relay ? gps.ip : "Select PC relay in Connect / GPS")
                TextField("CAD port", text: $port).keyboardType(.numberPad).focused($editing)
                    .disabled(transfer.connected || transfer.busy)
                Text("Uses the private key already saved in Connect / GPS. No second key to copy. CAD uses TCP 8766; GPS uses its own UDP port.")
                    .font(.footnote).foregroundStyle(.secondary)
                Button("Start CAD connection") { editing = false; transfer.start(ip: gps.ip, secret: gps.secret, port: port) }
                    .disabled(transfer.busy || transfer.connected || gps.mode != .relay)
                Button(transfer.busy ? "Cancel transfer" : "Stop CAD connection", role: .destructive) { transfer.stop() }
                Text(transfer.status)
                if transfer.busy { ProgressView() }
                if let error = transfer.error { Text(error).foregroundStyle(.red) }
            }
            Section("Send a saved iPhone design") {
                if library.items.isEmpty { Text("Add an STL or 3MF in Drone CAD first.").foregroundStyle(.secondary) }
                ForEach(library.items) { item in
                    Button { transfer.upload(item, library: library) } label: {
                        Label("Send \(item.name) to PC", systemImage: "arrow.up.doc")
                    }.disabled(!transfer.connected || transfer.busy || item.bytes > CADTransferWire.maxFile)
                }
            }
            Section("Receive from PC") {
                Button("Refresh PC library") { transfer.refresh() }.disabled(!transfer.connected || transfer.busy)
                ForEach(transfer.remoteItems, id: \.id) { item in
                    Button { transfer.download(item, library: library) } label: {
                        Label("Save \(item.name) on iPhone", systemImage: "arrow.down.doc")
                    }.disabled(!transfer.connected || transfer.busy)
                }
                Text("On the PC, open CAD transfer and use Add STL / 3MF before starting its listener. Each transfer saves a new copy; it never overwrites an existing design.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            Section("Two steps to connect") {
                Text("1. Use the same private Wi-Fi. On the PC select this iPhone’s address, then Start CAD transfer.")
                Text("2. Tap Start here. Send a saved design or choose a file from the PC library.")
                Text("Files up to 20 MiB are encrypted and verified. Stop closes this session; it also closes when you leave this screen, change PC/key or send the app to the background. GPS sharing is separate.")
                Text("This transfers STL and 3MF designs only. App updates still require normal signed installation; firmware and printer jobs are not installed or executed through CAD transfer.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
        }
        .modifier(DroneMatrixSurface())
        .navigationTitle("PC file transfer")
        .scrollDismissesKeyboard(.interactively)
        .toolbar { ToolbarItemGroup(placement: .keyboard) { Spacer(); Button("Done") { editing = false } } }
        .onDisappear { transfer.stop() }
        .onChange(of: gps.ip) { _, _ in transfer.stop() }
        .onChange(of: gps.secret) { _, _ in transfer.stop() }
        .onChange(of: gps.mode) { _, _ in transfer.stop() }
        .onChange(of: scenePhase) { _, phase in if phase == .background { transfer.stop() } }
        .safeAreaInset(edge: .bottom) { AppBrandFooter() }
    }
}
