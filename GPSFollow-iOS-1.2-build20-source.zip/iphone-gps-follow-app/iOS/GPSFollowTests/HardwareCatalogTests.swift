import XCTest
@testable import GPSFollow

final class HardwareCatalogTests: XCTestCase {
    func testFallbackDefaultAndCellBoundsNeverFabricateVoltage() throws {
        let catalog = HardwareCatalogRules.fallback()
        XCTAssertEqual(catalog.payload.batteryProfiles[0].defaultCells, 6)
        for cells in [1, 6, 12] {
            let view = try HardwareCatalogRules.batteryDisplay(measuredPackVoltage: nil, cells: cells, catalog: catalog)
            XCTAssertNil(view.measuredPackVoltage); XCTAssertNil(view.estimatedPercent)
        }
        XCTAssertThrowsError(try HardwareCatalogRules.batteryDisplay(measuredPackVoltage: nil, cells: 0, catalog: catalog))
        XCTAssertThrowsError(try HardwareCatalogRules.batteryDisplay(measuredPackVoltage: nil, cells: 13, catalog: catalog))
        let measured = try HardwareCatalogRules.batteryDisplay(measuredPackVoltage: 22.2, cells: 6, catalog: catalog)
        XCTAssertEqual(measured.measuredPackVoltage, 22.2); XCTAssertNotNil(measured.estimatedPercent)
    }
    func testWrongBoardRejected() throws {
        let catalog = HardwareCatalogRules.fallback()
        XCTAssertNoThrow(try HardwareCatalogRules.requireBoardFirmware(boardID: "micoair-h743-v2", target: "MicoAir743v2", catalog: catalog))
        XCTAssertThrowsError(try HardwareCatalogRules.requireBoardFirmware(boardID: "micoair-h743-v2", target: "MicoAir743", catalog: catalog))
        XCTAssertThrowsError(try HardwareCatalogRules.requireBoardFirmware(boardID: "unknown", target: "MicoAir743v2", catalog: catalog))
    }
    func testMalformedOversizeHashMismatchAndUntrustedURLRejected() async throws {
        XCTAssertThrowsError(try HardwareCatalogRules.validate(Data("{".utf8)))
        XCTAssertThrowsError(try HardwareCatalogRules.validate(Data(repeating: 0, count: HardwareCatalogRules.maxBytes + 1)))
        var object = try XCTUnwrap(JSONSerialization.jsonObject(with: Data(HardwareCatalogRules.embeddedFallbackJSON.utf8)) as? [String: Any])
        object["payload_sha256"] = String(repeating: "0", count: 64)
        XCTAssertThrowsError(try HardwareCatalogRules.validate(JSONSerialization.data(withJSONObject: object)))
        object = try XCTUnwrap(JSONSerialization.jsonObject(with: Data(HardwareCatalogRules.embeddedFallbackJSON.utf8)) as? [String: Any])
        object["unexpected"] = true
        XCTAssertThrowsError(try HardwareCatalogRules.validate(JSONSerialization.data(withJSONObject: object)))
        do { _ = try await HardwareCatalogRules.refresh(from: URL(string: "https://example.com/catalog.json")!); XCTFail("Untrusted URL accepted") }
        catch { XCTAssertTrue(true) }
    }
}
