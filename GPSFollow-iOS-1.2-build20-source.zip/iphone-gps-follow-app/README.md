# Secure edition · October 3, 2026

This edition needs the matching encrypted Windows companion. The phone-PC wire format is deliberately incompatible with the older HMAC release. No keys are rotated and no controller settings are changed by creating this source edition. Python relay code additionally needs the pinned cryptography dependency; it is bundled by the desktop release. Direct controller signing/provisioning remains unverified. New native compilation, tests and device installation must be verified separately. Historical base test reports are kept outside this source archive.

# GPS Follow for iPhone 16 Plus

This package contains a native SwiftUI iPhone app, an Xcode project and an optional Windows relay. The app shares a **GPS Follow target only**. It cannot arm, take off, land, search for a landing surface, change flight mode, set home, modify flight-controller parameters or replace the aircraft’s own GPS.

**Delivery status:** source and project are prepared. The Python validation/codec tests and project structure checks can run offline on Windows. The app has **not been compiled, signed, installed or tested on an iPhone**, because this workspace has no Mac/Xcode/iOS SDK. Direct connection also requires a compatible telemetry interface and a matching signing key; the currently identified UART8 classic Bluetooth/SPP module has not been verified as an iPhone-compatible direct interface. This package does not convert that module into BLE or invent BLE service identifiers. The live controller’s `FOLL_ENABLE=0` has been retained; this app will refuse to publish a direct target until the prepared Follow settings pass readback.

## What is included

- `iOS/GPSFollow.xcodeproj`: app and shared `GPSFollow` scheme, targeting iPhone/iOS 17 or later. iPhone 16 Plus supports the target platform.
- `iOS/GPSFollow/`: SwiftUI Start/Stop screen, precise foreground Core Location, direct MAVLink UDP, signature validation, device verification and GPS filtering.
- `iOS/GPSFollowTests/`: Swift XCTest sources and reference fixtures. **These Swift tests still need to run in Xcode.**
- `relay/relay.py`: optional authenticated phone-to-Windows UDP relay with explicit COM8/COM9 selection and exact H743 identity readback.
- `relay/test_relay.py`, `relay/test_project.py`: offline Python tests, including compatibility comparisons against the existing pymavlink codec. No hardware or network server is opened by these tests.
- `.github/workflows/ios-build.yml`: prepared manual Mac build/simulator-test workflow. See `CI-BUILD.md`; uploading/dispatching and actual native compilation remain pending.
- `ci/verify_workflow.py`: offline YAML/shell/Python/path/security checks and synthetic CI cases. The saved workflow review used the existing WSL Python/PyYAML installation.

## Direct connection: intended primary transport

```text
iPhone GPS Follow app -- signed MAVLink 2 unicast UDP --> compatible Wi-Fi telemetry gateway --> H743
```

The gateway must forward raw MAVLink bytes both directions and return controller telemetry to the same phone UDP connection. Its Wi-Fi address and UDP port are entered explicitly. There is no discovery, broadcast or internet/cloud service. The module’s actual model, firmware, network settings and iPhone interoperability must be verified before using this path. A radio advertised as classic Bluetooth SPP does not establish this UDP capability. No BLE transport is implemented without the module’s documented service/characteristic contract.

An independently engineered Wi-Fi-to-classic-Bluetooth bridge could potentially retain the current module and occupied UARTs. Such bridge hardware/firmware is **not included, installed or validated** by this app deliverable. A Windows SPP COM port also does not prove an Apple-supported GATT or accessory protocol. There is no claimed ArduPilot-only conversion of that module into an iPhone-compatible radio.

Direct UDP **requires MAVLink 2 signing already configured on the controller’s connected telemetry channel**. Enter the existing matching 32-byte secret as 64 hexadecimal characters. The app never sends `SETUP_SIGNING` and never replaces keys. It rejects unsigned replies, bad checksums, bad signatures, replayed messages and signing timestamps more than 60 seconds from the phone’s clock. Make sure the phone and controller clocks are correct; do not reset signing keys to work around a clock error. Link ID 43 identifies this sender; avoid assigning that signing link ID to another sender with the same system/component identity.

The app signs its lead heartbeat, diagnostic `AUTOPILOT_VERSION` request, read-only parameter requests and `GLOBAL_POSITION_INT`. Target identity is **system 42, component 191**. A controller heartbeat must be signed, identify ArduPilot and come from component 1. The app then verifies UID2:

```text
[private controller UID removed from public source]
```

It pads truncated MAVLink 2 extension bytes before comparing the full 18-byte UID. UID matching prevents accidental use with a different board; message signing supplies network authentication. A valid signed message from another target on system 42 blocks publication. Exact echoes of this app’s own frames are ignored. Run **one target publisher at a time**: do not run the direct app and a relay or another app instance together on system 42.

## Prepared Follow settings and altitude

Before publishing, the app reads and checks the following settings; **it never writes them**. These values describe the expected prepared configuration, not authorization to enable Follow before firmware integration and flight readiness have been reviewed.

| Parameter | Required readback |
|---|---|
| `FOLL_ENABLE` | `1` after a separate, reviewed setup; presently `0` on the board |
| `FOLL_SYSID` | `42` |
| `FOLL_ALT_TYPE` | `1`, home-relative |
| `FOLL_OFS_TYPE` | `0`, North-East-Down |
| `FOLL_OFS_X`, `FOLL_OFS_Y` | `0`, no hidden horizontal offset |
| `FOLL_OFS_Z` | Negative configured height, e.g. `-5` for 5 m above home/launch level |
| `FOLL_DIST_MAX` | Positive, at least 5 m and no greater than the app operating radius |
| `FOLL_TIMEOUT` | 0.5–3 seconds, read from this custom firmware |
| `FOLL_YAW_BEHAVE` | `0` (none) or `1` (face target) |

The exact custom source reviewed was based on `dbe792162d06cab66c3475fd5556bf7a120f119e`. It interprets `GLOBAL_POSITION_INT.relative_alt` according to `FOLL_ALT_TYPE`, while `FOLLOW_TARGET` uses absolute altitude. This sender intentionally uses **only `GLOBAL_POSITION_INT`** with `relative_alt=0`, `alt=0`, `vx=vy=vz=0`, unknown heading `65535` and no velocity extrapolation. `alt=0` is a deliberate placeholder; the absolute-altitude path is blocked by readback. The aircraft’s own GPS/estimator is never injected with the phone’s location.

**“Height above launch level” is a fixed height above the aircraft’s home datum. It is not clearance above the phone, the current ground, a roof or changing terrain.** The phone’s unreliable vertical GPS measurement is never used to command climbs. A negative down offset produces the configured height above the fixed home datum. Walking up a hill does not cause this sender to raise that altitude.

The controller chooses Follow only through the pilot’s separate transmitter/mode control. App Start does not change mode. `GLOBAL_POSITION_INT` has no delivery/acceptance acknowledgement: the direct counter reports locally queued target packets, not proof of aircraft movement or reception. Controller readiness means signed heartbeat/identity/settings were checked, not that a flight is safe.

## GPS validity and loss behavior

Only real, precise foreground Core Location fixes are used. Reduced/approximate permission and software-simulated locations are rejected. The source must be within the configured center/radius, with accuracy no worse than 8 m, age no more than 1 second and walking speed no more than 3 m/s. Position changes are bounded by elapsed fix time and a limited uncertainty allowance. Duplicate-time changed coordinates, backward timestamps, impossible jumps and invalid numeric values are rejected. These filters reduce bad fixes; they cannot prove the GPS coordinate is correct.

Target publication is bounded to 5 Hz. Leaving the app, locking the phone, stopping, loss of usable GPS, loss of signed controller heartbeat, stale parameter readback or a configuration mismatch suppresses target publication. A local UDP send failure marks the transport unavailable. The app prevents idle auto-lock while sharing, but an intentional lock/background transition stops it. It does not resume sharing automatically.

The source stops publishing within the 1-second freshness window. **Onboard response is separately controlled by the actual `FOLL_TIMEOUT` readback.** The reviewed custom firmware defaults to 3 seconds; source expiry does not mean an instant motor stop or an automatic mode change. Controller shaping and inertia still apply. Verify the actual loss response in simulation and controlled testing before flight.

**Integration prerequisite:** the reviewed native `mode_follow.cpp` bypasses the existing Guided/Loiter rangefinder/proximity safety path. This package adds no obstacle avoidance, dropout guard, roof/ground classification, landing search or landing command. Do not assume the existing Guided avoidance modifications protect native Follow. Keep the transmitter connected for pilot control and complete that firmware integration review before enabling Follow.

## Build and install on the iPhone

1. Copy this complete folder to a Mac with Xcode and the iOS SDK appropriate for the phone’s installed iOS version. Open `iOS/GPSFollow.xcodeproj`.
2. Select the `GPSFollow` scheme. In Signing & Capabilities, choose your Apple development team and replace the example bundle identifiers with your own unique identifiers if needed. No development team or signing certificate is included.
3. Run the included XCTest suite on a supported iPhone simulator/device. Software-simulated location is intentionally blocked in normal app operation; codec/filter unit tests use their own data.
4. Connect the iPhone 16 Plus to the Mac, select it as the run destination, complete any Xcode-requested device trust/Developer Mode steps and run the app.
5. Allow “While Using” location access with **Precise Location** enabled, and allow Local Network access. Permission sheets are allowed while the app remains in the foreground; actual backgrounding stops sharing.
6. Enter the verified Wi-Fi telemetry address/UDP port and existing MAVLink signing key. Set an explicit operating center, radius and height above launch level. “Use current location as center” gets one fresh fix; this is the center of the allowed horizontal area, not an aircraft home update.
7. Use Start to obtain GPS and verify controller configuration. With the present `FOLL_ENABLE=0`, the screen will report that Follow setup is required and no GPS target will be emitted to the board.

For a Mac-only compilation check without installing/signing, from this folder:

```sh
xcodebuild -project iOS/GPSFollow.xcodeproj -scheme GPSFollow \
  -destination 'generic/platform=iOS' CODE_SIGNING_ALLOWED=NO build
```

Then run tests using an actual available simulator destination shown by Xcode. No successful native build is claimed for this Windows deliverable.

For an automated Mac runner, the prepared manual GitHub Actions workflow compiles an unsigned physical-iPhone application and executes the included XCTest methods (the original seven plus secure-envelope regressions) on an iPhone 16 Plus simulator. `CI-BUILD.md` describes repository layout and the unsigned build/test artifacts. No Apple credentials or physical-device signing are needed for these checks. The workflow has not been dispatched by the app-building agent.

## Optional Windows relay

This fallback preserves a laptop’s existing serial/SPP connection without claiming that iOS supports the module’s classic SPP directly:

```text
iPhone -- AES-256-GCM encrypted GPS JSON over private Wi-Fi --> Windows relay -- existing serial/SPP --> H743
```

The phone and laptop must be on one private Wi-Fi network. The relay binds only the explicitly configured laptop address and accepts one explicitly configured phone IP/UDP endpoint. Reserve those addresses if the network uses DHCP. No listener or COM port starts automatically.

From the workspace root, using its bundled Python or another existing Python environment with the existing `work/serial-deps` dependencies:

```powershell
# These are EXAMPLE private addresses/coordinates; replace them with verified values.
& '<existing-python.exe>' outputs/iphone-gps-follow-app/relay/relay.py new-config `
  --config '<private-location>/gps-follow-config.json' `
  --bind-ip 192.168.4.1 --phone-ip 192.168.4.2 `
  --origin-lat 41.0 --origin-lon -87.0 --radius-m 50 --height-m 5

# Start a listener that validates GPS but opens no serial port and emits no MAVLink.
& '<existing-python.exe>' outputs/iphone-gps-follow-app/relay/relay.py run `
  --config '<private-location>/gps-follow-config.json' --dry-run
```

Creation generates a random 256-bit key; it does not print the key or open any network/hardware. Open the private configuration locally to copy the key into the app’s **Optional Windows relay** mode. App center/radius/height must match the relay configuration; authenticated handshake readback enforces this. The relay uses AES-256-GCM with a random 96-bit nonce, a 128-bit authentication tag and fixed protocol-domain associated data. It accepts only encrypted protocol v2 with no older HMAC/plaintext fallback. It also uses a fresh relay nonce, a fresh phone nonce, advancing sequences, bounded timestamps, source address pinning and the same coordinate validity constraints. Old/reordered/replayed data is rejected. A rejected authenticated position immediately clears the cached target. An explicit Stop is best effort; freshness expiry is the loss safeguard.

Only after the physical link and prepared board configuration have been separately verified, serial startup is explicit:

```powershell
& '<existing-python.exe>' outputs/iphone-gps-follow-app/relay/relay.py run `
  --config '<private-location>/gps-follow-config.json' --serial COM9 --baud 115200
```

Choose only the verified `COM8` or `COM9`; opening a port is exclusive, so close other applications that own it first. The relay sends a separate target heartbeat and diagnostic reads, verifies exact UID2, reads Follow settings and stops/refuses GPS publication on mismatch/loss. It makes no parameter changes. All handles are released if socket creation/setup/binding fails after probing; fault-injection tests cover these paths.

The optional serial leg uses the trusted locally selected serial/SPP link and does not configure MAVLink signing on the board. If the board requires signing on that link, this relay cannot satisfy it without a separately reviewed extension; use the implemented signed direct path with a compatible gateway instead. Do not expose the serial relay to a public interface or bridge it to the internet.

## Offline validation and privacy

Run the Python suite from the workspace root:

```powershell
& '<existing-python.exe>' -m unittest discover `
  -s outputs/iphone-gps-follow-app/relay -p 'test_*.py' -v
```

It checks authentication/replay, timestamp/accuracy/speed/radius/outlier rejection, source loss, 5 Hz limits, altitude encoding, UID extension padding, exact signed/unsigned packet compatibility with pymavlink, diagnostic-only message content, resource/scheme/plist references and serial/socket cleanup. It imports codecs and uses test doubles; it does not open real COM ports or sockets. The Python fixture comparisons do not execute Swift and cannot substitute for Xcode compilation and device testing.

This secure source edition has 49 offline protocol/project checks: all previous 36 validation cases and 13 encryption/availability checks. The native XCTest class retains all seven prior methods and adds six secure-envelope methods, 13 total. Offline Python checks cannot execute Swift or substitute for native compilation. The base evidence and its workflow checks are retained separately as history; the new source needs a fresh native build and all 13 XCTest methods must pass. See SECURITY.md for exact coverage and remaining controller-link limits.

Pairing/signing secrets are stored in iOS Keychain with “when unlocked, this device only” accessibility. The optional relay configuration contains a secret and should stay in a private local folder; this package contains no real key. The app and relay do not store the live location stream or travel history. The app remembers the configured operating center and network settings locally, and the relay configuration contains that operating center; the center may originate from the “Use current location” button. No cloud account is used. **The secure phone-PC relay encrypts GPS coordinates; direct MAVLink signing authenticates but does not encrypt the direct controller link.** Use a trusted, secured private Wi-Fi network. Local Network and location permission explanations are included; no background location mode or multicast entitlement is requested.

## Primary references

- [ArduPilot Follow Mode](https://ardupilot.org/copter/docs/follow-mode.html): Follow target identity and offsets. Custom installed source must take precedence over a different firmware version’s behavior.
- [MAVLink GLOBAL_POSITION_INT](https://mavlink.io/en/messages/common.html#GLOBAL_POSITION_INT): message units/fields.
- [MAVLink AUTOPILOT_VERSION](https://mavlink.io/en/messages/standard.html#AUTOPILOT_VERSION): UID2 extension.
- [MAVLink message signing](https://mavlink.io/en/guide/message_signing.html): signing timestamp, link ID and signature structure.
- [Apple requestWhenInUseAuthorization](https://developer.apple.com/documentation/corelocation/cllocationmanager/requestwheninuseauthorization()): foreground location permission and purpose text.
- [Apple NSLocalNetworkUsageDescription](https://developer.apple.com/documentation/bundleresources/information-property-list/nslocalnetworkusagedescription): local network purpose text.
- Installed-source and Apple permission review: sibling `../iphone-gps-follow-review/source-review.md` when kept in this workspace.

This is a complete source implementation within the stated supported transports. A signed installable build, native XCTest execution, the telemetry gateway’s documented compatibility and the reviewed native Follow safety integration remain prerequisites for flight use.
